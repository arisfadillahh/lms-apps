import { after, NextResponse } from 'next/server';
import { z } from 'zod';

import { getSessionOrThrow } from '@/lib/auth';
import { getAssessmentWithRelations, updateAssessment } from '@/lib/dao/trialAssessmentsDao';
import { getAppBaseUrl } from '@/lib/env';
import { assertRole } from '@/lib/roles';
import {
  buildTrialParentReportContent,
  isCompleteTrialRubric,
  parseTrialRubric,
} from '@/lib/services/trialAssessmentContent';
import { sendTrialParentReportWhatsAppNotification } from '@/lib/services/trialClassNotifications';
import { getSupabaseAdmin } from '@/lib/supabaseServer';

export const runtime = 'nodejs';

const approveSchema = z.object({
  recommendedLevelId: z.string().uuid(),
  recommendedClassId: z.string().uuid(),
  paymentPlanId: z.string().uuid(),
  estimatedStartDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  discountLabel: z.string().trim().max(120).nullable().optional(),
  discountAmount: z.number().int().min(0).max(50_000_000).default(0),
});

function calculateProgramPrice(baseMonthly: number, durationMonths: number, planDiscountPercent: number, discountAmount: number) {
  const subtotal = Math.max(0, Math.round(baseMonthly * durationMonths));
  const planDiscount = Math.max(0, Math.round((subtotal * planDiscountPercent) / 100));
  const basePrice = Math.max(0, subtotal - planDiscount);
  const finalPrice = Math.max(0, basePrice - discountAmount);
  return { basePrice, finalPrice };
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSessionOrThrow();
    await assertRole(session, 'ADMIN');

    const { id } = await context.params;
    const parsed = approveSchema.safeParse(await request.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json({ error: 'Data publish trial report tidak valid.' }, { status: 400 });
    }

    const assessment = await getAssessmentWithRelations(id);
    if (!assessment || !assessment.trial) {
      return NextResponse.json({ error: 'Assessment trial tidak ditemukan.' }, { status: 404 });
    }
    if (!['PENDING_ADMIN_REVIEW', 'APPROVED', 'PUBLISHED'].includes(assessment.status)) {
      return NextResponse.json({ error: 'Assessment belum siap dipublish atau sudah masuk proses pembayaran.' }, { status: 409 });
    }

    const rubric = parseTrialRubric(assessment.rubric);
    if (!isCompleteTrialRubric(rubric)) {
      return NextResponse.json({ error: 'Rubrik coach belum lengkap.' }, { status: 400 });
    }

    const supabase = getSupabaseAdmin();
    const [levelResult, classResult, planResult] = await Promise.all([
      supabase
        .from('levels')
        .select('id, name')
        .eq('id', parsed.data.recommendedLevelId)
        .maybeSingle(),
      supabase
        .from('classes')
        .select('id, name, type, level_id')
        .eq('id', parsed.data.recommendedClassId)
        .maybeSingle(),
      supabase
        .from('payment_plans')
        .select('id, duration_months, discount_percent, is_active')
        .eq('id', parsed.data.paymentPlanId)
        .eq('is_active', true)
        .maybeSingle(),
    ]);

    if (levelResult.error) {
      return NextResponse.json({ error: `Gagal mengambil level: ${levelResult.error.message}` }, { status: 500 });
    }
    if (classResult.error) {
      return NextResponse.json({ error: `Gagal mengambil kelas: ${classResult.error.message}` }, { status: 500 });
    }
    if (planResult.error) {
      return NextResponse.json({ error: `Gagal mengambil payment plan: ${planResult.error.message}` }, { status: 500 });
    }
    if (!levelResult.data) {
      return NextResponse.json({ error: 'Level rekomendasi tidak valid.' }, { status: 400 });
    }
    if (
      !classResult.data ||
      classResult.data.type !== 'WEEKLY' ||
      classResult.data.level_id !== levelResult.data.id
    ) {
      return NextResponse.json({ error: 'Kelas tujuan harus sesuai dengan level rekomendasi.' }, { status: 400 });
    }
    if (!planResult.data) {
      return NextResponse.json({ error: 'Payment plan aktif tidak ditemukan.' }, { status: 400 });
    }

    const { data: pricing, error: pricingError } = await supabase
      .from('pricing')
      .select('id, base_price_monthly')
      .eq('level_id', levelResult.data.id)
      .eq('mode', assessment.trial.trial_mode)
      .eq('is_active', true)
      .maybeSingle();

    if (pricingError) {
      return NextResponse.json({ error: `Gagal mengambil pricing: ${pricingError.message}` }, { status: 500 });
    }
    if (!pricing) {
      return NextResponse.json({ error: `Pricing ${assessment.trial.trial_mode} untuk level rekomendasi belum tersedia.` }, { status: 400 });
    }

    const discountAmount = Math.max(0, parsed.data.discountAmount);
    const { basePrice, finalPrice } = calculateProgramPrice(
      Number(pricing.base_price_monthly),
      Number(planResult.data.duration_months) || 1,
      Number(planResult.data.discount_percent) || 0,
      discountAmount,
    );

    const parentReportContent = buildTrialParentReportContent({
      rubric,
      quickObservations: assessment.quick_observations ?? [],
      personalizedObservation: assessment.personalized_observation,
      recommendationTags: assessment.recommendation_tags ?? [],
    });

    const publishedAt = new Date().toISOString();
    const updated = await updateAssessment(assessment.id, {
      status: 'PUBLISHED',
      recommended_level_id: levelResult.data.id,
      recommended_class_id: classResult.data.id,
      parent_report_content: parentReportContent as any,
      estimated_start_date: parsed.data.estimatedStartDate,
      discount_label: parsed.data.discountLabel?.trim() || null,
      discount_amount: discountAmount,
      base_price: basePrice,
      final_price: finalPrice,
      pricing_id: pricing.id,
      payment_plan_id: planResult.data.id,
      approved_by: session.user.id,
      approved_at: assessment.approved_at ?? publishedAt,
      published_at: assessment.published_at ?? publishedAt,
    });

    const reportUrl = `${getAppBaseUrl()}/trial-report/${updated.public_token}`;
    after(async () => {
      const result = await sendTrialParentReportWhatsAppNotification({
        parentName: assessment.trial!.parent_name,
        parentPhone: assessment.trial!.phone,
        studentName: assessment.trial!.student_name,
        recommendedProgram: levelResult.data?.name ?? 'Weekly Class',
        reportUrl,
      });
      if (result.success) {
        await updateAssessment(assessment.id, { report_sent_at: new Date().toISOString() }).catch((error) => {
          console.error('[TrialAssessment] Failed to mark parent report sent', error);
        });
      } else {
        console.error('[TrialAssessment] Failed to send parent trial report WA', result.error);
      }
    });

    return NextResponse.json({ ok: true, assessment: updated, reportUrl });
  } catch (error) {
    console.error('[TrialAssessment] Admin approve failed', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Gagal publish trial report.' },
      { status: 500 },
    );
  }
}
