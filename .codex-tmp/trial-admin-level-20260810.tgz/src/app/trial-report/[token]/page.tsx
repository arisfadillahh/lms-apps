import { notFound } from 'next/navigation';

import { getAssessmentByPublicToken } from '@/lib/dao/trialAssessmentsDao';
import { buildTrialParentReportContent, parseTrialRubric, type TrialParentReportContent } from '@/lib/services/trialAssessmentContent';

import TrialStoryReport from './TrialStoryReport';

export const dynamic = 'force-dynamic';

const VISIBLE_STATUSES = new Set([
  'PUBLISHED',
  'REGISTRATION_STARTED',
  'INVOICE_CREATED',
  'PAYMENT_PENDING',
  'PAID',
  'CONVERTED',
]);

function asParentContent(value: unknown, fallback: TrialParentReportContent): TrialParentReportContent {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return fallback;
  const source = value as Partial<TrialParentReportContent>;
  return {
    highlights: Array.isArray(source.highlights) ? source.highlights : fallback.highlights,
    potential: Array.isArray(source.potential) ? source.potential : fallback.potential,
    triedToday: Array.isArray(source.triedToday) ? source.triedToday : fallback.triedToday,
    strengths: Array.isArray(source.strengths) ? source.strengths : fallback.strengths,
    growthOpportunities: Array.isArray(source.growthOpportunities) ? source.growthOpportunities : fallback.growthOpportunities,
    coachMessage: typeof source.coachMessage === 'string' ? source.coachMessage : fallback.coachMessage,
    recommendationReasons: Array.isArray(source.recommendationReasons)
      ? source.recommendationReasons
      : fallback.recommendationReasons,
  };
}

export default async function TrialReportPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const assessment = await getAssessmentByPublicToken(token);
  if (!assessment || !assessment.trial || !VISIBLE_STATUSES.has(assessment.status)) {
    notFound();
  }

  const fallbackContent = buildTrialParentReportContent({
    rubric: parseTrialRubric(assessment.rubric) as any,
    quickObservations: assessment.quick_observations ?? [],
    personalizedObservation: assessment.personalized_observation,
    recommendationTags: assessment.recommendation_tags ?? [],
  });
  const content = asParentContent(assessment.parent_report_content, fallbackContent);

  return (
    <TrialStoryReport
      token={token}
      status={assessment.status}
      studentName={assessment.trial.student_name}
      parentName={assessment.trial.parent_name}
      coachName={assessment.coach?.full_name ?? assessment.trial.coach?.full_name ?? 'Coach Clevio'}
      trialMode={assessment.trial.trial_mode}
      trialDate={assessment.trial.scheduled_at}
      recommendedLevel={assessment.recommended_level?.name ?? 'Weekly Class'}
      estimatedStartDate={assessment.estimated_start_date}
      basePrice={assessment.base_price}
      finalPrice={assessment.final_price}
      discountLabel={assessment.discount_label}
      discountAmount={assessment.discount_amount}
      invoice={assessment.invoice ?? null}
      content={content}
    />
  );
}
