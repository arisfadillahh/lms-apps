# Clevio Event Manager

Separate Event Manager app for Clevio programs and public registrations.

## Runtime

- Separate app from LMS.
- Separate database from LMS.
- LMS invoice, payment, WhatsApp, and certificate integrations must go through LMS Core API/webhook only.
- Default local port: `3007`.
- Default production path: `https://lms.clev.io/event-manager`.

## Commands

```bash
npm install
npm run dev
npm run typecheck
npm run test
npm run db:migrate
npm run build
```

## Environment

```bash
EVENT_MANAGER_DATABASE_URL=postgres://event_manager:...@127.0.0.1:5437/event_manager
LMS_API_BASE_URL=https://lms.clev.io
LMS_API_TOKEN=...
LMS_WEBHOOK_SECRET=...
EVENT_MANAGER_PUBLIC_URL=https://lms.clev.io/event-manager
EVENT_MANAGER_INTERNAL_URL=http://127.0.0.1:3007/event-manager
NEXT_PUBLIC_BASE_PATH=/event-manager
FORM_ACCESS_SECRET=...
EVENT_MANAGER_JOB_TOKEN=...
```

Production must use `EVENT_MANAGER_DATABASE_URL` pointing to a database that is separate from LMS. Without a database URL, the app runs with the seeded Holiday Class demo repository for local UI/API verification only; admin mutations stay read-only in that mode.

## Maintenance jobs

Run these from cron or PM2 after deployment:

```bash
npm run jobs:run -- release-expired-reservations
npm run jobs:run -- sync-invoices
npm run jobs:run -- reconcile-batch-counters
```

All jobs require `EVENT_MANAGER_JOB_TOKEN` and call Event Manager API routes. They do not access LMS invoice tables directly.

## VPS routing

Run this app as a separate PM2 process, for example:

```bash
PORT=3007 NEXT_PUBLIC_BASE_PATH=/event-manager npm run start
```

Nginx should proxy `/event-manager` and `/event-manager/_next` to this app, while the LMS root app remains on port `3005`.
