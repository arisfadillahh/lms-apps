module.exports = {
  apps: [
    {
      name: "clevio-event-manager",
      script: "bash",
      args: "-lc 'set -a; [ -f .env ] && . ./.env; set +a; exec node_modules/next/dist/bin/next start -p 3007'",
      env: {
        NODE_ENV: "production",
        NEXT_PUBLIC_BASE_PATH: "/event-manager",
        EVENT_MANAGER_PUBLIC_URL: "https://lms.clev.io/event-manager",
        EVENT_MANAGER_INTERNAL_URL: "http://127.0.0.1:3007/event-manager"
      }
    }
  ]
};
