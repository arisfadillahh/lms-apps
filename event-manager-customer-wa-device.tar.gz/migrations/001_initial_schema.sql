create extension if not exists pgcrypto;

do $$ begin
  create type program_status as enum ('draft', 'active', 'closed', 'archived');
exception when duplicate_object then null; end $$;

do $$ begin
  create type form_access_type as enum ('public', 'code', 'token');
exception when duplicate_object then null; end $$;

do $$ begin
  create type form_status as enum ('draft', 'active', 'closed', 'archived');
exception when duplicate_object then null; end $$;

do $$ begin
  create type registration_status as enum (
    'pending_invoice',
    'invoice_failed',
    'waiting_payment',
    'paid',
    'confirmed',
    'expired',
    'cancelled',
    'completed'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type slot_status as enum ('reserved', 'confirmed', 'released', 'expired', 'cancelled');
exception when duplicate_object then null; end $$;

do $$ begin
  create type device_order_status as enum ('pending_payment', 'fulfillment_needed', 'processing', 'delivered', 'cancelled');
exception when duplicate_object then null; end $$;

create table if not exists programs (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  period_start date not null,
  period_end date not null,
  mode text not null,
  platform text,
  default_session_duration_minutes integer not null default 90,
  default_quota_per_batch integer not null default 10,
  registration_cutoff_rule text,
  has_levels boolean not null default true,
  has_bundling boolean not null default true,
  has_addons boolean not null default true,
  has_pitching_day boolean not null default false,
  has_certificates boolean not null default false,
  has_livestream_permission boolean not null default true,
  admin_notes text,
  status program_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists program_levels (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  code text not null,
  name text not null,
  grade_min integer not null,
  grade_max integer not null,
  grade_label text not null,
  sort_order integer not null default 0,
  unique (program_id, code)
);

create table if not exists program_classes (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  level_id uuid not null references program_levels(id) on delete cascade,
  slug text not null,
  name text not null,
  software_key text not null,
  requires_device boolean not null default false,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  unique (program_id, slug)
);

create table if not exists program_packages (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  code text not null,
  name text not null,
  description text,
  min_classes integer not null default 1,
  max_classes integer not null default 1,
  same_level_only boolean not null default true,
  unique_class_required boolean not null default true,
  unique_software_required boolean not null default true,
  one_class_per_week boolean not null default false,
  selection_order text not null default 'free',
  is_active boolean not null default true,
  unique (program_id, code)
);

create table if not exists program_pricings (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  price_type text not null,
  level_id uuid not null references program_levels(id) on delete cascade,
  package_id uuid not null references program_packages(id) on delete cascade,
  price integer not null check (price >= 0),
  currency text not null default 'IDR',
  effective_from timestamptz,
  effective_until timestamptz,
  is_active boolean not null default true,
  unique (program_id, price_type, level_id, package_id)
);

create table if not exists program_addons (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  code text not null,
  name text not null,
  price integer not null check (price >= 0),
  currency text not null default 'IDR',
  applies_to_class_id uuid references program_classes(id) on delete cascade,
  selection_type text not null,
  is_required_choice boolean not null default false,
  is_active boolean not null default true,
  admin_notes text,
  unique (program_id, code)
);

create table if not exists program_forms (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  slug text not null unique,
  name text not null,
  description text,
  template_key text not null default 'multi_step_registration',
  price_type text not null,
  access_type form_access_type not null default 'public',
  access_code_hash text,
  token_hash text,
  status form_status not null default 'draft',
  starts_at timestamptz,
  ends_at timestamptz,
  max_submissions integer,
  success_title text,
  success_message text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists program_form_steps (
  id uuid primary key default gen_random_uuid(),
  form_id uuid not null references program_forms(id) on delete cascade,
  step_key text not null,
  title text not null,
  description text,
  admin_review_notes text,
  sort_order integer not null default 0,
  visibility_json jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  unique (form_id, step_key)
);

create table if not exists program_form_fields (
  id uuid primary key default gen_random_uuid(),
  form_id uuid not null references program_forms(id) on delete cascade,
  step_key text not null,
  field_key text not null,
  label text not null,
  help_text text,
  placeholder text,
  field_type text not null,
  is_required boolean not null default false,
  default_value_json jsonb,
  options_json jsonb not null default '[]'::jsonb,
  validation_json jsonb not null default '{}'::jsonb,
  visibility_json jsonb not null default '{}'::jsonb,
  ui_json jsonb not null default '{}'::jsonb,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  unique (form_id, field_key)
);

create table if not exists form_access_tokens (
  id uuid primary key default gen_random_uuid(),
  form_id uuid not null references program_forms(id) on delete cascade,
  token_hash text,
  code_hash text,
  label text,
  max_uses integer,
  used_count integer not null default 0,
  starts_at timestamptz,
  expires_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists program_batches (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  class_id uuid not null references program_classes(id) on delete cascade,
  batch_code text not null,
  week_no integer not null,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  timezone text not null default 'Asia/Jakarta',
  quota integer not null check (quota >= 0),
  reserved_count integer not null default 0,
  confirmed_count integer not null default 0,
  status text not null default 'open',
  unique (program_id, batch_code)
);

create table if not exists program_sessions (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references program_batches(id) on delete cascade,
  session_no integer not null,
  title text,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  duration_minutes integer not null default 90,
  meeting_platform text,
  meeting_url text,
  unique (batch_id, session_no)
);

create table if not exists registrations (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete restrict,
  form_id uuid not null references program_forms(id) on delete restrict,
  external_reference text not null unique,
  parent_name text not null,
  parent_whatsapp text not null,
  parent_email text,
  student_name text not null,
  student_grade_raw text not null,
  student_grade_normalized text not null,
  student_school text,
  level_id uuid not null references program_levels(id) on delete restrict,
  package_id uuid not null references program_packages(id) on delete restrict,
  livestream_permission boolean,
  policy_agreed_at timestamptz,
  status registration_status not null default 'pending_invoice',
  payment_status text not null default 'pending_invoice',
  reservation_expires_at timestamptz,
  subtotal integer not null default 0,
  addon_total integer not null default 0,
  total integer not null default 0,
  currency text not null default 'IDR',
  invoice_error_message text,
  invoice_retryable boolean not null default false,
  admin_notes text,
  submitted_at timestamptz not null default now(),
  confirmed_at timestamptz,
  cancelled_at timestamptz,
  expired_at timestamptz
);

create table if not exists registration_items (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null references registrations(id) on delete cascade,
  program_class_id uuid not null references program_classes(id) on delete restrict,
  program_batch_id uuid not null references program_batches(id) on delete restrict,
  week_no integer not null,
  item_name text not null,
  qty integer not null default 1,
  unit_price integer not null default 0,
  line_total integer not null default 0,
  slot_status slot_status not null default 'reserved',
  reserved_at timestamptz,
  confirmed_at timestamptz,
  released_at timestamptz
);

create table if not exists registration_addons (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null references registrations(id) on delete cascade,
  program_addon_id uuid not null references program_addons(id) on delete restrict,
  program_class_id uuid references program_classes(id) on delete restrict,
  choice text not null,
  qty integer not null default 1,
  unit_price integer not null default 0,
  line_total integer not null default 0
);

create table if not exists invoice_references (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null references registrations(id) on delete cascade,
  external_reference text not null unique,
  lms_invoice_id text not null,
  invoice_number text,
  payment_link text,
  short_payment_link text,
  status text not null,
  amount integer not null default 0,
  expired_at timestamptz,
  paid_at timestamptz,
  last_synced_at timestamptz,
  admin_notes text,
  raw_response_json jsonb not null default '{}'::jsonb
);

create table if not exists webhook_logs (
  id uuid primary key default gen_random_uuid(),
  source text not null,
  event_type text not null,
  event_id text,
  external_reference text,
  payload_json jsonb not null,
  signature_valid boolean not null default false,
  processing_status text not null default 'received',
  error_message text,
  received_at timestamptz not null default now(),
  processed_at timestamptz
);

create table if not exists form_submission_events (
  id uuid primary key default gen_random_uuid(),
  program_id uuid references programs(id) on delete cascade,
  form_id uuid references program_forms(id) on delete cascade,
  registration_id uuid references registrations(id) on delete set null,
  session_id text,
  event_type text not null,
  step_key text,
  ip_address inet,
  user_agent text,
  metadata_json jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now()
);

create table if not exists device_orders (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null references registrations(id) on delete cascade,
  registration_addon_id uuid not null references registration_addons(id) on delete restrict,
  device_type text not null,
  status device_order_status not null default 'fulfillment_needed',
  fulfillment_notes text,
  admin_notes text,
  delivered_at timestamptz
);

create table if not exists pitching_day_entries (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  registration_id uuid references registrations(id) on delete cascade,
  student_name text not null,
  project_title text,
  entry_status text not null default 'pending',
  schedule_at timestamptz,
  notes text
);

create table if not exists certificates (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  registration_id uuid references registrations(id) on delete cascade,
  template_id uuid,
  template_key text,
  template_version integer,
  certificate_number text,
  lms_certificate_id text,
  status text not null default 'pending',
  generated_at timestamptz,
  sent_at timestamptz,
  issued_at date,
  download_url text,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  raw_response_json jsonb not null default '{}'::jsonb
);

create unique index if not exists idx_certificates_registration_unique
  on certificates(registration_id)
  where registration_id is not null;

create unique index if not exists idx_certificates_number_unique
  on certificates(certificate_number)
  where certificate_number is not null;

create table if not exists reconciliation_logs (
  id uuid primary key default gen_random_uuid(),
  job_name text not null,
  status text not null,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  summary_json jsonb not null default '{}'::jsonb,
  error_message text
);

create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_type text not null default 'admin',
  admin_id text,
  action text not null,
  entity_type text not null,
  entity_id text,
  old_value_json jsonb,
  new_value_json jsonb,
  reason text,
  ip_address inet,
  user_agent text,
  created_at timestamptz not null default now()
);

create table if not exists integration_logs (
  id uuid primary key default gen_random_uuid(),
  integration text not null,
  action text not null,
  registration_id uuid references registrations(id) on delete set null,
  invoice_reference_id uuid references invoice_references(id) on delete set null,
  status text not null,
  request_json jsonb,
  response_json jsonb,
  error_message text,
  created_at timestamptz not null default now()
);

create index if not exists idx_program_levels_program on program_levels(program_id);
create index if not exists idx_program_classes_program_level on program_classes(program_id, level_id);
create index if not exists idx_program_batches_class_week_status on program_batches(class_id, week_no, status);
create index if not exists idx_program_sessions_batch on program_sessions(batch_id, session_no);
create index if not exists idx_program_forms_program_status on program_forms(program_id, status, is_active);
create index if not exists idx_form_access_tokens_form on form_access_tokens(form_id, is_active);
create index if not exists idx_registrations_form_status on registrations(form_id, status);
create index if not exists idx_registrations_payment on registrations(payment_status, reservation_expires_at);
create index if not exists idx_registration_items_batch_status on registration_items(program_batch_id, slot_status);
create index if not exists idx_registration_items_registration on registration_items(registration_id);
create index if not exists idx_invoice_refs_status on invoice_references(status, last_synced_at);
create index if not exists idx_invoice_refs_external_reference on invoice_references(external_reference);
create index if not exists idx_webhook_logs_event on webhook_logs(source, event_id);
create index if not exists idx_form_events_form_event on form_submission_events(form_id, event_type, occurred_at);
create index if not exists idx_reconciliation_logs_job on reconciliation_logs(job_name, started_at desc);
create index if not exists idx_audit_logs_entity on audit_logs(entity_type, entity_id, created_at desc);
