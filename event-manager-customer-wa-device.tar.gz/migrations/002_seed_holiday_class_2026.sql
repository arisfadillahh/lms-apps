do $$
declare
  v_program uuid;
  v_explorer uuid;
  v_creator uuid;
  v_innovator uuid;
  v_single uuid;
  v_bundle uuid;
  v_public_form uuid;
  v_alpha_form uuid;
  v_class record;
  v_schedule record;
  v_batch uuid;
  v_week integer;
  v_session integer;
  v_start timestamptz;
begin
  insert into programs (
    slug,
    name,
    period_start,
    period_end,
    mode,
    platform,
    default_session_duration_minutes,
    default_quota_per_batch,
    registration_cutoff_rule,
    has_levels,
    has_bundling,
    has_addons,
    has_pitching_day,
    has_certificates,
    has_livestream_permission,
    admin_notes,
    status
  )
  values (
    'holiday-class-clevio-2026',
    'Holiday Class Clevio 2026',
    date '2026-06-15',
    date '2026-07-05',
    'online',
    'Zoom',
    90,
    10,
    'registration_open_until_h_minus_1_if_slot_available',
    true,
    true,
    true,
    true,
    true,
    true,
    null,
    'active'
  )
  on conflict (slug) do update set
    name = excluded.name,
    period_start = excluded.period_start,
    period_end = excluded.period_end,
    admin_notes = excluded.admin_notes,
    status = excluded.status
  returning id into v_program;

  insert into program_levels (program_id, code, name, grade_min, grade_max, grade_label, sort_order)
  values
    (v_program, 'explorer', 'Explorer', 1, 3, 'Kelas 1-3 SD', 1)
  on conflict (program_id, code) do update set name = excluded.name returning id into v_explorer;

  insert into program_levels (program_id, code, name, grade_min, grade_max, grade_label, sort_order)
  values
    (v_program, 'creator', 'Creator', 4, 6, 'Kelas 4-6 SD', 2)
  on conflict (program_id, code) do update set name = excluded.name returning id into v_creator;

  insert into program_levels (program_id, code, name, grade_min, grade_max, grade_label, sort_order)
  values
    (v_program, 'innovator', 'Innovator', 7, 12, 'Kelas 7 SMP-12 SMA', 3)
  on conflict (program_id, code) do update set name = excluded.name returning id into v_innovator;

  insert into program_classes (program_id, level_id, slug, name, software_key, requires_device, sort_order)
  values
    (v_program, v_explorer, 'kodu', 'Kodu', 'kodu', false, 1),
    (v_program, v_explorer, 'scratch-jr', 'Scratch Jr.', 'scratch_jr', false, 2),
    (v_program, v_explorer, 'minecraft-builder', 'Minecraft Builder', 'minecraft_builder', false, 3),
    (v_program, v_creator, 'minecraft-coding', 'Minecraft Coding', 'minecraft_coding', false, 1),
    (v_program, v_creator, 'microbit', 'Microbit', 'microbit', true, 2),
    (v_program, v_creator, 'app-inventor', 'App Inventor', 'app_inventor', false, 3),
    (v_program, v_innovator, 'blender-3d', 'Blender 3D', 'blender_3d', false, 1),
    (v_program, v_innovator, 'vibe-coding', 'Vibe Coding', 'vibe_coding', false, 2),
    (v_program, v_innovator, 'n8n-automation', 'n8n Automation', 'n8n_automation', false, 3),
    (v_program, v_innovator, 'arduino', 'Arduino', 'arduino', true, 4)
  on conflict (program_id, slug) do update set
    level_id = excluded.level_id,
    name = excluded.name,
    software_key = excluded.software_key,
    requires_device = excluded.requires_device,
    sort_order = excluded.sort_order;

  insert into program_packages (program_id, code, name, description, min_classes, max_classes, same_level_only, unique_class_required, unique_software_required, one_class_per_week, selection_order)
  values (
    v_program,
    'single',
    'Single Class',
    '1 kelas dan 1 software, durasi 3 hari belajar.',
    1,
    1,
    true,
    true,
    true,
    false,
    'single'
  )
  on conflict (program_id, code) do update set name = excluded.name, description = excluded.description returning id into v_single;

  insert into program_packages (program_id, code, name, description, min_classes, max_classes, same_level_only, unique_class_required, unique_software_required, one_class_per_week, selection_order)
  values (
    v_program,
    'bundling',
    'Bundling Journey',
    '3 kelas + 3 software berbeda, total 9 hari belajar.',
    3,
    3,
    true,
    true,
    true,
    true,
    'free'
  )
  on conflict (program_id, code) do update set name = excluded.name, description = excluded.description returning id into v_bundle;

  insert into program_pricings (program_id, price_type, level_id, package_id, price)
  values
    (v_program, 'normal', v_explorer, v_single, 350000),
    (v_program, 'normal', v_explorer, v_bundle, 900000),
    (v_program, 'normal', v_creator, v_single, 425000),
    (v_program, 'normal', v_creator, v_bundle, 1100000),
    (v_program, 'normal', v_innovator, v_single, 500000),
    (v_program, 'normal', v_innovator, v_bundle, 1300000),
    (v_program, 'alpha_omega', v_explorer, v_single, 325000),
    (v_program, 'alpha_omega', v_explorer, v_bundle, 900000),
    (v_program, 'alpha_omega', v_creator, v_single, 400000),
    (v_program, 'alpha_omega', v_creator, v_bundle, 1100000),
    (v_program, 'alpha_omega', v_innovator, v_single, 450000),
    (v_program, 'alpha_omega', v_innovator, v_bundle, 1300000)
  on conflict (program_id, price_type, level_id, package_id) do update set price = excluded.price;

  insert into program_addons (program_id, code, name, price, applies_to_class_id, selection_type, is_required_choice, admin_notes)
  select v_program, 'microbit_device', 'Device Microbit', 300000, id, 'own_or_buy', true, 'Aktif hanya setelah pembayaran paid/confirmed.'
  from program_classes where program_id = v_program and slug = 'microbit'
  on conflict (program_id, code) do update set price = excluded.price, applies_to_class_id = excluded.applies_to_class_id;

  insert into program_addons (program_id, code, name, price, applies_to_class_id, selection_type, is_required_choice, admin_notes)
  select v_program, 'arduino_device', 'Device Arduino', 350000, id, 'simulator_own_or_buy', true, 'Aktif hanya setelah pembayaran paid/confirmed.'
  from program_classes where program_id = v_program and slug = 'arduino'
  on conflict (program_id, code) do update set price = excluded.price, applies_to_class_id = excluded.applies_to_class_id;

  insert into program_forms (
    program_id,
    slug,
    name,
    description,
    price_type,
    access_type,
    status,
    max_submissions,
    success_title,
    success_message,
    is_active
  )
  values (
    v_program,
    'holiday-class-2026',
    'Pendaftaran Holiday Class Clevio 2026',
    'Form pendaftaran publik untuk Holiday Class Clevio 2026.',
    'normal',
    'public',
    'active',
    null,
    'Invoice berhasil dibuat',
    'Silakan lanjutkan pembayaran melalui link invoice.',
    true
  )
  on conflict (slug) do update set name = excluded.name, price_type = excluded.price_type, access_type = excluded.access_type, status = excluded.status
  returning id into v_public_form;

  insert into program_forms (
    program_id,
    slug,
    name,
    description,
    price_type,
    access_type,
    access_code_hash,
    status,
    max_submissions,
    success_title,
    success_message,
    is_active
  )
  values (
    v_program,
    'holiday-class-alpha-omega-2026',
    'Pendaftaran Alpha Omega Holiday Class Clevio 2026',
    'Form khusus Alpha Omega. Akses wajib menggunakan kode/token valid.',
    'alpha_omega',
    'code',
    encode(digest('AO2026', 'sha256'), 'hex'),
    'active',
    null,
    'Invoice Alpha Omega berhasil dibuat',
    'Silakan lanjutkan pembayaran melalui link invoice.',
    true
  )
  on conflict (slug) do update set name = excluded.name, price_type = excluded.price_type, access_type = excluded.access_type, access_code_hash = excluded.access_code_hash, status = excluded.status
  returning id into v_alpha_form;

  insert into form_access_tokens (form_id, code_hash, label, is_active)
  values (v_alpha_form, encode(digest('AO2026', 'sha256'), 'hex'), 'Default Alpha Omega 2026 code', true);

  foreach v_public_form in array array[v_public_form, v_alpha_form]
  loop
    insert into program_form_steps (form_id, step_key, title, description, admin_review_notes, sort_order)
    values
      (v_public_form, 'parent', 'Data Orang Tua', 'Kontak utama untuk invoice dan WhatsApp.', null, 1),
      (v_public_form, 'student', 'Data Anak', 'Grade anak digunakan untuk menentukan level kelas.', null, 2),
      (v_public_form, 'package', 'Pilih Paket', 'Pilih Single Class atau Bundling Journey.', null, 3),
      (v_public_form, 'schedule', 'Pilih Jadwal', 'Pilih jadwal yang masih tersedia sesuai kuota.', null, 4),
      (v_public_form, 'addons', 'Device/Add-on', 'Pilihan device muncul sesuai kelas yang dipilih.', null, 5),
      (v_public_form, 'agreement', 'Izin & Persetujuan', 'Konfirmasi izin livestream dan kebijakan program.', null, 6),
      (v_public_form, 'summary', 'Ringkasan', 'Periksa ulang data sebelum daftar.', null, 7)
    on conflict (form_id, step_key) do update set
      title = excluded.title,
      description = excluded.description,
      admin_review_notes = excluded.admin_review_notes,
      sort_order = excluded.sort_order;

    insert into program_form_fields (form_id, step_key, field_key, label, field_type, is_required, sort_order)
    values
      (v_public_form, 'parent', 'parent_name', 'Nama Orang Tua', 'text', true, 1),
      (v_public_form, 'parent', 'parent_whatsapp', 'Nomor WhatsApp', 'tel', true, 2),
      (v_public_form, 'parent', 'parent_email', 'Email', 'email', true, 3),
      (v_public_form, 'student', 'student_name', 'Nama Anak', 'text', true, 1),
      (v_public_form, 'student', 'student_grade_raw', 'Kelas Anak', 'select', true, 2),
      (v_public_form, 'student', 'student_school', 'Asal Sekolah', 'text', false, 3),
      (v_public_form, 'agreement', 'livestream_permission', 'Izin dokumentasi/livestream', 'radio', true, 1),
      (v_public_form, 'agreement', 'policy_agreement', 'Persetujuan kebijakan program', 'checkbox_group', true, 2)
    on conflict (form_id, field_key) do update set
      label = excluded.label,
      field_type = excluded.field_type,
      is_required = excluded.is_required,
      sort_order = excluded.sort_order;
  end loop;

  for v_schedule in
    select *
    from (values
      (1, 'kodu', date '2026-06-16', date '2026-06-18', time '10:00', time '11:30'),
      (1, 'scratch-jr', date '2026-06-18', date '2026-06-20', time '10:00', time '11:30'),
      (1, 'minecraft-builder', date '2026-06-15', date '2026-06-17', time '10:00', time '11:30'),
      (1, 'minecraft-coding', date '2026-06-15', date '2026-06-17', time '10:00', time '11:30'),
      (1, 'microbit', date '2026-06-18', date '2026-06-20', time '12:30', time '14:00'),
      (1, 'app-inventor', date '2026-06-15', date '2026-06-17', time '10:00', time '11:30'),
      (1, 'blender-3d', date '2026-06-15', date '2026-06-17', time '10:00', time '11:30'),
      (1, 'vibe-coding', date '2026-06-15', date '2026-06-17', time '12:30', time '14:00'),
      (1, 'n8n-automation', date '2026-06-15', date '2026-06-17', time '12:30', time '14:00'),
      (1, 'arduino', date '2026-06-18', date '2026-06-20', time '12:30', time '14:00'),
      (2, 'kodu', date '2026-06-23', date '2026-06-25', time '12:30', time '14:00'),
      (2, 'scratch-jr', date '2026-06-23', date '2026-06-25', time '10:00', time '11:30'),
      (2, 'minecraft-builder', date '2026-06-25', date '2026-06-27', time '10:00', time '11:30'),
      (2, 'minecraft-coding', date '2026-06-25', date '2026-06-27', time '12:30', time '14:00'),
      (2, 'microbit', date '2026-06-23', date '2026-06-25', time '10:00', time '11:30'),
      (2, 'app-inventor', date '2026-06-22', date '2026-06-24', time '10:00', time '11:30'),
      (2, 'blender-3d', date '2026-06-23', date '2026-06-25', time '10:00', time '11:30'),
      (2, 'vibe-coding', date '2026-06-25', date '2026-06-27', time '12:30', time '14:00'),
      (2, 'n8n-automation', date '2026-06-22', date '2026-06-24', time '12:30', time '14:00'),
      (2, 'arduino', date '2026-06-22', date '2026-06-24', time '12:30', time '14:00'),
      (3, 'kodu', date '2026-06-29', date '2026-07-01', time '10:00', time '11:30'),
      (3, 'scratch-jr', date '2026-06-29', date '2026-07-01', time '10:00', time '11:30'),
      (3, 'minecraft-builder', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30'),
      (3, 'minecraft-coding', date '2026-06-29', date '2026-07-01', time '12:30', time '14:00'),
      (3, 'microbit', date '2026-06-29', date '2026-07-01', time '12:30', time '14:00'),
      (3, 'app-inventor', date '2026-06-30', date '2026-07-02', time '12:30', time '14:00'),
      (3, 'blender-3d', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30'),
      (3, 'vibe-coding', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30'),
      (3, 'n8n-automation', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30'),
      (3, 'arduino', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30')
    ) as schedule(week_no, class_slug, start_date, end_date, start_time, end_time)
  loop
      select *
      into v_class
      from program_classes
      where program_id = v_program and slug = v_schedule.class_slug;

      v_start := ((v_schedule.start_date + v_schedule.start_time) at time zone 'Asia/Jakarta');

      insert into program_batches (
        program_id,
        class_id,
        batch_code,
        week_no,
        starts_at,
        ends_at,
        quota,
        status
      )
      values (
        v_program,
        v_class.id,
        upper(replace(v_class.slug, '-', '_')) || '-W' || v_schedule.week_no,
        v_schedule.week_no,
        v_start,
        ((v_schedule.end_date + v_schedule.end_time) at time zone 'Asia/Jakarta'),
        10,
        'open'
      )
      on conflict (program_id, batch_code) do update set
        starts_at = excluded.starts_at,
        ends_at = excluded.ends_at,
        quota = excluded.quota,
        status = excluded.status
      returning id into v_batch;

      for v_session in 1..3 loop
        insert into program_sessions (
          batch_id,
          session_no,
          title,
          starts_at,
          ends_at,
          duration_minutes,
          meeting_platform
        )
        values (
          v_batch,
          v_session,
          'Sesi ' || v_session,
          (((v_schedule.start_date + (v_session - 1)) + v_schedule.start_time) at time zone 'Asia/Jakarta'),
          (((v_schedule.start_date + (v_session - 1)) + v_schedule.end_time) at time zone 'Asia/Jakarta'),
          90,
          'Zoom'
        )
        on conflict (batch_id, session_no) do update set
          starts_at = excluded.starts_at,
          ends_at = excluded.ends_at,
          duration_minutes = excluded.duration_minutes,
          meeting_platform = excluded.meeting_platform;
      end loop;
  end loop;
end $$;
