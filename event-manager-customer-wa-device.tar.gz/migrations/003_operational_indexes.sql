create unique index if not exists idx_device_orders_registration_addon_unique
  on device_orders(registration_addon_id);

create index if not exists idx_registrations_reservation_cleanup
  on registrations(reservation_expires_at)
  where status in ('pending_invoice', 'waiting_payment');

create index if not exists idx_form_events_access_rate_limit
  on form_submission_events(form_id, ip_address, event_type, occurred_at desc)
  where event_type in ('access_failed', 'access_rate_limited');

create index if not exists idx_invoice_refs_lms_invoice_id
  on invoice_references(lms_invoice_id);

create index if not exists idx_device_orders_status
  on device_orders(status);
