alter table programs
  add column if not exists description text,
  add column if not exists registration_open_at timestamptz,
  add column if not exists registration_close_at timestamptz,
  add column if not exists registration_deadline_rule text,
  add column if not exists no_minimum_participant boolean not null default false,
  add column if not exists has_packages boolean not null default true,
  add column if not exists has_schedule_selection boolean not null default true,
  add column if not exists has_attendance boolean not null default false,
  add column if not exists has_whatsapp_automation boolean not null default true;

update programs
set registration_deadline_rule = coalesce(registration_deadline_rule, registration_cutoff_rule)
where registration_deadline_rule is null;

update programs
set
  description = coalesce(description, 'Program liburan online Clevio yang fleksibel untuk single class dan bundling journey.'),
  registration_open_at = coalesce(registration_open_at, '2026-06-01 00:00:00+07'::timestamptz),
  registration_close_at = coalesce(registration_close_at, '2026-07-04 23:59:59+07'::timestamptz),
  registration_deadline_rule = coalesce(registration_deadline_rule, 'H-1 sebelum kelas dimulai selama slot tersedia'),
  no_minimum_participant = true,
  has_packages = true,
  has_schedule_selection = true,
  has_attendance = true,
  has_whatsapp_automation = true
where slug = 'holiday-class-clevio-2026';

do $$
begin
  alter type device_order_status add value if not exists 'pending';
  alter type device_order_status add value if not exists 'prepared';
  alter type device_order_status add value if not exists 'picked_up';
exception
  when undefined_object then null;
end $$;

alter table program_levels
  add column if not exists description text,
  add column if not exists is_active boolean not null default true;

alter table program_classes
  add column if not exists description text,
  add column if not exists output_description text,
  add column if not exists requirements text,
  add column if not exists device_requirement_setting text not null default 'none';

update program_classes
set
  description = case slug
    when 'minecraft-builder' then 'Kelas creative building dan desain dunia Minecraft, bukan kelas coding.'
    when 'minecraft-coding' then 'Kelas coding dengan pendekatan Minecraft untuk membuat logika dan interaksi.'
    when 'microbit' then 'Kelas physical computing dengan device Microbit. Peserta dapat memakai device sendiri atau membeli dari Clevio.'
    when 'arduino' then 'Kelas dasar Arduino; peserta dapat memakai simulator, device sendiri, atau membeli device dari Clevio.'
    when 'blender-3d' then 'Kelas pengenalan modeling 3D dan workflow visual di Blender.'
    else coalesce(description, 'Kelas Holiday Class Clevio.')
  end,
  output_description = case slug
    when 'minecraft-builder' then 'Peserta membuat karya dunia Minecraft yang rapi dan siap dipresentasikan.'
    when 'minecraft-coding' then 'Peserta membuat interaksi sederhana berbasis logika coding.'
    when 'microbit' then 'Peserta membuat project device interaktif dengan Microbit.'
    when 'arduino' then 'Peserta membuat simulasi atau project Arduino dasar.'
    when 'blender-3d' then 'Peserta membuat model 3D sederhana.'
    else coalesce(output_description, 'Peserta menghasilkan karya digital sesuai kelas.')
  end,
  requirements = case slug
    when 'microbit' then 'Device Microbit sendiri atau beli dari Clevio.'
    when 'arduino' then 'Simulator, device Arduino sendiri, atau beli dari Clevio.'
    when 'blender-3d' then 'CPU: Ryzen 5 5000 / Intel Core i5 gen 10
GPU: Nvidia GTX/RTX series / AMD Radeon 5500 atau 5700 series (direkomendasikan VRAM 6/8GB)
RAM: DDR4/5 8GB (direkomendasikan 12/16GB)'
    else coalesce(requirements, 'Laptop/tablet yang mendukung Zoom dan koneksi internet stabil.')
  end,
  device_requirement_setting = case slug
    when 'microbit' then 'required_own_or_buy'
    when 'arduino' then 'optional_simulator_own_or_buy'
    else 'none'
  end
where program_id in (select id from programs where slug = 'holiday-class-clevio-2026');

alter table program_packages
  add column if not exists required_week_count integer,
  add column if not exists allow_custom_selection boolean not null default true;

update program_packages
set
  required_week_count = case code when 'bundling' then 3 else 1 end,
  allow_custom_selection = true
where program_id in (select id from programs where slug = 'holiday-class-clevio-2026');

alter table program_pricings
  add column if not exists last_edited_by_admin text,
  add column if not exists updated_at timestamptz not null default now();

alter table program_addons
  add column if not exists description text,
  add column if not exists choices_json jsonb not null default '[]'::jsonb,
  add column if not exists is_active boolean not null default true;

update program_addons
set
  description = case code
    when 'microbit_device' then 'Device Microbit untuk kelas Microbit. Dibeli hanya jika peserta belum punya device sendiri.'
    when 'arduino_device' then 'Device Arduino opsional. Peserta juga bisa memakai simulator atau device sendiri.'
    else description
  end,
  choices_json = case code
    when 'microbit_device' then '[{"value":"own","label":"Saya sudah punya device Microbit sendiri"},{"value":"buy","label":"Saya ingin membeli device Microbit dari Clevio","price":300000}]'::jsonb
    when 'arduino_device' then '[{"value":"simulator","label":"Tanpa device, menggunakan simulator"},{"value":"own","label":"Saya sudah punya device Arduino sendiri"},{"value":"buy","label":"Saya ingin membeli device Arduino dari Clevio","price":350000}]'::jsonb
    else choices_json
  end
where program_id in (select id from programs where slug = 'holiday-class-clevio-2026');

alter table program_batches
  add column if not exists level_id uuid references program_levels(id) on delete set null,
  add column if not exists batch_name text,
  add column if not exists notes text;

update program_batches b
set level_id = c.level_id
from program_classes c
where b.class_id = c.id and b.level_id is null;

update program_batches
set
  batch_name = coalesce(batch_name, batch_code),
  notes = coalesce(notes, 'Initial Holiday Class schedule seed. Admin dapat edit, tutup, duplicate, atau mengganti jadwal ini.')
where program_id in (select id from programs where slug = 'holiday-class-clevio-2026');

alter table program_sessions
  add column if not exists meeting_location text,
  add column if not exists notes text;

alter table invoice_references
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

create table if not exists payment_status_events (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid references registrations(id) on delete cascade,
  invoice_reference_id uuid references invoice_references(id) on delete cascade,
  external_reference text,
  old_status text,
  new_status text not null,
  source text not null default 'lms',
  amount integer,
  event_at timestamptz not null default now(),
  raw_payload_json jsonb not null default '{}'::jsonb
);

create table if not exists whatsapp_logs (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid references registrations(id) on delete set null,
  invoice_reference_id uuid references invoice_references(id) on delete set null,
  message_type text not null,
  recipient text not null,
  message_preview text,
  lms_response_json jsonb,
  status text not null default 'pending',
  error_message text,
  created_at timestamptz not null default now()
);

create table if not exists attendance_sessions (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  batch_id uuid references program_batches(id) on delete cascade,
  program_session_id uuid references program_sessions(id) on delete cascade,
  title text not null,
  session_type text not null default 'class',
  starts_at timestamptz,
  ends_at timestamptz,
  status text not null default 'draft',
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists attendance_records (
  id uuid primary key default gen_random_uuid(),
  attendance_session_id uuid not null references attendance_sessions(id) on delete cascade,
  registration_id uuid not null references registrations(id) on delete cascade,
  status text not null default 'present',
  notes text,
  checked_in_at timestamptz,
  checked_by_admin text,
  unique (attendance_session_id, registration_id)
);

create table if not exists certificate_templates (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  template_key text not null,
  name text not null,
  template_version integer not null default 1,
  background_url text,
  preview_image_url text,
  layout_json jsonb not null default '{}'::jsonb,
  variables_json jsonb not null default '[]'::jsonb,
  is_active boolean not null default true,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (program_id, template_key)
);

create table if not exists admin_users (
  id uuid primary key default gen_random_uuid(),
  lms_admin_id text unique,
  display_name text,
  email text,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists admin_roles (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  permissions_json jsonb not null default '[]'::jsonb
);

create table if not exists admin_user_roles (
  admin_user_id uuid not null references admin_users(id) on delete cascade,
  admin_role_id uuid not null references admin_roles(id) on delete cascade,
  primary key (admin_user_id, admin_role_id)
);

create index if not exists idx_payment_events_registration on payment_status_events(registration_id, event_at desc);
create index if not exists idx_whatsapp_logs_registration on whatsapp_logs(registration_id, created_at desc);
create index if not exists idx_whatsapp_logs_type_status on whatsapp_logs(message_type, status, created_at desc);
create index if not exists idx_attendance_sessions_program on attendance_sessions(program_id, starts_at desc);
create index if not exists idx_attendance_records_registration on attendance_records(registration_id);
create index if not exists idx_program_batches_level_week on program_batches(program_id, level_id, week_no);

insert into admin_roles (code, name, permissions_json)
values
  ('owner', 'Owner', '["*"]'::jsonb),
  ('event_ops', 'Event Operations', '["program:read","form:manage","schedule:manage","registration:manage","invoice:manage","device:manage","analytics:read"]'::jsonb)
on conflict (code) do nothing;
