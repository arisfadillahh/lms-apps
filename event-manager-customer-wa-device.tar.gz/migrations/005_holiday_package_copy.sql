update program_packages
set description = '1 kelas dan 1 software, durasi 3 hari belajar.'
where code = 'single'
  and program_id in (select id from programs where slug = 'holiday-class-clevio-2026');

update program_packages
set description = '3 kelas + 3 software berbeda, total 9 hari belajar.'
where code = 'bundling'
  and program_id in (select id from programs where slug = 'holiday-class-clevio-2026');
