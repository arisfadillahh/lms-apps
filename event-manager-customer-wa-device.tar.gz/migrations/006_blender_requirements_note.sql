update programs
set admin_notes = null
where slug = 'holiday-class-clevio-2026'
  and admin_notes ilike '%Minimum spec laptop%';

update program_form_steps
set
  description = 'Periksa ulang data sebelum daftar.',
  admin_review_notes = null
where step_key = 'summary'
  and form_id in (
    select id
    from program_forms
    where program_id in (select id from programs where slug = 'holiday-class-clevio-2026')
  )
  and coalesce(admin_review_notes, '') ilike '%Blender disarankan RAM 8GB%';

update program_classes
set requirements = null
where program_id in (select id from programs where slug = 'holiday-class-clevio-2026')
  and requirements = 'Laptop/tablet yang mendukung Zoom dan koneksi internet stabil.';

update program_classes
set requirements = 'CPU: Ryzen 5 5000 / Intel Core i5 gen 10
GPU: Nvidia GTX/RTX series / AMD Radeon 5500 atau 5700 series (direkomendasikan VRAM 6/8GB)
RAM: DDR4/5 8GB (direkomendasikan 12/16GB)'
where slug = 'blender-3d'
  and program_id in (select id from programs where slug = 'holiday-class-clevio-2026');
