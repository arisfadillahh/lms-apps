do $$
declare
  v_program uuid;
  v_class record;
  v_schedule record;
  v_batch uuid;
  v_session integer;
begin
  select id into v_program from programs where slug = 'holiday-class-clevio-2026';

  if v_program is null then
    return;
  end if;

  for v_schedule in
    select *
    from (values
      (1, 'kodu', date '2026-06-16', date '2026-06-18', time '10:00', time '11:30'),
      (1, 'scratch-jr', date '2026-06-18', date '2026-06-20', time '10:00', time '11:30'),
      (1, 'minecraft-builder', date '2026-06-15', date '2026-06-17', time '10:00', time '11:30'),
      (1, 'minecraft-coding', date '2026-06-15', date '2026-06-17', time '10:00', time '11:30'),
      (1, 'microbit', date '2026-06-18', date '2026-06-20', time '12:30', time '14:00'),
      (1, 'app-inventor', date '2026-06-15', date '2026-06-17', time '10:00', time '11:30'),
      (1, 'blender-3d', date '2026-06-15', date '2026-06-17', time '10:00', time '11:30'),
      (1, 'vibe-coding', date '2026-06-15', date '2026-06-17', time '12:30', time '14:00'),
      (1, 'n8n-automation', date '2026-06-15', date '2026-06-17', time '12:30', time '14:00'),
      (1, 'arduino', date '2026-06-18', date '2026-06-20', time '12:30', time '14:00'),
      (2, 'kodu', date '2026-06-23', date '2026-06-25', time '12:30', time '14:00'),
      (2, 'scratch-jr', date '2026-06-23', date '2026-06-25', time '10:00', time '11:30'),
      (2, 'minecraft-builder', date '2026-06-25', date '2026-06-27', time '10:00', time '11:30'),
      (2, 'minecraft-coding', date '2026-06-25', date '2026-06-27', time '12:30', time '14:00'),
      (2, 'microbit', date '2026-06-23', date '2026-06-25', time '10:00', time '11:30'),
      (2, 'app-inventor', date '2026-06-22', date '2026-06-24', time '10:00', time '11:30'),
      (2, 'blender-3d', date '2026-06-23', date '2026-06-25', time '10:00', time '11:30'),
      (2, 'vibe-coding', date '2026-06-25', date '2026-06-27', time '12:30', time '14:00'),
      (2, 'n8n-automation', date '2026-06-22', date '2026-06-24', time '12:30', time '14:00'),
      (2, 'arduino', date '2026-06-22', date '2026-06-24', time '12:30', time '14:00'),
      (3, 'kodu', date '2026-06-29', date '2026-07-01', time '10:00', time '11:30'),
      (3, 'scratch-jr', date '2026-06-29', date '2026-07-01', time '10:00', time '11:30'),
      (3, 'minecraft-builder', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30'),
      (3, 'minecraft-coding', date '2026-06-29', date '2026-07-01', time '12:30', time '14:00'),
      (3, 'microbit', date '2026-06-29', date '2026-07-01', time '12:30', time '14:00'),
      (3, 'app-inventor', date '2026-06-30', date '2026-07-02', time '12:30', time '14:00'),
      (3, 'blender-3d', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30'),
      (3, 'vibe-coding', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30'),
      (3, 'n8n-automation', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30'),
      (3, 'arduino', date '2026-06-30', date '2026-07-02', time '10:00', time '11:30')
    ) as schedule(week_no, class_slug, start_date, end_date, start_time, end_time)
  loop
    select *
    into v_class
    from program_classes
    where program_id = v_program and slug = v_schedule.class_slug;

    if not found then
      raise exception 'Holiday Class schedule class not found: %', v_schedule.class_slug;
    end if;

    insert into program_batches (
      program_id,
      class_id,
      level_id,
      batch_code,
      batch_name,
      week_no,
      starts_at,
      ends_at,
      timezone,
      quota,
      status,
      notes
    )
    values (
      v_program,
      v_class.id,
      v_class.level_id,
      upper(replace(v_class.slug, '-', '_')) || '-W' || v_schedule.week_no,
      v_class.name || ' - Week ' || v_schedule.week_no,
      v_schedule.week_no,
      ((v_schedule.start_date + v_schedule.start_time) at time zone 'Asia/Jakarta'),
      ((v_schedule.end_date + v_schedule.end_time) at time zone 'Asia/Jakarta'),
      'Asia/Jakarta',
      10,
      'open',
      'Jadwal resmi Holiday Class Juni-Juli 2026.'
    )
    on conflict (program_id, batch_code) do update set
      class_id = excluded.class_id,
      level_id = excluded.level_id,
      batch_name = excluded.batch_name,
      week_no = excluded.week_no,
      starts_at = excluded.starts_at,
      ends_at = excluded.ends_at,
      timezone = excluded.timezone,
      notes = excluded.notes
    returning id into v_batch;

    for v_session in 1..3 loop
      insert into program_sessions (
        batch_id,
        session_no,
        title,
        starts_at,
        ends_at,
        duration_minutes,
        meeting_platform,
        notes
      )
      values (
        v_batch,
        v_session,
        'Sesi ' || v_session,
        (((v_schedule.start_date + (v_session - 1)) + v_schedule.start_time) at time zone 'Asia/Jakarta'),
        (((v_schedule.start_date + (v_session - 1)) + v_schedule.end_time) at time zone 'Asia/Jakarta'),
        90,
        'Zoom',
        null
      )
      on conflict (batch_id, session_no) do update set
        title = excluded.title,
        starts_at = excluded.starts_at,
        ends_at = excluded.ends_at,
        duration_minutes = excluded.duration_minutes,
        meeting_platform = excluded.meeting_platform,
        notes = excluded.notes;
    end loop;
  end loop;

  update program_form_steps
  set description = 'Pilih kelasnya dulu, lalu tanggal mulai.'
  where step_key = 'schedule'
    and form_id in (select id from program_forms where program_id = v_program);
end $$;
