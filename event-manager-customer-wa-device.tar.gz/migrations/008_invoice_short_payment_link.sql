alter table invoice_references
  add column if not exists short_payment_link text;
