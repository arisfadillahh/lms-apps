alter table certificate_templates
  add column if not exists template_version integer not null default 1,
  add column if not exists background_url text,
  add column if not exists preview_image_url text,
  add column if not exists layout_json jsonb not null default '{}'::jsonb,
  add column if not exists notes text,
  add column if not exists updated_at timestamptz not null default now();

alter table certificates
  add column if not exists template_id uuid references certificate_templates(id) on delete set null,
  add column if not exists template_version integer,
  add column if not exists certificate_number text,
  add column if not exists sent_at timestamptz,
  add column if not exists issued_at date,
  add column if not exists error_message text,
  add column if not exists created_at timestamptz not null default now(),
  add column if not exists updated_at timestamptz not null default now();

create unique index if not exists idx_certificates_registration_unique
  on certificates(registration_id)
  where registration_id is not null;

create unique index if not exists idx_certificates_number_unique
  on certificates(certificate_number)
  where certificate_number is not null;

create index if not exists idx_certificates_program_status
  on certificates(program_id, status);

do $$
begin
  if not exists (
    select 1
    from information_schema.table_constraints
    where constraint_name = 'certificates_template_id_fkey'
      and table_name = 'certificates'
  ) then
    alter table certificates
      add constraint certificates_template_id_fkey
      foreign key (template_id) references certificate_templates(id) on delete set null;
  end if;
end $$;
