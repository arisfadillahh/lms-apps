create table if not exists partner_schools (
  id uuid primary key default gen_random_uuid(),
  program_id uuid not null references programs(id) on delete cascade,
  slug text not null,
  name text not null,
  status text not null default 'active',
  price_type text not null default 'partner_school',
  contact_name text,
  contact_whatsapp text,
  admin_notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (program_id, slug)
);

alter table form_access_tokens
  add column if not exists partner_school_id uuid references partner_schools(id) on delete set null,
  add column if not exists metadata_json jsonb not null default '{}'::jsonb;

alter table registrations
  add column if not exists partner_school_id uuid references partner_schools(id) on delete set null,
  add column if not exists partner_school_name text,
  add column if not exists partner_school_slug text;

alter table form_submission_events
  add column if not exists partner_school_id uuid references partner_schools(id) on delete set null;

create index if not exists idx_partner_schools_program_status on partner_schools(program_id, status, is_active);
create index if not exists idx_form_access_tokens_partner_school on form_access_tokens(partner_school_id);
create index if not exists idx_registrations_partner_school on registrations(partner_school_id);

do $$
declare
  v_program uuid;
  v_public_form uuid;
  v_partner_form uuid;
  v_alpha_school uuid;
  v_global_sevilla_school uuid;
begin
  select id into v_program
  from programs
  where slug = 'holiday-class-clevio-2026'
  limit 1;

  if v_program is null then
    return;
  end if;

  insert into program_pricings (program_id, price_type, level_id, package_id, price, currency, effective_from, effective_until, is_active)
  select program_id, 'partner_school', level_id, package_id, price, currency, effective_from, effective_until, is_active
  from program_pricings
  where program_id = v_program
    and price_type = 'alpha_omega'
  on conflict (program_id, price_type, level_id, package_id) do update set
    price = excluded.price,
    currency = excluded.currency,
    effective_from = excluded.effective_from,
    effective_until = excluded.effective_until,
    is_active = excluded.is_active;

  select id into v_public_form
  from program_forms
  where program_id = v_program
    and slug = 'holiday-class-2026'
  limit 1;

  insert into program_forms (
    program_id,
    slug,
    name,
    description,
    template_key,
    price_type,
    access_type,
    access_code_hash,
    status,
    max_submissions,
    success_title,
    success_message,
    is_active
  )
  values (
    v_program,
    'holiday-class-partner-2026',
    'Pendaftaran Sekolah Partner Holiday Class Clevio 2026',
    'Form penawaran khusus untuk sekolah partner Clevio. Akses wajib menggunakan kode sekolah valid.',
    'holiday_class_registration',
    'partner_school',
    'code',
    null,
    'active',
    null,
    'Invoice sekolah partner berhasil dibuat',
    'Silakan lanjutkan pembayaran melalui link invoice.',
    true
  )
  on conflict (slug) do update set
    name = excluded.name,
    description = excluded.description,
    price_type = excluded.price_type,
    access_type = excluded.access_type,
    access_code_hash = null,
    status = excluded.status,
    success_title = excluded.success_title,
    success_message = excluded.success_message,
    is_active = true,
    updated_at = now()
  returning id into v_partner_form;

  if v_public_form is not null then
    insert into program_form_steps (form_id, step_key, title, description, admin_review_notes, sort_order, visibility_json, is_active)
    select v_partner_form, step_key, title, description, admin_review_notes, sort_order, visibility_json, is_active
    from program_form_steps
    where form_id = v_public_form
    on conflict (form_id, step_key) do update set
      title = excluded.title,
      description = excluded.description,
      admin_review_notes = excluded.admin_review_notes,
      sort_order = excluded.sort_order,
      visibility_json = excluded.visibility_json,
      is_active = excluded.is_active;

    insert into program_form_fields (
      form_id,
      step_key,
      field_key,
      label,
      help_text,
      placeholder,
      field_type,
      is_required,
      default_value_json,
      options_json,
      validation_json,
      visibility_json,
      ui_json,
      sort_order,
      is_active
    )
    select
      v_partner_form,
      step_key,
      field_key,
      label,
      help_text,
      placeholder,
      field_type,
      is_required,
      default_value_json,
      options_json,
      validation_json,
      visibility_json,
      ui_json,
      sort_order,
      is_active
    from program_form_fields
    where form_id = v_public_form
    on conflict (form_id, field_key) do update set
      step_key = excluded.step_key,
      label = excluded.label,
      help_text = excluded.help_text,
      placeholder = excluded.placeholder,
      field_type = excluded.field_type,
      is_required = excluded.is_required,
      default_value_json = excluded.default_value_json,
      options_json = excluded.options_json,
      validation_json = excluded.validation_json,
      visibility_json = excluded.visibility_json,
      ui_json = excluded.ui_json,
      sort_order = excluded.sort_order,
      is_active = excluded.is_active;
  end if;

  update program_forms
  set
    name = 'Pendaftaran Sekolah Partner Holiday Class Clevio 2026',
    description = 'Link lama Alpha Omega. Gunakan form Sekolah Partner untuk sekolah kerja sama Clevio.',
    price_type = 'partner_school',
    access_type = 'code',
    access_code_hash = null,
    status = 'archived',
    is_active = false,
    updated_at = now()
  where program_id = v_program
    and slug = 'holiday-class-alpha-omega-2026';

  insert into partner_schools (program_id, slug, name, status, price_type, admin_notes, is_active)
  values
    (v_program, 'alpha-omega', 'Alpha Omega', 'active', 'partner_school', 'Sekolah partner legacy dari form AO.', true),
    (v_program, 'global-sevilla', 'Global Sevilla', 'active', 'partner_school', 'Sekolah partner Holiday Class 2026.', true)
  on conflict (program_id, slug) do update set
    name = excluded.name,
    status = excluded.status,
    price_type = excluded.price_type,
    admin_notes = excluded.admin_notes,
    is_active = excluded.is_active,
    updated_at = now();

  select id into v_alpha_school
  from partner_schools
  where program_id = v_program
    and slug = 'alpha-omega';

  select id into v_global_sevilla_school
  from partner_schools
  where program_id = v_program
    and slug = 'global-sevilla';

  insert into form_access_tokens (form_id, code_hash, label, partner_school_id, metadata_json, is_active)
  select v_partner_form, encode(digest('AO2026', 'sha256'), 'hex'), 'Alpha Omega', v_alpha_school, '{"school_slug":"alpha-omega"}'::jsonb, true
  where not exists (
    select 1 from form_access_tokens
    where form_id = v_partner_form
      and code_hash = encode(digest('AO2026', 'sha256'), 'hex')
  );

  insert into form_access_tokens (form_id, code_hash, label, partner_school_id, metadata_json, is_active)
  select v_partner_form, encode(digest('GLOBALSEVILLA2026', 'sha256'), 'hex'), 'Global Sevilla', v_global_sevilla_school, '{"school_slug":"global-sevilla"}'::jsonb, true
  where not exists (
    select 1 from form_access_tokens
    where form_id = v_partner_form
      and code_hash = encode(digest('GLOBALSEVILLA2026', 'sha256'), 'hex')
  );
end $$;
