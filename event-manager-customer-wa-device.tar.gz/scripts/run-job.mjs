import process from "node:process";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");

await loadEnvFile(path.join(root, ".env"));

const jobName = process.argv[2];
const allowed = new Set(["release-expired-reservations", "sync-invoices", "reconcile-batch-counters"]);

if (!allowed.has(jobName)) {
  console.error("Usage: npm run jobs:run -- <release-expired-reservations|sync-invoices|reconcile-batch-counters>");
  process.exit(1);
}

const baseUrl = process.env.EVENT_MANAGER_INTERNAL_URL || "http://127.0.0.1:3007/event-manager";
const token = process.env.EVENT_MANAGER_JOB_TOKEN;

if (!token) {
  console.error("EVENT_MANAGER_JOB_TOKEN is required.");
  process.exit(1);
}

const response = await fetch(`${baseUrl}/api/admin/jobs/${jobName}`, {
  method: "POST",
  headers: {
    authorization: `Bearer ${token}`,
    "content-type": "application/json"
  }
});

const body = await response.json().catch(() => ({}));
if (!response.ok) {
  console.error(JSON.stringify(body, null, 2));
  process.exit(1);
}

console.log(JSON.stringify(body, null, 2));

async function loadEnvFile(filePath) {
  try {
    const content = await fs.readFile(filePath, "utf8");
    for (const line of content.split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const separatorIndex = trimmed.indexOf("=");
      if (separatorIndex < 1) continue;
      const key = trimmed.slice(0, separatorIndex).trim();
      const value = trimmed.slice(separatorIndex + 1).trim().replace(/^["']|["']$/g, "");
      if (!process.env[key]) process.env[key] = value;
    }
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
  }
}
