import { notFound } from "next/navigation";
import { AdminDashboard } from "@/components/AdminDashboard";
import { requireAdminPage } from "@/lib/adminAuth";
import { getAdminSnapshot } from "@/lib/repository";

export const dynamic = "force-dynamic";

const sectionMap: Record<string, string> = {
  programs: "program",
  forms: "form",
  registrations: "registrasi",
  schedules: "schedule",
  classes: "classes",
  pricing: "pricing",
  addons: "addons",
  devices: "device",
  attendance: "attendance",
  pitching: "pitching",
  certificates: "certificates",
  analytics: "analytics",
  integration: "integration",
  whatsapp: "whatsapp",
  webhooks: "webhooks",
  audit: "audit"
};

export default async function AdminSectionPage({ params }: { params: Promise<{ section: string }> }) {
  await requireAdminPage();
  const { section } = await params;
  const focusSection = sectionMap[section];

  if (!focusSection) {
    notFound();
  }

  const snapshot = await getAdminSnapshot();
  return <AdminDashboard snapshot={snapshot} focusSection={focusSection} />;
}
