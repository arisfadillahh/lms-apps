import Link from "next/link";
import { Lock, ShieldCheck } from "lucide-react";
import { redirect } from "next/navigation";
import { appPath } from "@/lib/constants";
import { getAdminSession } from "@/lib/adminAuth";

export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  const session = await getAdminSession();
  if (session) {
    redirect(appPath("/admin"));
  }

  return (
    <main className="admin-login-shell">
      <section className="admin-login-card">
        <div className="brand-lockup centered">
          <span className="brand-mark">C</span>
          <div>
            <strong>Clevio</strong>
            <span>Event Manager</span>
          </div>
        </div>
        <Lock size={38} />
        <div>
          <p className="section-label">Khusus Admin</p>
          <h1>Login Admin Diperlukan</h1>
          <p>
            Dashboard Event Manager hanya bisa dibuka oleh akun admin LMS yang aktif.
            Jika belum login, masuk ke LMS dulu lalu kembali ke halaman ini.
          </p>
        </div>
        <div className="admin-login-actions">
          <a className="primary-action full" href="/login">
            <ShieldCheck size={18} />
            Masuk lewat LMS
          </a>
          <Link className="secondary-action full" href={appPath("/admin")}>
            Saya sudah login
          </Link>
        </div>
      </section>
    </main>
  );
}
