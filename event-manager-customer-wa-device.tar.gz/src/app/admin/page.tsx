import { AdminDashboard } from "@/components/AdminDashboard";
import { requireAdminPage } from "@/lib/adminAuth";
import { getAdminSnapshot } from "@/lib/repository";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  await requireAdminPage();
  const snapshot = await getAdminSnapshot();
  return <AdminDashboard snapshot={snapshot} />;
}
