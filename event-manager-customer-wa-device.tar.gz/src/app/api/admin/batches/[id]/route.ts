import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { updateProgramBatch } from "@/lib/repository";

export async function PATCH(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  try {
    const batch = await updateProgramBatch(
      id,
      {
        batchName: Object.prototype.hasOwnProperty.call(body, "batchName") ? String(body.batchName ?? "") || null : undefined,
        weekNo: Object.prototype.hasOwnProperty.call(body, "weekNo") ? Number(body.weekNo) : undefined,
        quota: Object.prototype.hasOwnProperty.call(body, "quota") ? Number(body.quota) : undefined,
        status: body.status ? String(body.status) : undefined,
        startsAt: body.startsAt ? String(body.startsAt) : undefined,
        endsAt: body.endsAt ? String(body.endsAt) : undefined
      },
      await getAdminActor(request)
    );
    if (!batch) return NextResponse.json({ ok: false, message: "Batch tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: batch });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Batch update failed" }, { status: 400 });
  }
}
