import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { createProgramBatch } from "@/lib/repository";

export async function POST(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const body = await request.json().catch(() => ({}));
  try {
    const batch = await createProgramBatch(
      {
        programId: String(body.programId ?? ""),
        classId: String(body.classId ?? ""),
        batchCode: body.batchCode ? String(body.batchCode) : undefined,
        batchName: body.batchName ? String(body.batchName) : null,
        weekNo: Number(body.weekNo ?? 1),
        startsAt: String(body.startsAt ?? ""),
        endsAt: String(body.endsAt ?? ""),
        timezone: body.timezone ? String(body.timezone) : "Asia/Jakarta",
        quota: Number(body.quota ?? 10),
        status: body.status ? String(body.status) : "open",
        sessionCount: Number(body.sessionCount ?? 3),
        meetingPlatform: body.meetingPlatform ? String(body.meetingPlatform) : "Zoom",
        meetingUrl: body.meetingUrl ? String(body.meetingUrl) : null,
        notes: body.notes ? String(body.notes) : null
      },
      await getAdminActor(request)
    );
    return NextResponse.json({ ok: true, data: batch });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Batch create failed" }, { status: 400 });
  }
}
