import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { generateCertificates, listCertificates, prepareCertificates, saveCertificateTemplate, sendCertificates } from "@/lib/repository";

const certificateActionSchema = z.discriminatedUnion("action", [
  z.object({
    action: z.literal("save_template"),
    programId: z.string().uuid().optional().nullable(),
    name: z.string().min(1).max(120).optional(),
    backgroundUrl: z.string().url().optional().nullable().or(z.literal("")),
    previewImageUrl: z.string().url().optional().nullable().or(z.literal("")),
    primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional().nullable().or(z.literal("")),
    accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional().nullable().or(z.literal("")),
    logoUrl: z.string().url().optional().nullable().or(z.literal("")),
    signatureName: z.string().max(100).optional().nullable(),
    notes: z.string().max(500).optional().nullable()
  }),
  z.object({
    action: z.literal("prepare"),
    programId: z.string().uuid().optional().nullable()
  }),
  z.object({
    action: z.literal("generate"),
    programId: z.string().uuid().optional().nullable()
  }),
  z.object({
    action: z.literal("send"),
    programId: z.string().uuid().optional().nullable()
  })
]);

export async function GET(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  return NextResponse.json({
    ok: true,
    data: await listCertificates(request.nextUrl.searchParams.get("programId") ?? undefined)
  });
}

export async function POST(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const body = await request.json().catch(() => null);
  const parsed = certificateActionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, message: "Input sertifikat tidak valid.", errors: parsed.error.flatten() }, { status: 400 });
  }

  const actor = await getAdminActor(request);
  const payload = parsed.data;

  if (payload.action === "save_template") {
    const result = await saveCertificateTemplate({
      programId: payload.programId,
      name: payload.name,
      backgroundUrl: payload.backgroundUrl || null,
      previewImageUrl: payload.previewImageUrl || null,
      primaryColor: payload.primaryColor || null,
      accentColor: payload.accentColor || null,
      logoUrl: payload.logoUrl || null,
      signatureName: payload.signatureName,
      notes: payload.notes
    }, actor);
    return NextResponse.json({ ok: true, data: result });
  }

  if (payload.action === "prepare") {
    const result = await prepareCertificates(payload.programId, actor);
    return NextResponse.json({ ok: true, data: result });
  }

  if (payload.action === "generate") {
    const result = await generateCertificates(payload.programId, actor);
    return NextResponse.json({ ok: true, data: result });
  }

  const result = await sendCertificates(payload.programId, actor);
  return NextResponse.json({ ok: true, data: result });
}
