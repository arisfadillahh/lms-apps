import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { updateDeviceOrder } from "@/lib/repository";

export async function PATCH(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  try {
    const order = await updateDeviceOrder(
      id,
      {
        status: body.status ? String(body.status) : undefined,
        adminNotes: Object.prototype.hasOwnProperty.call(body, "adminNotes") ? String(body.adminNotes ?? "") || null : undefined,
        fulfillmentNotes: Object.prototype.hasOwnProperty.call(body, "fulfillmentNotes") ? String(body.fulfillmentNotes ?? "") || null : undefined
      },
      await getAdminActor(request)
    );
    if (!order) return NextResponse.json({ ok: false, message: "Device order tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: order });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Device order update failed" }, { status: 400 });
  }
}
