import { NextRequest, NextResponse } from "next/server";
import { requireAdminRequest } from "@/lib/adminAuth";
import { getAdminSnapshot } from "@/lib/repository";

export async function GET(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const snapshot = await getAdminSnapshot();
  return NextResponse.json({ ok: true, data: snapshot.deviceOrders });
}
