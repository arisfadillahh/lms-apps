import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { updateFormField } from "@/lib/repository";

export async function PATCH(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  try {
    const field = await updateFormField(
      id,
      {
        label: body.label ? String(body.label) : undefined,
        helpText: Object.prototype.hasOwnProperty.call(body, "helpText") ? String(body.helpText ?? "") || null : undefined,
        placeholder: Object.prototype.hasOwnProperty.call(body, "placeholder") ? String(body.placeholder ?? "") || null : undefined,
        isRequired: typeof body.isRequired === "boolean" ? body.isRequired : undefined,
        isActive: typeof body.isActive === "boolean" ? body.isActive : undefined
      },
      await getAdminActor(request)
    );
    if (!field) return NextResponse.json({ ok: false, message: "Field tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: field });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Field update failed" }, { status: 400 });
  }
}
