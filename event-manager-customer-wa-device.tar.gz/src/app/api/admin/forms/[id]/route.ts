import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { updateProgramForm } from "@/lib/repository";

export async function PATCH(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  try {
    const form = await updateProgramForm(
      id,
      {
        name: body.name ? String(body.name) : undefined,
        slug: body.slug ? String(body.slug) : undefined,
        description: body.description ? String(body.description) : undefined,
        status: body.status ? String(body.status) : undefined,
        accessType: body.accessType ? String(body.accessType) : undefined,
        accessCode: body.accessCode ? String(body.accessCode) : undefined,
        priceType: body.priceType ? String(body.priceType) : undefined,
        maxSubmissions: Object.prototype.hasOwnProperty.call(body, "maxSubmissions") ? Number(body.maxSubmissions) || null : undefined,
        successTitle: body.successTitle ? String(body.successTitle) : undefined,
        successMessage: body.successMessage ? String(body.successMessage) : undefined,
        isActive: typeof body.isActive === "boolean" ? body.isActive : undefined
      },
      await getAdminActor(request)
    );
    if (!form) return NextResponse.json({ ok: false, message: "Form tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: form });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Form update failed" }, { status: 400 });
  }
}
