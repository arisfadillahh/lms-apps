import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { LmsClient } from "@/lib/lmsClient";
import { getParams } from "@/lib/http";
import { refreshInvoiceStatusFromLms } from "@/lib/repository";

export async function POST(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const lms = new LmsClient();
  const data = await lms.getInvoice(id);
  const result = await refreshInvoiceStatusFromLms(id, data, await getAdminActor(request));
  return NextResponse.json({ ok: true, data, result });
}
