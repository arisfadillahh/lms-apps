import { NextRequest, NextResponse } from "next/server";
import { requireAdminRequest } from "@/lib/adminAuth";
import { LmsClient } from "@/lib/lmsClient";
import { getParams } from "@/lib/http";
import { recordIntegrationLog, recordWhatsappLog } from "@/lib/repository";

export async function POST(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const lms = new LmsClient();
  try {
    const result = await lms.resendInvoice(id);
    await recordWhatsappLog({
      messageType: "invoice_reminder",
      recipient: `invoice:${id}`,
      messagePreview: `Resend invoice link requested for ${id}`,
      response: result,
      status: "success"
    });
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: "resend_invoice",
      status: "success",
      message: `Resend requested for ${id}`
    });
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    await recordWhatsappLog({
      messageType: "invoice_reminder",
      recipient: `invoice:${id}`,
      messagePreview: `Resend invoice link requested for ${id}`,
      status: "failed",
      errorMessage: error instanceof Error ? error.message : "Invoice resend failed"
    });
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: "resend_invoice",
      status: "failed",
      message: error instanceof Error ? error.message : "Invoice resend failed"
    });
    return NextResponse.json({ ok: false, message: "Invoice belum bisa dikirim ulang." }, { status: 502 });
  }
}
