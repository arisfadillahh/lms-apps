import { NextRequest, NextResponse } from "next/server";
import { requireAdminOrJobRequest } from "@/lib/adminAuth";
import { runMaintenanceJob } from "@/lib/repository";

export async function POST(request: NextRequest) {
  const unauthorized = await requireAdminOrJobRequest(request);
  if (unauthorized) return unauthorized;

  return NextResponse.json({ ok: true, result: await runMaintenanceJob("sync-invoices") });
}
