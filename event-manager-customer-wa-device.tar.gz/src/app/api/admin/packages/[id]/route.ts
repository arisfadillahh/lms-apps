import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { updateProgramPackage } from "@/lib/repository";

export async function PATCH(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  try {
    const pkg = await updateProgramPackage(
      id,
      {
        code: body.code ? String(body.code).trim() : undefined,
        name: body.name ? String(body.name).trim() : undefined,
        description: Object.prototype.hasOwnProperty.call(body, "description") ? String(body.description ?? "").trim() : undefined,
        minClasses: Object.prototype.hasOwnProperty.call(body, "minClasses") ? Number(body.minClasses) : undefined,
        maxClasses: Object.prototype.hasOwnProperty.call(body, "maxClasses") ? Number(body.maxClasses) : undefined,
        requiredWeekCount: Object.prototype.hasOwnProperty.call(body, "requiredWeekCount")
          ? body.requiredWeekCount === null || body.requiredWeekCount === ""
            ? null
            : Number(body.requiredWeekCount)
          : undefined,
        sameLevelOnly: Object.prototype.hasOwnProperty.call(body, "sameLevelOnly") ? Boolean(body.sameLevelOnly) : undefined,
        uniqueClassRequired: Object.prototype.hasOwnProperty.call(body, "uniqueClassRequired") ? Boolean(body.uniqueClassRequired) : undefined,
        uniqueSoftwareRequired: Object.prototype.hasOwnProperty.call(body, "uniqueSoftwareRequired") ? Boolean(body.uniqueSoftwareRequired) : undefined,
        oneClassPerWeek: Object.prototype.hasOwnProperty.call(body, "oneClassPerWeek") ? Boolean(body.oneClassPerWeek) : undefined,
        allowCustomSelection: Object.prototype.hasOwnProperty.call(body, "allowCustomSelection") ? Boolean(body.allowCustomSelection) : undefined,
        isActive: Object.prototype.hasOwnProperty.call(body, "isActive") ? Boolean(body.isActive) : undefined
      },
      await getAdminActor(request)
    );
    if (!pkg) return NextResponse.json({ ok: false, message: "Paket tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: pkg });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Package update failed" }, { status: 400 });
  }
}
