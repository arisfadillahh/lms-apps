import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { createProgramPackage } from "@/lib/repository";

export async function POST(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const body = await request.json().catch(() => ({}));
  try {
    const pkg = await createProgramPackage(
      {
        programId: String(body.programId ?? ""),
        code: String(body.code ?? "").trim(),
        name: String(body.name ?? "").trim(),
        description: String(body.description ?? "").trim(),
        minClasses: Number(body.minClasses ?? 1),
        maxClasses: Number(body.maxClasses ?? 1),
        requiredWeekCount: body.requiredWeekCount === null || body.requiredWeekCount === "" ? null : Number(body.requiredWeekCount ?? body.maxClasses ?? 1),
        sameLevelOnly: body.sameLevelOnly !== false,
        uniqueClassRequired: body.uniqueClassRequired !== false,
        uniqueSoftwareRequired: body.uniqueSoftwareRequired !== false,
        oneClassPerWeek: Boolean(body.oneClassPerWeek),
        allowCustomSelection: body.allowCustomSelection !== false,
        isActive: body.isActive !== false
      },
      await getAdminActor(request)
    );
    return NextResponse.json({ ok: true, data: pkg });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Package create failed" }, { status: 400 });
  }
}
