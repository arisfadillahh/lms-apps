import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { updateProgramPricing } from "@/lib/repository";

export async function PATCH(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  const actor = await getAdminActor(request);
  try {
    const pricing = await updateProgramPricing(
      id,
      {
        price: Object.prototype.hasOwnProperty.call(body, "price") ? Number(body.price) : undefined,
        currency: body.currency ? String(body.currency) : undefined,
        isActive: Object.prototype.hasOwnProperty.call(body, "isActive") ? Boolean(body.isActive) : undefined,
        adminId: actor.adminId
      },
      actor
    );
    if (!pricing) return NextResponse.json({ ok: false, message: "Harga tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: pricing });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Pricing update failed" }, { status: 400 });
  }
}
