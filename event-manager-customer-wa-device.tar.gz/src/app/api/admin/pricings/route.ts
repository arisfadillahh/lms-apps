import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { upsertProgramPricing } from "@/lib/repository";

export async function POST(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const body = await request.json().catch(() => ({}));
  const actor = await getAdminActor(request);
  try {
    const pricing = await upsertProgramPricing(
      {
        programId: String(body.programId ?? ""),
        priceType: String(body.priceType ?? "normal"),
        levelId: String(body.levelId ?? ""),
        packageId: String(body.packageId ?? ""),
        price: Number(body.price ?? 0),
        currency: body.currency ? String(body.currency) : "IDR",
        adminId: actor.adminId
      },
      actor
    );
    return NextResponse.json({ ok: true, data: pricing });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Pricing save failed" }, { status: 400 });
  }
}
