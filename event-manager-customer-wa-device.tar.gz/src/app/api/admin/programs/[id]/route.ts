import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { updateProgram } from "@/lib/repository";

export async function PATCH(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  try {
    const program = await updateProgram(
      id,
      {
        name: body.name ? String(body.name) : undefined,
        periodStart: body.periodStart ? String(body.periodStart) : undefined,
        periodEnd: body.periodEnd ? String(body.periodEnd) : undefined,
        mode: body.mode ? String(body.mode) : undefined,
        platform: body.platform ? String(body.platform) : undefined,
        defaultSessionDurationMinutes: body.defaultSessionDurationMinutes ? Number(body.defaultSessionDurationMinutes) : undefined,
        defaultQuotaPerBatch: body.defaultQuotaPerBatch ? Number(body.defaultQuotaPerBatch) : undefined,
        adminNotes: body.adminNotes ? String(body.adminNotes) : undefined,
        status: body.status ? String(body.status) : undefined
      },
      await getAdminActor(request)
    );
    if (!program) return NextResponse.json({ ok: false, message: "Program tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: program });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Program update failed" }, { status: 400 });
  }
}
