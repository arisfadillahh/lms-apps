import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { createProgram, listPrograms } from "@/lib/repository";

export async function GET(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  return NextResponse.json({ ok: true, data: await listPrograms() });
}

export async function POST(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const body = await request.json().catch(() => ({}));
  try {
    const program = await createProgram(
      {
        slug: String(body.slug ?? ""),
        name: String(body.name ?? ""),
        periodStart: String(body.periodStart ?? body.period_start ?? ""),
        periodEnd: String(body.periodEnd ?? body.period_end ?? ""),
        mode: String(body.mode ?? "online"),
        platform: body.platform ? String(body.platform) : undefined,
        defaultSessionDurationMinutes: Number(body.defaultSessionDurationMinutes ?? 90),
        defaultQuotaPerBatch: Number(body.defaultQuotaPerBatch ?? 10),
        adminNotes: body.adminNotes ? String(body.adminNotes) : undefined,
        status: body.status ? String(body.status) : "draft"
      },
      await getAdminActor(request)
    );
    return NextResponse.json({ ok: true, data: program }, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { ok: false, message: error instanceof Error ? error.message : "Program create failed" },
      { status: 400 }
    );
  }
}
