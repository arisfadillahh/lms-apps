import { NextRequest, NextResponse } from "next/server";
import { requireAdminRequest } from "@/lib/adminAuth";
import { listReconciliationLogs } from "@/lib/repository";

export async function GET(request: NextRequest) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  return NextResponse.json({ ok: true, data: await listReconciliationLogs() });
}
