import { NextRequest, NextResponse } from "next/server";
import { sendAdminPaymentConfirmedNotification } from "@/lib/adminWhatsappNotifications";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getClientIp, getParams, getUserAgent } from "@/lib/http";
import { buildEventPaymentConfirmedWhatsAppMessage, LmsClient } from "@/lib/lmsClient";
import { resolveShortPaymentLink } from "@/lib/paymentLinks";
import {
  getPaymentConfirmationWhatsappContext,
  getRegistrationPaymentContext,
  hasSuccessfulWhatsappLog,
  manualPaymentOverride,
  recordIntegrationLog,
  recordWhatsappLog
} from "@/lib/repository";
import type { RegistrationStatus } from "@/lib/types";

const allowedStatuses: RegistrationStatus[] = [
  "pending_invoice",
  "invoice_failed",
  "waiting_payment",
  "paid",
  "confirmed",
  "expired",
  "cancelled",
  "completed"
];

export async function POST(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  const newStatus = String(body.newStatus ?? "") as RegistrationStatus;
  const reason = String(body.reason ?? "").trim();

  if (!allowedStatuses.includes(newStatus) || reason.length < 5) {
    return NextResponse.json(
      { ok: false, message: "newStatus valid dan reason minimal 5 karakter wajib diisi." },
      { status: 400 }
    );
  }

  const paidAt = new Date().toISOString();
  const shouldMarkPaid = ["paid", "confirmed", "completed"].includes(newStatus);
  const paymentContext = await getRegistrationPaymentContext(id);
  if (!paymentContext) {
    return NextResponse.json({ ok: false, message: "Registrasi tidak ditemukan." }, { status: 404 });
  }

  if (shouldMarkPaid) {
    if (!paymentContext.invoiceId) {
      return NextResponse.json(
        { ok: false, message: "Invoice LMS belum ada untuk registrasi ini. Buat atau retry invoice dulu sebelum ditandai sudah bayar." },
        { status: 400 }
      );
    }

    const lms = new LmsClient();
    try {
      await lms.markInvoicePaid(paymentContext.invoiceId, {
        paidAt,
        reason,
        paidNotes: `Event Manager manual paid override: ${reason}`,
        externalReference: paymentContext.externalReference
      });
      await recordIntegrationLog({
        integration: "LMS Core",
        action: "manual_mark_invoice_paid",
        status: "success",
        message: `${paymentContext.externalReference} -> ${paymentContext.invoiceId} marked paid in LMS Core`
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "LMS invoice mark paid failed";
      await recordIntegrationLog({
        integration: "LMS Core",
        action: "manual_mark_invoice_paid",
        status: "failed",
        message: `${paymentContext.externalReference} -> ${message}`
      });
      return NextResponse.json(
        { ok: false, message: `Status invoice di LMS belum berhasil diubah: ${message}` },
        { status: 502 }
      );
    }
  }

  const result = await manualPaymentOverride(id, { newStatus, reason }, await getAdminActor(request));
  if (result && ["paid", "confirmed", "completed"].includes(newStatus)) {
    await sendManualPaymentConfirmation(String(result.externalReference), reason, paidAt);
  }
  return NextResponse.json({
    ok: true,
    data: result,
    requestContext: {
      ipAddress: getClientIp(request),
      userAgent: getUserAgent(request)
    },
    note: "Payment override updates LMS Core invoice status first, then mirrors the paid status in Event Manager with audit log."
  });
}

async function sendManualPaymentConfirmation(externalReference: string, reason: string, paidAt: string) {
  const context = await getPaymentConfirmationWhatsappContext(externalReference);
  if (!context) {
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: "send_payment_confirmation",
      status: "ignored",
      message: `${externalReference} manual payment confirmation skipped: registration context not found`
    });
    return;
  }

  const paymentLink = await resolveShortPaymentLink(context);
  const alreadySent = await hasSuccessfulWhatsappLog(context.registrationId, "payment_confirmed");
  if (!alreadySent) {
    const message = buildEventPaymentConfirmedWhatsAppMessage({
      parentName: context.parentName,
      studentName: context.studentName,
      programName: context.programName,
      packageName: context.packageName,
      levelName: context.levelName,
      scheduleLines: context.scheduleLines,
      addonLines: context.addonLines,
      total: context.total,
      paidAt,
      invoiceNumber: context.invoiceNumber,
      paymentLink
    });
    const lms = new LmsClient();
    try {
      const response = await lms.sendWhatsAppMessage({
        to: context.parentWhatsapp,
        message
      });
      await recordWhatsappLog({
        registrationId: context.registrationId,
        invoiceReferenceId: context.invoiceReferenceId,
        messageType: "payment_confirmed",
        recipient: context.parentWhatsapp,
        messagePreview: message.slice(0, 480),
        response,
        status: "success"
      });
      await recordIntegrationLog({
        integration: "LMS WhatsApp",
        action: "send_payment_confirmation",
        status: "success",
        message: `${externalReference} manual payment confirmation sent. Reason: ${reason}`
      });
    } catch (error) {
      const messageError = error instanceof Error ? error.message : "Payment confirmation WhatsApp failed";
      await recordWhatsappLog({
        registrationId: context.registrationId,
        invoiceReferenceId: context.invoiceReferenceId,
        messageType: "payment_confirmed",
        recipient: context.parentWhatsapp,
        messagePreview: message.slice(0, 480),
        status: "failed",
        errorMessage: messageError
      });
      await recordIntegrationLog({
        integration: "LMS WhatsApp",
        action: "send_payment_confirmation",
        status: "failed",
        message: messageError
      });
    }
  }

  await sendAdminPaymentConfirmedNotification(externalReference, { ...context, shortPaymentLink: paymentLink }, paidAt);
}
