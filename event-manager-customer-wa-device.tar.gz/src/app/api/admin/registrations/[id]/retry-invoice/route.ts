import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { buildEventInvoiceWhatsAppMessage, LmsClient } from "@/lib/lmsClient";
import { ReservationError } from "@/lib/dbRepository";
import { attachInvoice, markInvoiceFailed, prepareInvoiceRetry, recordIntegrationLog, recordWhatsappLog } from "@/lib/repository";

export async function POST(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const actor = await getAdminActor(request);

  let retry: Awaited<ReturnType<typeof prepareInvoiceRetry>>;
  try {
    retry = await prepareInvoiceRetry(id, actor);
  } catch (error) {
    const isReservationError = error instanceof ReservationError;
    const status = isReservationError ? (error.code === "SCHEDULE_FULL" ? 409 : 400) : 500;
    return NextResponse.json(
      {
        ok: false,
        code: isReservationError ? error.code : "SERVER_ERROR",
        message: isReservationError ? error.message : "Invoice belum bisa diretry."
      },
      { status }
    );
  }

  const lms = new LmsClient();

  try {
    const invoice = await lms.createInvoice(retry.invoicePayload);
    await attachInvoice(retry.id, invoice);
    await recordIntegrationLog({
      integration: "LMS Core",
      action: "retry_create_invoice",
      status: "success",
      message: `${invoice.invoiceNumber} created for ${retry.externalReference}`
    });

    let whatsappWarning: string | undefined;
    const whatsappMessage = buildEventInvoiceWhatsAppMessage({
      parentName: retry.parentName,
      studentName: retry.studentName,
      programName: retry.programName,
      invoiceNumber: invoice.invoiceNumber,
      paymentLink: invoice.paymentLink,
      total: retry.total,
      expiredAt: invoice.expiredAt,
      packageName: retry.packageName,
      levelName: retry.levelName,
      scheduleLines: retry.scheduleLines,
      addonLines: retry.addonLines
    });
    try {
      const whatsappResult = await lms.sendWhatsAppMessage({
        to: retry.parentWhatsapp,
        message: whatsappMessage
      });
      await recordWhatsappLog({
        registrationId: retry.id,
        messageType: "invoice_retry",
        recipient: retry.parentWhatsapp,
        messagePreview: whatsappMessage.slice(0, 480),
        response: whatsappResult,
        status: "success"
      });
      await recordIntegrationLog({
        integration: "LMS WhatsApp",
        action: "retry_send_invoice",
        status: "success",
        message: `Invoice retry sent to ${retry.parentWhatsapp}`
      });
    } catch (error) {
      whatsappWarning = "Invoice berhasil dibuat, tapi WhatsApp retry belum terkirim.";
      await recordWhatsappLog({
        registrationId: retry.id,
        messageType: "invoice_retry",
        recipient: retry.parentWhatsapp,
        messagePreview: whatsappMessage.slice(0, 480),
        status: "failed",
        errorMessage: error instanceof Error ? error.message : "WhatsApp retry failed"
      });
      await recordIntegrationLog({
        integration: "LMS WhatsApp",
        action: "retry_send_invoice",
        status: "failed",
        message: error instanceof Error ? error.message : "WhatsApp retry failed"
      });
    }

    return NextResponse.json({
      ok: true,
      data: {
        externalReference: retry.externalReference,
        invoice,
        whatsappWarning
      }
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invoice retry failed";
    await markInvoiceFailed(retry.id, message);
    return NextResponse.json(
      {
        ok: false,
        code: "INVOICE_FAILED",
        message: "Retry invoice gagal. Slot sudah dilepas kembali dan failure tercatat untuk admin."
      },
      { status: 502 }
    );
  }
}
