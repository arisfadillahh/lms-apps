import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { deleteRegistration } from "@/lib/repository";

export async function DELETE(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));

  try {
    const result = await deleteRegistration(
      id,
      {
        reason: body.reason ? String(body.reason) : "Cleanup data testing"
      },
      await getAdminActor(request)
    );
    if (!result) return NextResponse.json({ ok: false, message: "Registrasi tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: result });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Registration delete failed" }, { status: 400 });
  }
}
