import { NextRequest, NextResponse } from "next/server";
import { getFormConfig } from "@/lib/repository";
import { getParams } from "@/lib/http";

export async function GET(request: NextRequest, context: { params: { slug: string } | Promise<{ slug: string }> }) {
  const { slug } = await getParams(context.params);
  const accessToken = request.headers.get("x-form-access-token") ?? undefined;
  const config = await getFormConfig(slug, accessToken);

  if (!config) {
    return NextResponse.json({ ok: false, code: "FORM_CLOSED", message: "Form tidak ditemukan." }, { status: 404 });
  }

  return NextResponse.json({ ok: true, config });
}

