import { NextRequest, NextResponse } from "next/server";
import { getClientIp, getParams, getUserAgent } from "@/lib/http";
import { getFormConfig, recordFormEvent } from "@/lib/repository";

export async function POST(request: NextRequest, context: { params: { slug: string } | Promise<{ slug: string }> }) {
  const { slug } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  const config = await getFormConfig(slug, request.headers.get("x-form-access-token") ?? undefined);

  await recordFormEvent({
    formId: config?.form.id,
    eventType: String(body.eventType ?? "visit"),
    stepKey: body.stepKey ? String(body.stepKey) : undefined,
    ipAddress: getClientIp(request),
    userAgent: getUserAgent(request)
  });

  return NextResponse.json({ ok: true });
}

