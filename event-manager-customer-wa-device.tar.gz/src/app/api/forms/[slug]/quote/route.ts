import { NextRequest, NextResponse } from "next/server";
import { calculateQuote } from "@/lib/formEngine";
import { getClientIp, getParams, getUserAgent } from "@/lib/http";
import { getFormConfig, recordFormEvent } from "@/lib/repository";

export async function POST(request: NextRequest, context: { params: { slug: string } | Promise<{ slug: string }> }) {
  const { slug } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  const accessToken = request.headers.get("x-form-access-token") ?? body.accessToken;
  const config = await getFormConfig(slug, accessToken);

  if (!config) {
    return NextResponse.json({ ok: false, code: "FORM_CLOSED", message: "Form tidak ditemukan." }, { status: 404 });
  }

  const result = calculateQuote(config, body);
  await recordFormEvent({
    formId: config.form.id,
    eventType: result.ok ? "quote_requested" : "quote_failed",
    ipAddress: getClientIp(request),
    userAgent: getUserAgent(request),
    stepKey: "summary"
  });

  return NextResponse.json(result, { status: result.ok ? 200 : 400 });
}

