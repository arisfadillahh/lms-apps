import { NextRequest, NextResponse } from "next/server";
import { normalizeWhatsapp, validateSubmit } from "@/lib/formEngine";
import { getClientIp, getParams, getUserAgent } from "@/lib/http";
import { buildEventInvoiceWhatsAppMessage, buildInvoicePayload, LmsClient } from "@/lib/lmsClient";
import { sendAdminRegistrationCreatedNotification } from "@/lib/adminWhatsappNotifications";
import { ReservationError } from "@/lib/dbRepository";
import { attachInvoice, getFormConfig, markInvoiceFailed, recordFormEvent, recordIntegrationLog, recordWhatsappLog, reserveRegistration } from "@/lib/repository";
import type { SubmitRequest } from "@/lib/types";

export async function POST(request: NextRequest, context: { params: { slug: string } | Promise<{ slug: string }> }) {
  const { slug } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  const rawBody = body as Record<string, any>;
  const rawParent = (rawBody.parent ?? {}) as Record<string, any>;
  const accessToken = request.headers.get("x-form-access-token") ?? rawBody.accessToken;
  const config = await getFormConfig(slug, accessToken);

  if (!config) {
    return NextResponse.json({ ok: false, code: "FORM_CLOSED", message: "Form tidak ditemukan." }, { status: 404 });
  }

  const normalizedBody = {
    ...rawBody,
    parent: {
      ...rawParent,
      parentWhatsapp: normalizeWhatsapp(String(rawParent.parentWhatsapp ?? ""))
    }
  } as SubmitRequest;

  const quote = validateSubmit(config, normalizedBody);
  if (!quote.ok) {
    await recordFormEvent({
      formId: config.form.id,
      eventType: "error",
      ipAddress: getClientIp(request),
      userAgent: getUserAgent(request),
      stepKey: "submit"
    });
    return NextResponse.json(quote, { status: 400 });
  }

  let registration: Awaited<ReturnType<typeof reserveRegistration>>;
  try {
    registration = await reserveRegistration(normalizedBody, quote, config);
  } catch (error) {
    const isReservationError = error instanceof ReservationError;
    await recordFormEvent({
      formId: config.form.id,
      eventType: "error",
      ipAddress: getClientIp(request),
      userAgent: getUserAgent(request),
      stepKey: "reservation"
    });

    const status = isReservationError ? (error.code === "SCHEDULE_FULL" ? 409 : error.code === "FORM_CLOSED" ? 400 : 500) : 500;
    return NextResponse.json(
      {
        ok: false,
        code: isReservationError ? error.code : "SERVER_ERROR",
        message: isReservationError ? error.message : "Jadwal belum bisa diamankan. Silakan coba lagi."
      },
      { status }
    );
  }

  const lms = new LmsClient();

  try {
    const invoicePayload = buildInvoicePayload(normalizedBody, quote, registration.externalReference);
    const invoice = await lms.createInvoice(invoicePayload);
    await attachInvoice(registration.id, invoice);
    await recordIntegrationLog({
      integration: "LMS Core",
      action: "create_invoice",
      status: "success",
      message: `${invoice.invoiceNumber} created for ${registration.externalReference}`
    });
    await recordFormEvent({
      formId: config.form.id,
      eventType: "invoice_created",
      ipAddress: getClientIp(request),
      userAgent: getUserAgent(request),
      stepKey: "invoice"
    });

    let whatsappWarning: string | undefined;
    const whatsappPaymentLink = invoice.shortPaymentLink || invoice.paymentLink;
    const whatsappMessage = buildEventInvoiceWhatsAppMessage({
      parentName: normalizedBody.parent.parentName,
      studentName: normalizedBody.student.studentName,
      programName: config.program.name,
      invoiceNumber: invoice.invoiceNumber,
      paymentLink: whatsappPaymentLink,
      total: quote.total,
      expiredAt: invoice.expiredAt,
      packageName: quote.package.name,
      levelName: quote.level.name,
      addonLines: buildAddonLines(normalizedBody, config),
      scheduleLines: quote.selectedBatches.map((batch) => {
        const klass = quote.selectedClasses.find((item) => item.id === batch.classId);
        return `Minggu ${batch.weekNo} - ${klass?.name ?? "Kelas"} - ${formatScheduleDate(batch.startsAt)}`;
      })
    });
    try {
      const whatsappResult = await lms.sendWhatsAppMessage({
        to: normalizedBody.parent.parentWhatsapp,
        message: whatsappMessage
      });
      await recordWhatsappLog({
        registrationId: registration.id,
        messageType: "invoice_created",
        recipient: normalizedBody.parent.parentWhatsapp,
        messagePreview: whatsappMessage.slice(0, 480),
        response: whatsappResult,
        status: "success"
      });
      await recordIntegrationLog({
        integration: "LMS WhatsApp",
        action: "send_invoice",
        status: "success",
        message: `Invoice sent to ${normalizedBody.parent.parentWhatsapp}`
      });
    } catch (error) {
      whatsappWarning = "Invoice berhasil dibuat, tapi WhatsApp belum terkirim. Link pembayaran tetap tersedia di halaman ini.";
      await recordWhatsappLog({
        registrationId: registration.id,
        messageType: "invoice_created",
        recipient: normalizedBody.parent.parentWhatsapp,
        messagePreview: whatsappMessage.slice(0, 480),
        status: "failed",
        errorMessage: error instanceof Error ? error.message : "WhatsApp send failed"
      });
      await recordIntegrationLog({
        integration: "LMS WhatsApp",
        action: "send_invoice",
        status: "failed",
        message: error instanceof Error ? error.message : "WhatsApp send failed"
      });
    }

    await sendAdminRegistrationCreatedNotification({
      registrationId: registration.id,
      externalReference: registration.externalReference,
      parentName: normalizedBody.parent.parentName,
      parentWhatsapp: normalizedBody.parent.parentWhatsapp,
      studentName: normalizedBody.student.studentName,
      programName: config.program.name,
      packageName: quote.package.name,
      levelName: quote.level.name,
      studentGrade: normalizedBody.student.studentGradeRaw,
      studentSchool: normalizedBody.student.studentSchool,
      partnerSchoolName: config.accessContext?.partnerSchool?.name,
      addonLines: buildAddonLines(normalizedBody, config),
      total: quote.total,
      invoiceNumber: invoice.invoiceNumber,
      paymentLink: whatsappPaymentLink,
      selectedBatches: quote.selectedBatches,
      selectedClasses: quote.selectedClasses
    });

    await recordFormEvent({
      formId: config.form.id,
      eventType: "submitted",
      ipAddress: getClientIp(request),
      userAgent: getUserAgent(request)
    });

    return NextResponse.json({
      ok: true,
      registrationId: registration.id,
      externalReference: registration.externalReference,
      status: "waiting_payment",
      invoice,
      whatsappWarning
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invoice creation failed";
    await markInvoiceFailed(registration.id, message);
    await recordFormEvent({
      formId: config.form.id,
      eventType: "error",
      ipAddress: getClientIp(request),
      userAgent: getUserAgent(request),
      stepKey: "invoice"
    });

    return NextResponse.json(
      {
        ok: false,
        code: "INVOICE_FAILED",
        message: "Pendaftaran tersimpan, tapi invoice belum berhasil dibuat. Tim admin akan membantu memproses pendaftaran ini."
      },
      { status: 502 }
    );
  }
}

function formatScheduleDate(value: string) {
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  }).format(new Date(value));
}

function buildAddonLines(input: SubmitRequest, config: Awaited<ReturnType<typeof getFormConfig>>) {
  if (!config) return [];
  return (input.addons ?? [])
    .map((selection) => {
      const addon = config.addons.find((item) => item.code === selection.addonCode);
      if (!addon) return null;
      return `${addon.name}: ${formatAddonChoice(selection.choice)}`;
    })
    .filter((line): line is string => Boolean(line));
}

function formatAddonChoice(choice: string) {
  if (choice === "buy") return "Beli dari Clevio";
  if (choice === "own") return "Punya sendiri";
  if (choice === "simulator") return "Pakai simulator";
  return choice;
}
