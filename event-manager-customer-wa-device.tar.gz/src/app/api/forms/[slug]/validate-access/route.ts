import { NextRequest, NextResponse } from "next/server";
import { getClientIp, getParams, getUserAgent } from "@/lib/http";
import { getFormConfig, recordFormEvent, validateFormAccess } from "@/lib/repository";

export async function POST(request: NextRequest, context: { params: { slug: string } | Promise<{ slug: string }> }) {
  const { slug } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));
  const config = await getFormConfig(slug);

  if (!config) {
    return NextResponse.json({ ok: false, code: "FORM_CLOSED", message: "Form tidak ditemukan." }, { status: 404 });
  }

  if (config.form.accessType === "public") {
    return NextResponse.json({ ok: true, accessToken: null });
  }

  const result = await validateFormAccess(slug, String(body.code ?? ""), getClientIp(request), getUserAgent(request));
  await recordFormEvent({
    formId: config.form.id,
    eventType: result.ok ? "access_granted" : "access_failed",
    ipAddress: getClientIp(request),
    userAgent: getUserAgent(request)
  });

  if (!result.ok) {
    return NextResponse.json(result, { status: result.code === "RATE_LIMITED" ? 429 : 401 });
  }

  return NextResponse.json(result);
}
