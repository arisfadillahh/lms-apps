import { NextRequest, NextResponse } from "next/server";
import { getParams } from "@/lib/http";
import { getAvailabilityForProgram } from "@/lib/repository";

export async function GET(request: NextRequest, context: { params: { programId: string } | Promise<{ programId: string }> }) {
  const { programId } = await getParams(context.params);
  const levelId = request.nextUrl.searchParams.get("levelId") ?? undefined;
  const availability = await getAvailabilityForProgram(programId, levelId);
  return NextResponse.json({ ok: true, availability });
}

