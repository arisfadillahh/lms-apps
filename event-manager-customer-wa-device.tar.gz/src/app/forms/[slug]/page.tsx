import type { Metadata } from "next";
import { PublicRegistrationForm } from "@/components/PublicRegistrationForm";
import { BASE_PATH } from "@/lib/constants";
import { getParams } from "@/lib/http";

const siteUrl = "https://lms.clev.io";
const formTitle = "Form Holiday Class Clevio 2026";
const formDescription = "Daftar Holiday Class Clevio 2026. Pilih paket dan jadwal kelas liburan coding anak bersama Clevio.";
const formImage = `${siteUrl}${BASE_PATH}/holiday-class-2026/holiday-logo.png`;

export async function generateMetadata({ params }: { params: { slug: string } | Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await getParams(params);
  const url = `${siteUrl}${BASE_PATH}/forms/${slug}`;

  return {
    title: formTitle,
    description: formDescription,
    alternates: {
      canonical: url
    },
    openGraph: {
      title: formTitle,
      description: formDescription,
      url,
      siteName: "Clevio",
      type: "website",
      images: [
        {
          url: formImage,
          width: 1200,
          height: 630,
          alt: "Holiday Class Clevio 2026"
        }
      ]
    },
    twitter: {
      card: "summary_large_image",
      title: formTitle,
      description: formDescription,
      images: [formImage]
    }
  };
}

export default async function FormPage({ params }: { params: { slug: string } | Promise<{ slug: string }> }) {
  const { slug } = await getParams(params);
  return <PublicRegistrationForm slug={slug} />;
}
