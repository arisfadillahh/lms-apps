import type { Metadata } from "next";
import "@/app/globals.css";

export const metadata: Metadata = {
  title: "Clevio Event Manager",
  description: "Program, registration, invoice, and quota manager for Clevio events"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}

