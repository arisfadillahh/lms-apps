import Link from "next/link";
import { CalendarCheck, ExternalLink, LayoutDashboard } from "lucide-react";
import { appPath } from "@/lib/constants";

export default function HomePage() {
  return (
    <main className="home-shell">
      <section className="home-panel">
        <div className="brand-lockup">
          <span className="brand-mark">C</span>
          <div>
            <strong>Clevio</strong>
            <span>Event Manager</span>
          </div>
        </div>
        <h1>Holiday Class Clevio 2026</h1>
        <p>Dashboard event terpisah dari LMS, dengan invoice dan WhatsApp tetap lewat LMS Core API.</p>
        <div className="home-actions">
          <Link href={appPath("/admin")} className="primary-action">
            <LayoutDashboard size={18} />
            Admin Dashboard
          </Link>
          <Link href={appPath("/forms/holiday-class-2026")} className="secondary-action">
            <CalendarCheck size={18} />
            Form Publik
          </Link>
          <Link href={appPath("/forms/holiday-class-partner-2026")} className="secondary-action">
            <ExternalLink size={18} />
            Form Sekolah Partner
          </Link>
        </div>
      </section>
    </main>
  );
}
