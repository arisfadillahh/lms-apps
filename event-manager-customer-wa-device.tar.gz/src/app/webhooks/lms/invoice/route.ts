import { NextRequest, NextResponse } from "next/server";
import crypto from "node:crypto";
import { sendAdminPaymentConfirmedNotification } from "@/lib/adminWhatsappNotifications";
import { buildEventPaymentConfirmedWhatsAppMessage, LmsClient } from "@/lib/lmsClient";
import { resolveShortPaymentLink } from "@/lib/paymentLinks";
import {
  applyInvoiceWebhook,
  getPaymentConfirmationWhatsappContext,
  hasSuccessfulWhatsappLog,
  recordIntegrationLog,
  recordWebhookLog,
  recordWhatsappLog
} from "@/lib/repository";

export async function POST(request: NextRequest) {
  const rawBody = await request.text();
  const signature = request.headers.get("x-lms-signature");
  const signatureValid = verifySignature(rawBody, signature);
  let payload: {
    invoice_id?: string;
    external_reference?: string;
    status?: "paid" | "expired" | "cancelled" | string;
    paid_at?: string;
    amount?: number;
  };

  try {
    payload = JSON.parse(rawBody);
  } catch (error) {
    await recordWebhookLog({
      source: "lms",
      eventType: "invoice",
      payload: { rawBody },
      signatureValid,
      processingStatus: "failed",
      errorMessage: error instanceof Error ? error.message : "Invalid JSON"
    });
    return NextResponse.json({ ok: false, message: "Invalid JSON payload" }, { status: 400 });
  }

  if (!signatureValid && process.env.LMS_WEBHOOK_SECRET) {
    await recordWebhookLog({
      source: "lms",
      eventType: "invoice",
      eventId: payload.invoice_id ?? null,
      externalReference: payload.external_reference ?? null,
      payload,
      signatureValid,
      processingStatus: "rejected",
      errorMessage: "Invalid LMS webhook signature"
    });
    return NextResponse.json({ ok: false, message: "Invalid LMS webhook signature" }, { status: 401 });
  }

  const result = await applyInvoiceWebhook({
    invoice_id: String(payload.invoice_id ?? ""),
    external_reference: String(payload.external_reference ?? ""),
    status: String(payload.status ?? "unknown"),
    paid_at: payload.paid_at,
    amount: payload.amount
  });
  await recordWebhookLog({
    source: "lms",
    eventType: "invoice",
    eventId: payload.invoice_id ?? null,
    externalReference: payload.external_reference ?? null,
    payload,
    signatureValid,
    processingStatus: result.updated ? "processed" : "ignored",
    errorMessage: result.updated ? null : "reason" in result ? result.reason : "not_updated"
  });
  await recordIntegrationLog({
    integration: "LMS Webhook",
    action: "invoice_status",
    status: result.updated ? "success" : "ignored",
    message: `${payload.external_reference ?? "unknown"} -> ${payload.status ?? "unknown"}`
  });

  if (result.updated && payload.status === "paid") {
    await sendPaymentConfirmationWhatsapp(String(payload.external_reference ?? ""), payload.paid_at);
  }

  return NextResponse.json({ ok: true, result });
}

async function sendPaymentConfirmationWhatsapp(externalReference: string, paidAt?: string) {
  const context = await getPaymentConfirmationWhatsappContext(externalReference);
  if (!context) {
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: "send_payment_confirmation",
      status: "ignored",
      message: `${externalReference} payment confirmation skipped: registration context not found`
    });
    return;
  }

  const paymentLink = await resolveShortPaymentLink(context);
  const alreadySent = await hasSuccessfulWhatsappLog(context.registrationId, "payment_confirmed");
  if (alreadySent) {
    await sendAdminPaymentConfirmedNotification(externalReference, { ...context, shortPaymentLink: paymentLink }, paidAt ?? context.paidAt);
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: "send_payment_confirmation",
      status: "ignored",
      message: `${externalReference} payment confirmation already sent`
    });
    return;
  }

  const message = buildEventPaymentConfirmedWhatsAppMessage({
    parentName: context.parentName,
    studentName: context.studentName,
    programName: context.programName,
    packageName: context.packageName,
    levelName: context.levelName,
    scheduleLines: context.scheduleLines,
    addonLines: context.addonLines,
    total: context.total,
    paidAt: paidAt ?? context.paidAt,
    invoiceNumber: context.invoiceNumber,
    paymentLink
  });
  const lms = new LmsClient();

  try {
    const response = await lms.sendWhatsAppMessage({
      to: context.parentWhatsapp,
      message
    });
    await recordWhatsappLog({
      registrationId: context.registrationId,
      invoiceReferenceId: context.invoiceReferenceId,
      messageType: "payment_confirmed",
      recipient: context.parentWhatsapp,
      messagePreview: message.slice(0, 480),
      response,
      status: "success"
    });
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: "send_payment_confirmation",
      status: "success",
      message: `${externalReference} payment confirmation sent to ${context.parentWhatsapp}`
    });
  } catch (error) {
    const messageError = error instanceof Error ? error.message : "Payment confirmation WhatsApp failed";
    await recordWhatsappLog({
      registrationId: context.registrationId,
      invoiceReferenceId: context.invoiceReferenceId,
      messageType: "payment_confirmed",
      recipient: context.parentWhatsapp,
      messagePreview: message.slice(0, 480),
      status: "failed",
      errorMessage: messageError
    });
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: "send_payment_confirmation",
      status: "failed",
      message: messageError
    });
  }

  await sendAdminPaymentConfirmedNotification(externalReference, { ...context, shortPaymentLink: paymentLink }, paidAt ?? context.paidAt);
}

function verifySignature(rawBody: string, signature: string | null) {
  const secret = process.env.LMS_WEBHOOK_SECRET;
  if (!secret) return true;
  if (!signature) return false;
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  if (signature.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
}
