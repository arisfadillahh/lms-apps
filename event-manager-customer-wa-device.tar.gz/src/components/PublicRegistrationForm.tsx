"use client";

import { useEffect, useMemo, useRef, useState, useTransition, type TouchEvent } from "react";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  CreditCard,
  Lock,
  MessageCircle,
  Monitor,
  PackageCheck,
  ShieldCheck,
  User,
  Users
} from "lucide-react";
import { BASE_PATH, apiPath } from "@/lib/constants";
import { buildAvailability, detectLevel, formatRupiah, formatScheduleDateRange, formatScheduleTime, normalizeWhatsapp } from "@/lib/formEngine";
import type { AvailabilityItem, FormConfig, ProgramClass, QuoteResult, SubmitSuccess } from "@/lib/types";

type FormState = {
  parentName: string;
  parentWhatsapp: string;
  studentName: string;
  studentGradeRaw: string;
  packageCode: string;
  scheduleClassChoices: Record<number, string>;
  schedules: Record<number, string>;
  addons: Record<string, string>;
};

const initialState: FormState = {
  parentName: "",
  parentWhatsapp: "",
  studentName: "",
  studentGradeRaw: "",
  packageCode: "single",
  scheduleClassChoices: {},
  schedules: {},
  addons: {}
};

const gradeOptions = [
  "1 SD",
  "2 SD",
  "3 SD",
  "4 SD",
  "5 SD",
  "6 SD",
  "7 SMP",
  "8 SMP",
  "9 SMP",
  "10 SMA",
  "11 SMA",
  "12 SMA"
];

const holidayAsset = (fileName: string) => `${BASE_PATH}/holiday-class-2026/${fileName}`;

export function PublicRegistrationForm({ slug }: { slug: string }) {
  const [config, setConfig] = useState<FormConfig | null>(null);
  const [accessCode, setAccessCode] = useState("");
  const [accessToken, setAccessToken] = useState<string | undefined>();
  const [form, setForm] = useState(initialState);
  const [stepIndex, setStepIndex] = useState(0);
  const [quote, setQuote] = useState<QuoteResult | null>(null);
  const [success, setSuccess] = useState<SubmitSuccess | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [keyboardOpen, setKeyboardOpen] = useState(false);
  const contentTouchYRef = useRef<number | null>(null);
  const contentTouchMovedRef = useRef(false);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    fetchConfig(accessToken);
    fetch(apiPath(`/forms/${slug}/events`), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ eventType: "visit" })
    }).catch(() => undefined);
  }, [accessToken, slug]);

  useEffect(() => {
    const isMobile = () => window.matchMedia("(max-width: 760px)").matches;
    const isFormControl = (element: Element | null): element is HTMLElement =>
      element instanceof HTMLElement && element.matches("input, textarea, select");

    let scrollTimer: number | undefined;
    const updateKeyboardOffset = () => {
      const viewport = window.visualViewport;
      const offset = viewport && isMobile() ? Math.max(0, window.innerHeight - viewport.height - viewport.offsetTop) : 0;
      document.documentElement.style.setProperty("--event-form-keyboard-offset", `${Math.round(offset)}px`);
    };

    const keepFocusedControlVisible = () => {
      if (!isMobile()) {
        setKeyboardOpen(false);
        document.documentElement.style.setProperty("--event-form-keyboard-offset", "0px");
        return;
      }

      updateKeyboardOffset();
      const activeElement = document.activeElement;
      const focusedControl = isFormControl(activeElement) ? activeElement : null;
      setKeyboardOpen(Boolean(focusedControl));

      if (!focusedControl) return;
      window.clearTimeout(scrollTimer);
      scrollTimer = window.setTimeout(() => {
        focusedControl.scrollIntoView({ block: "center", inline: "nearest", behavior: "smooth" });
        window.setTimeout(() => {
          const controlRect = focusedControl.getBoundingClientRect();
          const footerRect = document.querySelector(".form-footer")?.getBoundingClientRect();
          if (footerRect && controlRect.bottom > footerRect.top - 12) {
            window.scrollBy({ top: controlRect.bottom - footerRect.top + 24, behavior: "smooth" });
          } else if (controlRect.top < 12) {
            window.scrollBy({ top: controlRect.top - 18, behavior: "smooth" });
          }
        }, 180);
      }, 80);
    };

    const clearKeyboardState = () => {
      window.clearTimeout(scrollTimer);
      window.setTimeout(() => {
        if (!isFormControl(document.activeElement)) {
          setKeyboardOpen(false);
          document.documentElement.style.setProperty("--event-form-keyboard-offset", "0px");
        }
      }, 120);
    };

    window.addEventListener("focusin", keepFocusedControlVisible);
    window.addEventListener("focusout", clearKeyboardState);
    window.visualViewport?.addEventListener("resize", keepFocusedControlVisible);
    window.visualViewport?.addEventListener("scroll", keepFocusedControlVisible);

    return () => {
      window.clearTimeout(scrollTimer);
      document.documentElement.style.removeProperty("--event-form-keyboard-offset");
      window.removeEventListener("focusin", keepFocusedControlVisible);
      window.removeEventListener("focusout", clearKeyboardState);
      window.visualViewport?.removeEventListener("resize", keepFocusedControlVisible);
      window.visualViewport?.removeEventListener("scroll", keepFocusedControlVisible);
    };
  }, []);

  const steps = config?.steps ?? [];
  const activeStep = steps[stepIndex];
  const detectedLevel = useMemo(() => (config ? detectLevel(config.levels, form.studentGradeRaw) : null), [config, form.studentGradeRaw]);
  const selectedPackage = config?.packages.find((item) => item.code === form.packageCode);
  const expectedScheduleCount = form.packageCode === "bundling" ? 3 : 1;
  const availability = useMemo(() => {
    if (!config) return [];
    const items = buildAvailability(config, detectedLevel?.id);
    if (detectedLevel) return items;
    return items.map((item) => ({ ...item, isSelectable: false, disabledReason: "Pilih kelas anak dulu" }));
  }, [config, detectedLevel]);

  const selectedBatches = useMemo(() => {
    const ids = getSchedulePayload().map((selection) => selection.batchId);
    return availability.filter((batch) => ids.includes(batch.id));
  }, [availability, form.packageCode, form.schedules]);

  const selectedClasses = useMemo(() => {
    if (!config) return [];
    return selectedBatches.map((batch) => config.classes.find((klass) => klass.id === batch.classId)).filter(Boolean);
  }, [config, selectedBatches]);

  const needsMicrobit = selectedClasses.some((klass) => klass?.slug === "microbit");
  const needsArduino = selectedClasses.some((klass) => klass?.slug === "arduino");
  const reviewNotes = useMemo(() => {
    const classNotes = selectedClasses
      .map((klass) => (klass?.requirements ? `${klass.name}\n${klass.requirements}` : null))
      .filter((note): note is string => Boolean(note));
    const globalNotes = (config?.reviewNotes ?? []).filter((note) => !isLegacyMinimumSpecNote(note));
    return [...globalNotes, ...classNotes];
  }, [config, selectedClasses]);
  const visibleSteps = steps.filter((step) => isStepVisible(step.stepKey));
  const currentVisibleIndex = Math.max(0, visibleSteps.findIndex((step) => step.stepKey === activeStep?.stepKey));
  const progressPercent = visibleSteps.length > 0 ? Math.round(((currentVisibleIndex + 1) / visibleSteps.length) * 100) : 0;
  const stepTitle = activeStep?.stepKey === "parent" ? "Data Peserta" : activeStep?.title;
  const stepDescription = activeStep?.stepKey === "parent" ? "Isi kontak orang tua dan data anak." : activeStep?.stepKey === "schedule" ? "Pilih kelasnya dulu, lalu tanggal mulai." : activeStep?.description;

  async function fetchConfig(token?: string) {
    const response = await fetch(apiPath(`/forms/${slug}/config`), {
      headers: token ? { "x-form-access-token": token } : undefined
    });
    const data = await response.json();
    if (data.ok) setConfig(data.config);
    else setError(data.message ?? "Form tidak tersedia.");
  }

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    if (key === "packageCode" && contentTouchMovedRef.current) {
      contentTouchMovedRef.current = false;
      return;
    }

    setForm((current) => {
      if (key === "studentGradeRaw" || key === "packageCode") {
        return { ...current, [key]: value, scheduleClassChoices: {}, schedules: {}, addons: {} };
      }
      return { ...current, [key]: value };
    });
    setError(null);
    setFieldErrors({});
    setQuote(null);
  }

  function updateWhatsapp(value: string) {
    setForm((current) => ({ ...current, parentWhatsapp: value.replace(/[^\d+()\-\s]/g, "") }));
    setError(null);
    setFieldErrors({});
    setQuote(null);
  }

  function normalizeWhatsappField() {
    setForm((current) => ({ ...current, parentWhatsapp: normalizeWhatsapp(current.parentWhatsapp) }));
  }

  function updateSchedule(weekNo: number, batchId: string) {
    if (contentTouchMovedRef.current) {
      contentTouchMovedRef.current = false;
      return;
    }

    setForm((current) => {
      const chosenBatch = availability.find((batch) => batch.id === batchId);
      const schedules = current.packageCode === "single" ? { 1: batchId } : { ...current.schedules, [weekNo]: batchId };
      const scheduleClassChoices =
        current.packageCode === "single"
          ? { 1: chosenBatch?.classId ?? current.scheduleClassChoices[1] }
          : { ...current.scheduleClassChoices, [weekNo]: chosenBatch?.classId ?? current.scheduleClassChoices[weekNo] };
      return { ...current, scheduleClassChoices, schedules, addons: {} };
    });
    setQuote(null);
  }

  function updateScheduleClass(weekNo: number, classId: string, autoBatchId?: string) {
    if (contentTouchMovedRef.current) {
      contentTouchMovedRef.current = false;
      return;
    }

    const shouldFocusDates = form.packageCode === "single";
    setForm((current) => {
      const scheduleClassChoices = current.packageCode === "single" ? { 1: classId } : { ...current.scheduleClassChoices, [weekNo]: classId };
      const schedules: Record<number, string> = current.packageCode === "single" ? {} : { ...current.schedules };
      if (current.packageCode !== "single") {
        delete schedules[weekNo];
      }
      if (autoBatchId) {
        schedules[weekNo] = autoBatchId;
      }
      return { ...current, scheduleClassChoices, schedules, addons: {} };
    });
    setQuote(null);
    if (shouldFocusDates) {
      window.setTimeout(() => {
        document.querySelector(".date-choice-grid, .schedule-empty-inline")?.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 120);
    }
  }

  function updateAddon(code: string, choice: string) {
    if (contentTouchMovedRef.current) {
      contentTouchMovedRef.current = false;
      return;
    }

    setForm((current) => ({ ...current, addons: { ...current.addons, [code]: choice } }));
    setQuote(null);
  }

  async function validateAccess() {
    setError(null);
    const response = await fetch(apiPath(`/forms/${slug}/validate-access`), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ code: accessCode })
    });
    const data = await response.json();
    if (!data.ok) {
      setError(data.message ?? "Kode akses tidak valid.");
      return;
    }
    setAccessToken(data.accessToken);
  }

  async function requestQuote() {
    if (!config) return null;
    const payload = buildPayload();
    const response = await fetch(apiPath(`/forms/${slug}/quote`), {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(accessToken ? { "x-form-access-token": accessToken } : {})
      },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!data.ok) {
      setError(data.message ?? "Quote belum valid.");
      setFieldErrors(data.fieldErrors ?? {});
      return null;
    }
    setQuote(data);
    return data as QuoteResult;
  }

  function nextStep() {
    setError(null);
    if (!validateCurrentStep()) return;
    if (activeStep?.stepKey === "summary") return;
    const targetIndex = findVisibleStepIndex(1);
    if (targetIndex === stepIndex) return;
    if (steps[targetIndex]?.stepKey === "summary") {
      startTransition(async () => {
        const latestQuote = await requestQuote();
        if (latestQuote) {
          setStepIndex(targetIndex);
          scrollFormIntoView();
        }
      });
      return;
    }
    setStepIndex(targetIndex);
    scrollFormIntoView();
  }

  function previousStep() {
    setStepIndex(findVisibleStepIndex(-1));
    setError(null);
    scrollFormIntoView();
  }

  function isStepVisible(stepKey: string) {
    if (stepKey === "student" || stepKey === "agreement") return false;
    return stepKey !== "addons" || needsMicrobit || needsArduino;
  }

  function findVisibleStepIndex(direction: 1 | -1) {
    for (let index = stepIndex + direction; index >= 0 && index < steps.length; index += direction) {
      if (isStepVisible(steps[index].stepKey)) return index;
    }
    return stepIndex;
  }

  function scrollFormIntoView() {
    window.setTimeout(() => {
      const target = window.matchMedia("(max-width: 760px)").matches ? document.querySelector(".form-header") : document.querySelector(".form-card");
      target?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 60);
  }

  function handleContentTouchStart(event: TouchEvent<HTMLDivElement>) {
    if (!window.matchMedia("(max-width: 760px)").matches) return;
    contentTouchYRef.current = event.touches[0]?.clientY ?? null;
    contentTouchMovedRef.current = false;
  }

  function handleContentTouchMove(event: TouchEvent<HTMLDivElement>) {
    if (!window.matchMedia("(max-width: 760px)").matches) return;
    const nextY = event.touches[0]?.clientY;
    const previousY = contentTouchYRef.current;
    if (nextY == null || previousY == null) {
      contentTouchYRef.current = nextY ?? null;
      return;
    }

    const delta = previousY - nextY;
    if (Math.abs(delta) < 2) return;

    contentTouchMovedRef.current = true;
    contentTouchYRef.current = nextY;
    window.scrollBy({ top: delta, behavior: "auto" });
  }

  function handleContentTouchEnd() {
    contentTouchYRef.current = null;
    window.setTimeout(() => {
      contentTouchMovedRef.current = false;
    }, 180);
  }

  async function submit() {
    setError(null);

    startTransition(async () => {
      const latestQuote = quote ?? (await requestQuote());
      if (!latestQuote) return;
      const response = await fetch(apiPath(`/forms/${slug}/submit`), {
        method: "POST",
        headers: {
          "content-type": "application/json",
          ...(accessToken ? { "x-form-access-token": accessToken } : {})
        },
        body: JSON.stringify({ ...buildPayload(), policyAgreement: true })
      });
      const data = await response.json();
      if (!data.ok) {
        setError(data.message ?? "Pendaftaran belum berhasil.");
        setFieldErrors(data.fieldErrors ?? {});
        return;
      }
      setSuccess(data);
    });
  }

  function validateCurrentStep() {
    const errors: Record<string, string> = {};
    const key = activeStep?.stepKey;
    if (key === "parent") {
      const normalizedWhatsapp = normalizeWhatsapp(form.parentWhatsapp);
      if (normalizedWhatsapp !== form.parentWhatsapp) {
        setForm((current) => ({ ...current, parentWhatsapp: normalizedWhatsapp }));
      }
      if (!form.parentName.trim()) errors.parentName = "Nama orang tua wajib diisi.";
      if (!/^62\d{8,15}$/.test(normalizedWhatsapp)) errors.parentWhatsapp = "Nomor WhatsApp belum valid.";
      if (!form.studentName.trim()) errors.studentName = "Nama anak wajib diisi.";
      if (!detectedLevel) errors.studentGradeRaw = "Pilih kelas SD/SMP/SMA yang valid.";
    }
    if (key === "schedule") {
      if (selectedBatches.length !== expectedScheduleCount) errors.schedule = `Pilih ${expectedScheduleCount} jadwal.`;
      if (selectedBatches.some((batch) => !batch.isSelectable)) errors.schedule = "Ada jadwal yang sudah penuh atau tidak tersedia.";
      if (form.packageCode === "bundling") {
        const uniqueClasses = new Set(selectedBatches.map((batch) => batch.classId));
        if (uniqueClasses.size !== selectedBatches.length) errors.schedule = "Bundling wajib memilih 3 class/software berbeda.";
      }
    }
    if (key === "addons") {
      if (needsMicrobit && !form.addons.microbit_device) errors.microbit_device = "Pilih opsi device Microbit.";
      if (needsArduino && !form.addons.arduino_device) errors.arduino_device = "Pilih opsi device Arduino.";
    }
    setFieldErrors(errors);
    if (Object.keys(errors).length > 0) {
      setError("Periksa kembali data di langkah ini.");
      return false;
    }
    return true;
  }

  function buildPayload() {
    return {
      accessToken,
      parent: {
        parentName: form.parentName,
        parentWhatsapp: normalizeWhatsapp(form.parentWhatsapp)
      },
      student: {
        studentName: form.studentName,
        studentGradeRaw: form.studentGradeRaw
      },
      packageCode: form.packageCode,
      schedules: getSchedulePayload(),
      addons: Object.entries(form.addons)
        .filter(([, choice]) => choice)
        .map(([addonCode, choice]) => ({ addonCode, choice })),
      livestreamPermission: false,
      policiesAccepted: []
    };
  }

  function getSchedulePayload() {
    if (form.packageCode === "single") {
      return form.schedules[1] ? [{ weekNo: 1, batchId: form.schedules[1] }] : [];
    }

    return [1, 2, 3]
      .map((weekNo) => ({ weekNo, batchId: form.schedules[weekNo] }))
      .filter((selection): selection is { weekNo: number; batchId: string } => Boolean(selection.batchId));
  }

  function getChosenClassIdForWeek(weekNo: number) {
    return form.scheduleClassChoices[weekNo] ?? availability.find((batch) => batch.id === form.schedules[weekNo])?.classId;
  }

  if (!config) {
    return (
      <main className="public-shell">
        <div className="loading-card">Memuat form pendaftaran...</div>
      </main>
    );
  }

  if (config.locked) {
    return (
      <main className="public-shell">
        <section className="access-card">
          <div className="brand-lockup centered">
            <img className="brand-logo-image" src={holidayAsset("clevio-logo.png")} alt="Clevio Innovator Camp" />
            <div>
              <strong>Clevio</strong>
              <span>Sekolah Partner</span>
            </div>
          </div>
          <Lock size={34} />
          <h1>{config.form.name}</h1>
          <p>Masukkan kode sekolah untuk membuka penawaran khusus sekolah partner Clevio.</p>
          <input value={accessCode} onChange={(event) => setAccessCode(event.target.value)} placeholder="Kode akses" />
          {error ? <div className="form-alert danger">{error}</div> : null}
          <button className="primary-action full" onClick={validateAccess} disabled={isPending}>
            Buka Form
          </button>
        </section>
      </main>
    );
  }

  if (success) {
    return (
      <main className="public-shell">
        <section className="success-card">
          <CheckCircle2 size={48} />
          <h1>{config.form.successTitle}</h1>
          <p>{config.form.successMessage}</p>
          <div className="success-details">
            <div>
              <span>Registration</span>
              <strong>{success.externalReference}</strong>
            </div>
            <div>
              <span>Invoice</span>
              <strong>{success.invoice.invoiceNumber}</strong>
            </div>
            <div>
              <span>Status</span>
              <strong>{success.invoice.status}</strong>
            </div>
          </div>
          {success.whatsappWarning ? <div className="form-alert warning">{success.whatsappWarning}</div> : null}
          <a className="primary-action full" href={success.invoice.shortPaymentLink || success.invoice.paymentLink} target="_blank" rel="noreferrer">
            <CreditCard size={18} />
            Buka Link Pembayaran
          </a>
        </section>
      </main>
    );
  }

  return (
    <main className={`public-shell holiday-shell${keyboardOpen ? " keyboard-open" : ""}`}>
      <img className="holiday-palm holiday-palm-tl" src={holidayAsset("palm-left.png")} alt="" aria-hidden="true" />
      <img className="holiday-palm holiday-palm-tr" src={holidayAsset("palm-right.png")} alt="" aria-hidden="true" />
      <img className="holiday-palm holiday-palm-bl" src={holidayAsset("palm-left.png")} alt="" aria-hidden="true" />
      <img className="sky-orn orn-drone" src={holidayAsset("drone.png")} alt="" aria-hidden="true" />
      <img className="sky-orn orn-seagull" src={holidayAsset("seagull.png")} alt="" aria-hidden="true" />
      <img className="sky-orn orn-seagull-2" src={holidayAsset("seagull.png")} alt="" aria-hidden="true" />
      <img className="sky-orn orn-camera" src={holidayAsset("camera.png")} alt="" aria-hidden="true" />
      <a className="form-help-chip" href="https://clev.io/chat" target="_blank" rel="noreferrer">
        <MessageCircle size={15} />
        Butuh bantuan? clev.io/chat
      </a>
      <section className="form-layout">
        <aside className="form-side">
          <img className="hero-mini-logo" src={holidayAsset("logo.png")} alt="Clevio Innovator Camp" />
          <img className="holiday-logo" src={holidayAsset("holiday-logo.png")} alt={config.program.name} />
          <p className="hero-tagline">Daftar sekarang - pilih jadwal favorit anak!</p>
          <div className="hero-badges">
            <img src={holidayAsset("date-badge.png")} alt="15 Juni 2026 sampai 5 Juli 2026, online via Zoom" />
            <img src={holidayAsset("belajar-badge.png")} alt="3 hari belajar online" />
          </div>
          <div className="hero-trust" aria-label="Fasilitas program">
            <span>
              <CalendarDays size={14} />
              3 sesi online
            </span>
            <span>
              <ShieldCheck size={14} />
              Sertifikat digital
            </span>
            <span>
              <CheckCircle2 size={14} />
              Pitching Day online
            </span>
          </div>
          <img className="holiday-robot" src={holidayAsset("robot.png")} alt="" aria-hidden="true" />
        </aside>

        <section className="form-card" data-step={activeStep.stepKey}>
          <div className="card-top">
            <p className="section-label">Pendaftaran · Holiday Class 2026</p>
            <h1>{stepTitle}</h1>
            {config.accessContext?.partnerSchool ? (
              <p className="partner-school-badge">Penawaran khusus {config.accessContext.partnerSchool.name}</p>
            ) : null}
            <div className="form-progress" aria-label={`Progress ${progressPercent}%`}>
              <div>
                <span style={{ width: `${progressPercent}%` }} />
              </div>
              <strong>{progressPercent}%</strong>
            </div>
          </div>

          <div className="stepper" aria-label="Registration progress">
            {visibleSteps.map((step, visibleIndex) => {
              const realIndex = steps.findIndex((item) => item.stepKey === step.stepKey);
              const StepIcon = getStepIcon(step.stepKey);
              const label = getStepLabel(step.stepKey, step.title);
              return (
              <button
                aria-current={realIndex === stepIndex ? "step" : undefined}
                className={realIndex === stepIndex ? "active" : visibleIndex < currentVisibleIndex ? "done" : ""}
                key={step.stepKey}
                onClick={() => realIndex < stepIndex && setStepIndex(realIndex)}
                type="button"
              >
                <span><StepIcon size={16} /></span>
                <small>{label}</small>
              </button>
            );
            })}
          </div>

          <header className="form-header">
            <div className="form-header-top">
              <p className="section-label">Step {currentVisibleIndex + 1} dari {visibleSteps.length}</p>
              <span className="form-step-badge">{activeStep?.stepKey === "summary" ? "Review akhir" : "Pendaftaran"}</span>
            </div>
            <h2>{stepTitle}</h2>
            <span>{stepDescription}</span>
          </header>

          <div className="form-context-strip" aria-label="Ringkasan sementara">
            <span>
              <ShieldCheck size={15} />
              {detectedLevel ? detectedLevel.name : "Level otomatis"}
            </span>
            <span>
              <PackageCheck size={15} />
              {selectedPackage?.name ?? "Pilih paket"}
            </span>
            <span>
              <CalendarDays size={15} />
              {selectedBatches.length > 0 ? `${selectedBatches.length}/${expectedScheduleCount} jadwal dipilih` : "Pilih jadwal"}
            </span>
          </div>

          {error ? (
            <div className="form-alert danger">
              <AlertCircle size={18} />
              {error}
            </div>
          ) : null}

          <div className="step-body" onTouchEnd={handleContentTouchEnd} onTouchMove={handleContentTouchMove} onTouchStart={handleContentTouchStart}>
            {renderStep()}
          </div>

          <footer className="form-footer">
            <button className="secondary-action" onClick={previousStep} disabled={stepIndex === 0 || isPending}>
              <ArrowLeft size={18} />
              Kembali
            </button>
            {activeStep?.stepKey === "summary" ? (
              <button className="primary-action" onClick={submit} disabled={isPending}>
                <CreditCard size={18} />
                {isPending ? "Membuat invoice..." : "Daftar & Buat Invoice"}
              </button>
            ) : (
              <button className="primary-action" onClick={nextStep} disabled={isPending}>
                Lanjut
                <ArrowRight size={18} />
              </button>
            )}
          </footer>
        </section>
      </section>
    </main>
  );

  function renderStep() {
    if (!config) return null;

    switch (activeStep?.stepKey) {
      case "parent":
        return (
          <div className="field-grid">
            <TextField label="Nama Orang Tua" value={form.parentName} onChange={(value) => update("parentName", value)} error={fieldErrors.parentName} placeholder="cth. Ibu Sari" icon={User} />
            <TextField label="Nomor WhatsApp" value={form.parentWhatsapp} onBlur={normalizeWhatsappField} onChange={updateWhatsapp} error={fieldErrors.parentWhatsapp} placeholder="62xxxxxxx" type="tel" inputMode="numeric" icon={MessageCircle} />
            <TextField label="Nama Anak" value={form.studentName} onChange={(value) => update("studentName", value)} error={fieldErrors.studentName} placeholder="Nama lengkap anak" icon={Users} />
            <label className="input-field">
              <span>Kelas Anak</span>
              <select value={form.studentGradeRaw} onChange={(event) => update("studentGradeRaw", event.target.value)}>
                <option value="">Pilih kelas</option>
                {gradeOptions.map((grade) => (
                  <option value={grade} key={grade}>{grade}</option>
                ))}
              </select>
              {fieldErrors.studentGradeRaw ? <small>{fieldErrors.studentGradeRaw}</small> : null}
            </label>
            {detectedLevel ? (
              <div className="detected-level">
                <ShieldCheck size={20} />
                <div>
                  <span>Level terdeteksi</span>
                  <strong>{detectedLevel.name} - {detectedLevel.gradeLabel}</strong>
                </div>
                <img src={holidayAsset(levelImageFor(detectedLevel.code))} alt="" aria-hidden="true" />
              </div>
            ) : null}
          </div>
        );
      case "student":
        return null;
      case "package":
        return (
          <div className="package-grid">
        {config.packages.map((pack) => {
          const price = config.pricings?.find((pricing) => pricing.packageId === pack.id && pricing.levelId === detectedLevel?.id)?.price;
          const packageBadge = packageBadgeFor(pack);
          return (
            <button className={`${form.packageCode === pack.code ? "package-card selected" : "package-card"} ${pack.code === "bundling" ? "bundle-card" : "single-card"}`} key={pack.id} onClick={() => update("packageCode", pack.code)} type="button">
              {pack.code === "bundling" ? <img className="bundle-badge" src={holidayAsset("bundling.png")} alt="" aria-hidden="true" /> : null}
              <div className="option-card-top">
                <PackageCheck size={22} />
                {packageBadge ? <small>{packageBadge}</small> : null}
              </div>
              <strong>{pack.name}</strong>
              <span>{packageDescriptionFor(pack)}</span>
              <em>{detectedLevel && price ? formatRupiah(price) : "Pilih grade dulu"}</em>
                </button>
              );
            })}
          </div>
        );
      case "schedule":
        return (
          <div className="schedule-stack">
            {form.packageCode === "single" ? (
              <SingleSchedulePicker
                availability={availability.filter((batch) => !detectedLevel || batch.levelId === detectedLevel.id)}
                classes={config.classes.filter((klass) => !detectedLevel || klass.levelId === detectedLevel.id)}
                expectedScheduleCount={expectedScheduleCount}
                levelName={detectedLevel?.name ?? "Level otomatis"}
                onBatchSelect={(batchId) => updateSchedule(1, batchId)}
                onClassSelect={(classId, autoBatchId) => updateScheduleClass(1, classId, autoBatchId)}
                packageName={selectedPackage?.name ?? "Single Class"}
                selectedBatchId={form.schedules[1]}
                selectedClassId={getChosenClassIdForWeek(1)}
                selectedCount={selectedBatches.length}
              />
            ) : (
              <BundlingSchedulePicker
                availability={availability.filter((batch) => !detectedLevel || batch.levelId === detectedLevel.id)}
                classes={config.classes.filter((klass) => !detectedLevel || klass.levelId === detectedLevel.id)}
                expectedScheduleCount={expectedScheduleCount}
                levelName={detectedLevel?.name ?? "Level otomatis"}
                onBatchSelect={updateSchedule}
                onClassSelect={updateScheduleClass}
                packageName={selectedPackage?.name ?? "Bundling Journey"}
                selectedBatchIds={form.schedules}
                selectedClassIds={[1, 2, 3].reduce<Record<number, string>>((choices, weekNo) => {
                  const classId = getChosenClassIdForWeek(weekNo);
                  if (classId) choices[weekNo] = classId;
                  return choices;
                }, {})}
                selectedCount={selectedBatches.length}
              />
            )}
            {fieldErrors.schedule ? <small className="field-error">{fieldErrors.schedule}</small> : null}
          </div>
        );
      case "addons":
        if (!needsMicrobit && !needsArduino) {
          return <div className="empty-state"><Monitor size={22} />Tidak ada device/add-on yang dibutuhkan untuk pilihan kelas ini.</div>;
        }
        return (
          <div className="addon-stack">
            {needsMicrobit ? (
              <ChoiceCard title="Microbit Device" error={fieldErrors.microbit_device} options={[["own", "Saya sudah punya device Microbit sendiri"], ["buy", "Saya ingin membeli device Microbit dari Clevio (+Rp300.000)"]]} value={form.addons.microbit_device} onChange={(value) => updateAddon("microbit_device", value)} />
            ) : null}
            {needsArduino ? (
              <ChoiceCard title="Arduino Device" error={fieldErrors.arduino_device} options={[["simulator", "Tanpa device, menggunakan simulator"], ["own", "Saya sudah punya device Arduino sendiri"], ["buy", "Saya ingin membeli device Arduino dari Clevio (+Rp350.000)"]]} value={form.addons.arduino_device} onChange={(value) => updateAddon("arduino_device", value)} />
            ) : null}
          </div>
        );
      case "agreement":
        return null;
      case "summary":
        return (
          <div className="summary-grid">
            <SummaryBlock title="Data Peserta" rows={[["Orang tua", form.parentName], ["WhatsApp", form.parentWhatsapp], ["Anak", form.studentName], ["Kelas", form.studentGradeRaw], ["Level", detectedLevel?.name ?? "-"]]} />
            <SummaryBlock title="Paket" rows={[["Paket", selectedPackage?.name ?? "-"]]} />
            <div className="summary-block">
              <h3>Jadwal</h3>
              {selectedBatches.map((batch) => (
                <p key={batch.id}>
                  <span>Week {batch.weekNo}</span>
                  <strong>{batch.className} - {batch.sessionCount} hari: {formatScheduleDateRange(batch)}, mulai {formatScheduleTime(batch)}</strong>
                </p>
              ))}
            </div>
            {reviewNotes.length > 0 ? (
              <div className="review-note">
                <Monitor size={20} />
                <div>
                  <strong>Catatan Admin</strong>
                  {reviewNotes.map((note) => <p key={note}>{note}</p>)}
                </div>
              </div>
            ) : null}
            <div className="price-box">
              <h3>Rincian Biaya</h3>
              {quote?.lineItems.map((item) => (
                <div key={`${item.name}-${item.total}`}>
                  <span>{item.name}</span>
                  <strong>{formatRupiah(item.total)}</strong>
                </div>
              ))}
              <footer>
                <span>Total</span>
                <strong>{quote ? formatRupiah(quote.total) : "Menghitung..."}</strong>
              </footer>
            </div>
          </div>
        );
      default:
        return null;
    }
  }
}

function TextField({
  label,
  value,
  onChange,
  onBlur,
  error,
  placeholder,
  type = "text",
  inputMode,
  icon: Icon
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  onBlur?: () => void;
  error?: string;
  placeholder?: string;
  type?: string;
  inputMode?: "none" | "text" | "tel" | "url" | "email" | "numeric" | "decimal" | "search";
  icon?: typeof User;
}) {
  return (
    <label className="input-field">
      <span>{label}</span>
      <div className="input-shell">
        {Icon ? <Icon size={18} /> : null}
        <input value={value} onBlur={onBlur} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} type={type} inputMode={inputMode} />
      </div>
      {error ? <small>{error}</small> : null}
    </label>
  );
}

function getStepIcon(stepKey: string) {
  if (stepKey === "parent") return Users;
  if (stepKey === "package") return PackageCheck;
  if (stepKey === "schedule") return CalendarDays;
  if (stepKey === "addons") return Monitor;
  if (stepKey === "summary") return CheckCircle2;
  return ShieldCheck;
}

function getStepLabel(stepKey: string, fallback: string) {
  if (stepKey === "parent") return "Peserta";
  if (stepKey === "package") return "Paket";
  if (stepKey === "schedule") return "Jadwal";
  if (stepKey === "addons") return "Device";
  if (stepKey === "summary") return "Review";
  return fallback;
}

function levelImageFor(code: string) {
  if (code === "explorer") return "level-1.png";
  if (code === "creator") return "level-2.png";
  if (code === "innovator") return "level-3.png";
  return "level-2.png";
}

function packageBadgeFor(pack: { code: string; maxClasses: number }) {
  if (pack.code === "single") return "1 kelas / 3 hari";
  if (pack.code === "bundling") return "";
  return pack.maxClasses > 1 ? `${pack.maxClasses} kelas` : "1 kelas";
}

function packageDescriptionFor(pack: { code: string; description: string }) {
  if (pack.code === "single") return "1 kelas dan 1 software, durasi 3 hari belajar.";
  if (pack.code === "bundling") return "3 kelas + 3 software berbeda, total 9 hari belajar.";
  return pack.description;
}

function isLegacyMinimumSpecNote(note: string) {
  return /minimum spec|spec laptop|ram 4gb|chrome terbaru|zoom terpasang|blender disarankan ram 8gb/i.test(note);
}

function SingleSchedulePicker({
  availability,
  classes,
  selectedClassId,
  selectedBatchId,
  selectedCount,
  expectedScheduleCount,
  levelName,
  packageName,
  onClassSelect,
  onBatchSelect
}: {
  availability: AvailabilityItem[];
  classes: ProgramClass[];
  selectedClassId?: string;
  selectedBatchId?: string;
  selectedCount: number;
  expectedScheduleCount: number;
  levelName: string;
  packageName: string;
  onClassSelect: (classId: string, autoBatchId?: string) => void;
  onBatchSelect: (batchId: string) => void;
}) {
  const selectedClass = classes.find((klass) => klass.id === selectedClassId);
  const batchesForClass = selectedClassId ? availability.filter((batch) => batch.classId === selectedClassId) : [];

  return (
    <div className="schedule-flow">
      <ScheduleMeta levelName={levelName} packageName={packageName} selectedCount={selectedCount} expectedScheduleCount={expectedScheduleCount} />
      <div className="schedule-info-card">
        <CalendarDays size={22} />
        <p>
          <strong>Pilih kelasnya dulu, lalu tanggal mulai.</strong>
          <span>Setiap pilihan berisi 3 hari belajar online @ 90 menit/sesi.</span>
        </p>
      </div>
      <ScheduleSectionTitle number={1} title="Pilih kelas" />
      <ClassChoiceList
        availability={availability}
        classes={classes}
        onSelect={onClassSelect}
        selectedClassId={selectedClassId}
      />
      <ScheduleSectionTitle number={2} title={`Pilih tanggal mulai${selectedClass ? ` - ${selectedClass.name}` : ""}`} />
      <DateChoiceGrid batches={batchesForClass} emptyText="Pilih kelas dulu untuk melihat tanggal mulai." onSelect={onBatchSelect} selectedBatchId={selectedBatchId} />
    </div>
  );
}

function BundlingSchedulePicker({
  availability,
  classes,
  selectedClassIds,
  selectedBatchIds,
  selectedCount,
  expectedScheduleCount,
  levelName,
  packageName,
  onClassSelect,
  onBatchSelect
}: {
  availability: AvailabilityItem[];
  classes: ProgramClass[];
  selectedClassIds: Record<number, string>;
  selectedBatchIds: Record<number, string>;
  selectedCount: number;
  expectedScheduleCount: number;
  levelName: string;
  packageName: string;
  onClassSelect: (weekNo: number, classId: string, autoBatchId?: string) => void;
  onBatchSelect: (weekNo: number, batchId: string) => void;
}) {
  return (
    <div className="schedule-flow bundle-flow">
      <ScheduleMeta levelName={levelName} packageName={packageName} selectedCount={selectedCount} expectedScheduleCount={expectedScheduleCount} />
      <div className="schedule-info-card">
        <CalendarDays size={22} />
        <p>
          <strong>Bundling = 3 kelas berbeda, total 9 hari belajar.</strong>
          <span>Pilih kelas dan tanggal mulai untuk Minggu 1, Minggu 2, dan Minggu 3.</span>
        </p>
      </div>
      {[1, 2, 3].map((weekNo) => {
        const weekBatches = availability.filter((batch) => batch.weekNo === weekNo);
        const selectedClassId = selectedClassIds[weekNo];
        const selectedClass = classes.find((klass) => klass.id === selectedClassId);
        const selectedByOtherWeeks = Object.entries(selectedClassIds)
          .filter(([otherWeek]) => Number(otherWeek) !== weekNo)
          .map(([, classId]) => classId);
        const batchesForClass = selectedClassId ? weekBatches.filter((batch) => batch.classId === selectedClassId) : [];

        return (
          <section className="bundle-week-panel" key={weekNo}>
            <div className="bundle-week-head">
              <span>Minggu {weekNo}</span>
              <strong>{selectedClass ? selectedClass.name : "Pilih kelas dan tanggal"}</strong>
            </div>
            <ScheduleSectionTitle number={1} title="Pilih kelas" />
            <ClassChoiceList
              autoSelectSingleDate
              availability={weekBatches}
              classes={classes}
              disabledClassIds={selectedByOtherWeeks}
              onSelect={(classId, autoBatchId) => onClassSelect(weekNo, classId, autoBatchId)}
              selectedClassId={selectedClassId}
            />
            <ScheduleSectionTitle number={2} title={`Pilih tanggal mulai${selectedClass ? ` - ${selectedClass.name}` : ""}`} />
            <DateChoiceGrid
              batches={batchesForClass}
              emptyText="Pilih kelas untuk minggu ini dulu."
              onSelect={(batchId) => onBatchSelect(weekNo, batchId)}
              selectedBatchId={selectedBatchIds[weekNo]}
            />
          </section>
        );
      })}
    </div>
  );
}

function ScheduleMeta({
  levelName,
  packageName,
  selectedCount,
  expectedScheduleCount
}: {
  levelName: string;
  packageName: string;
  selectedCount: number;
  expectedScheduleCount: number;
}) {
  return (
    <div className="schedule-choice-meta" aria-label="Konteks pilihan jadwal">
      <span>
        <ShieldCheck size={15} />
        {levelName}
      </span>
      <span>
        <PackageCheck size={15} />
        {packageName}
      </span>
      <span>
        <CalendarDays size={15} />
        {selectedCount} / {expectedScheduleCount} jadwal
      </span>
    </div>
  );
}

function ScheduleSectionTitle({ number, title }: { number: number; title: string }) {
  return (
    <div className="schedule-section-title">
      <span>{number}</span>
      <h3>{title}</h3>
    </div>
  );
}

function ClassChoiceList({
  classes,
  availability,
  selectedClassId,
  disabledClassIds = [],
  autoSelectSingleDate = false,
  onSelect
}: {
  classes: ProgramClass[];
  availability: AvailabilityItem[];
  selectedClassId?: string;
  disabledClassIds?: string[];
  autoSelectSingleDate?: boolean;
  onSelect: (classId: string, autoBatchId?: string) => void;
}) {
  const activeClasses = classes.filter((klass) => klass.isActive !== false).sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name));

  if (activeClasses.length === 0) {
    return <div className="schedule-empty-inline">Pilih kelas anak dulu untuk melihat pilihan kelas.</div>;
  }

  return (
    <div className="class-choice-list">
      {activeClasses.map((klass) => {
        const classBatches = availability.filter((batch) => batch.classId === klass.id);
        const selectableBatches = classBatches.filter((batch) => batch.isSelectable);
        const duplicate = disabledClassIds.includes(klass.id);
        const disabled = duplicate || classBatches.length === 0 || selectableBatches.length === 0;
        const autoBatchId = autoSelectSingleDate && selectableBatches.length === 1 ? selectableBatches[0].id : undefined;
        const meta = duplicate
          ? "Sudah dipilih di minggu lain"
          : classBatches.length === 0
            ? "Jadwal belum tersedia"
            : selectableBatches.length === 0
              ? "Tanggal penuh atau ditutup"
              : classDescriptionFor(klass);

        return (
          <button
            className={`class-choice-card${selectedClassId === klass.id ? " selected" : ""}`}
            disabled={disabled}
            key={klass.id}
            onClick={() => onSelect(klass.id, autoBatchId)}
            type="button"
          >
            <span className="class-radio" aria-hidden="true" />
            <span className="class-icon">
              <PackageCheck size={18} />
            </span>
            <span className="class-copy">
              <strong>{klass.name}</strong>
              <small>{meta}</small>
            </span>
            {deviceBadgeFor(klass) ? <em className="device-mini-badge">{deviceBadgeFor(klass)}</em> : null}
          </button>
        );
      })}
    </div>
  );
}

function DateChoiceGrid({
  batches,
  selectedBatchId,
  emptyText,
  onSelect
}: {
  batches: AvailabilityItem[];
  selectedBatchId?: string;
  emptyText: string;
  onSelect: (batchId: string) => void;
}) {
  const sortedBatches = [...batches].sort((a, b) => a.startsAt.localeCompare(b.startsAt));

  if (sortedBatches.length === 0) {
    return <div className="schedule-empty-inline">{emptyText}</div>;
  }

  return (
    <div className="date-choice-grid">
      {sortedBatches.map((batch) => {
        const dateParts = getDateTileParts(batch);
        return (
          <button
            className={`date-choice-card${selectedBatchId === batch.id ? " selected" : ""}`}
            disabled={!batch.isSelectable}
            key={batch.id}
            onClick={() => onSelect(batch.id)}
            type="button"
          >
            <span className="date-tile">
              <strong>{dateParts.day}</strong>
              <small>{dateParts.month}</small>
            </span>
            <span className="date-copy">
              <strong>{dateParts.weekday}</strong>
              <small>Minggu {batch.weekNo} - {formatScheduleTime(batch)}</small>
              <em>{batch.sessionCount} hari: {formatScheduleDateRange(batch)}</em>
            </span>
            {!batch.isSelectable ? <span className="date-status closed">Tidak tersedia</span> : null}
          </button>
        );
      })}
    </div>
  );
}

function getDateTileParts(batch: AvailabilityItem) {
  const date = new Date(batch.firstSessionAt);
  const weekday = new Intl.DateTimeFormat("id-ID", { weekday: "long", timeZone: batch.timezone }).format(date);
  const day = new Intl.DateTimeFormat("id-ID", { day: "2-digit", timeZone: batch.timezone }).format(date);
  const month = new Intl.DateTimeFormat("id-ID", { month: "short", timeZone: batch.timezone }).format(date).replace(".", "").toUpperCase();
  return { weekday, day, month };
}

function classDescriptionFor(klass: ProgramClass) {
  if (klass.description) return klass.description;
  if (klass.slug === "kodu") return "Membuat game sederhana dengan logika visual.";
  if (klass.slug === "scratch-jr") return "Cerita interaktif dan coding awal untuk anak.";
  if (klass.slug === "minecraft-builder") return "Bangun dunia kreatif di Minecraft.";
  if (klass.slug === "minecraft-coding") return "Belajar logika lewat Minecraft.";
  if (klass.slug === "microbit") return "Pemrograman perangkat fisik micro:bit.";
  if (klass.slug === "app-inventor") return "Bikin aplikasi Android sederhana.";
  if (klass.slug === "blender-3d") return "Membuat model 3D sederhana.";
  if (klass.slug === "vibe-coding") return "Membuat aplikasi dengan bantuan AI.";
  if (klass.slug === "n8n-automation") return "Belajar alur automation visual.";
  if (klass.slug === "arduino") return "Simulasi dan project Arduino dasar.";
  return "Kelas kreatif teknologi untuk anak.";
}

function deviceBadgeFor(klass: ProgramClass) {
  if (klass.slug === "microbit") return "Perlu device";
  if (klass.slug === "arduino") return "Device opsional";
  if (klass.requiresDevice) return "Perlu device";
  return null;
}

function ChoiceCard({
  title,
  options,
  value,
  error,
  onChange
}: {
  title: string;
  options: Array<[string, string]>;
  value?: string;
  error?: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className="choice-card">
      <strong>{title}</strong>
      {options.map(([optionValue, label]) => (
        <label className={value === optionValue ? "selected" : ""} key={optionValue}>
          <input type="radio" checked={value === optionValue} onChange={() => onChange(optionValue)} />
          <span>{label}</span>
        </label>
      ))}
      {error ? <small>{error}</small> : null}
    </div>
  );
}

function SummaryBlock({ title, rows }: { title: string; rows: Array<[string, string]> }) {
  return (
    <div className="summary-block">
      <h3>{title}</h3>
      {rows.map(([label, value]) => (
        <p key={label}>
          <span>{label}</span>
          <strong>{value}</strong>
        </p>
      ))}
    </div>
  );
}
