import { headers } from "next/headers";
import { redirect } from "next/navigation";
import crypto from "node:crypto";
import { NextResponse } from "next/server";
import { appPath } from "@/lib/constants";

type LmsAdminSession = {
  user: {
    id: string;
    username?: string;
    fullName?: string;
    role: "ADMIN";
    isActive: boolean;
  };
};

type LmsSessionResponse = {
  user?: {
    id?: unknown;
    username?: unknown;
    fullName?: unknown;
    role?: unknown;
    isActive?: unknown;
  };
};

const LMS_SESSION_PATH = "/api/auth/session";

function getLmsBaseUrl() {
  return process.env.LMS_API_BASE_URL || "http://127.0.0.1:3005";
}

function normalizeLmsSession(value: LmsSessionResponse): LmsAdminSession | null {
  const user = value.user;
  if (!user || typeof user.id !== "string") return null;
  if (user.role !== "ADMIN" || user.isActive !== true) return null;

  return {
    user: {
      id: user.id,
      username: typeof user.username === "string" ? user.username : undefined,
      fullName: typeof user.fullName === "string" ? user.fullName : undefined,
      role: "ADMIN",
      isActive: true
    }
  };
}

export async function getAdminSessionFromCookieHeader(cookieHeader: string | null) {
  if (!cookieHeader) return null;

  try {
    const response = await fetch(`${getLmsBaseUrl()}${LMS_SESSION_PATH}`, {
      headers: { cookie: cookieHeader },
      cache: "no-store"
    });
    if (!response.ok) return null;

    const data = (await response.json()) as LmsSessionResponse;
    return normalizeLmsSession(data);
  } catch (error) {
    console.error("[event-manager-auth] Failed to validate LMS admin session", error);
    return null;
  }
}

export async function getAdminSession() {
  const headerStore = await headers();
  return getAdminSessionFromCookieHeader(headerStore.get("cookie"));
}

export async function requireAdminPage() {
  const session = await getAdminSession();
  if (!session) {
    redirect(appPath("/admin/login"));
  }
  return session;
}

export async function requireAdminRequest(request: Request) {
  const session = await getAdminSessionFromCookieHeader(request.headers.get("cookie"));
  if (session) return null;

  return NextResponse.json(
    {
      ok: false,
      message: "Unauthorized. Login sebagai admin LMS dulu untuk akses Event Manager."
    },
    { status: 401 }
  );
}

export async function requireAdminOrJobRequest(request: Request) {
  if (isValidJobToken(request.headers.get("authorization"))) return null;
  return requireAdminRequest(request);
}

export async function getAdminActor(request: Request) {
  const session = await getAdminSessionFromCookieHeader(request.headers.get("cookie"));
  return {
    adminId: session?.user.id,
    ipAddress: request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? request.headers.get("x-real-ip") ?? "127.0.0.1",
    userAgent: request.headers.get("user-agent") ?? "unknown"
  };
}

function isValidJobToken(header: string | null) {
  const expected = process.env.EVENT_MANAGER_JOB_TOKEN;
  if (!expected || !header) return false;
  const provided = header.replace(/^Bearer\s+/i, "").trim();
  if (provided.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(expected));
}
