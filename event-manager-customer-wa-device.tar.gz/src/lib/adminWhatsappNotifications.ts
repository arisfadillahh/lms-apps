import { formatRupiah, formatScheduleDateRange, formatScheduleTime } from "@/lib/formEngine";
import { LmsClient } from "@/lib/lmsClient";
import { hasSuccessfulWhatsappLog, recordIntegrationLog, recordWhatsappLog } from "@/lib/repository";
import type { PaymentConfirmationWhatsappContext, ProgramBatch, ProgramClass } from "@/lib/types";

const DEFAULT_ADMIN_GROUP_JID = "120363299465478999@g.us";

type RegistrationCreatedNotificationInput = {
  registrationId: string;
  externalReference: string;
  parentName: string;
  parentWhatsapp: string;
  studentName: string;
  programName: string;
  packageName?: string | null;
  levelName?: string | null;
  partnerSchoolName?: string | null;
  studentGrade?: string | null;
  studentSchool?: string | null;
  addonLines?: string[];
  total: number;
  invoiceNumber?: string | null;
  paymentLink?: string | null;
  selectedBatches: ProgramBatch[];
  selectedClasses: ProgramClass[];
};

export async function sendAdminRegistrationCreatedNotification(input: RegistrationCreatedNotificationInput) {
  const scheduleLines = input.selectedBatches.map((batch) => {
    const klass = input.selectedClasses.find((item) => item.id === batch.classId);
    return `Minggu ${batch.weekNo}: ${klass?.name ?? "Kelas"} (${formatScheduleDateRange(batch)}, ${formatScheduleTime(batch)})`;
  });

  const message = [
    "*Pendaftaran Baru*",
    "",
    `*Ref:* ${input.externalReference}`,
    `*Program:* ${input.programName}`,
    `*Anak:* ${input.studentName}`,
    input.studentGrade ? `*Kelas:* ${input.studentGrade}` : null,
    input.studentSchool ? `*Sekolah:* ${input.studentSchool}` : null,
    `*Orang tua:* ${input.parentName}`,
    `*WA:* ${input.parentWhatsapp}`,
    input.levelName ? `*Level:* ${input.levelName}` : null,
    input.packageName ? `*Paket:* ${input.packageName}` : null,
    input.partnerSchoolName ? `*Sekolah partner:* ${input.partnerSchoolName}` : null,
    `*Total:* ${formatRupiah(input.total)}`,
    "*Status:* Menunggu pembayaran",
    input.invoiceNumber ? `*Invoice:* ${input.invoiceNumber}` : null,
    input.paymentLink ? `*Link bayar:* ${input.paymentLink}` : null,
    "",
    "*Jadwal:*",
    ...formatNumberedLines(scheduleLines),
    input.addonLines?.length ? "" : null,
    input.addonLines?.length ? "*Device/Add-on:*" : null,
    ...(input.addonLines?.length ? formatNumberedLines(input.addonLines) : [])
  ].filter((line): line is string => Boolean(line)).join("\n");

  await sendAdminGroupMessage({
    registrationId: input.registrationId,
    messageType: "admin_registration_created",
    action: "send_admin_registration_created",
    successMessage: `${input.externalReference} registration update sent to admin group`,
    failureFallback: "Admin registration group notification failed",
    message
  });
}

export async function sendAdminPaymentConfirmedNotification(externalReference: string, context: PaymentConfirmationWhatsappContext, paidAt?: string | null) {
  const alreadySent = await hasSuccessfulWhatsappLog(context.registrationId, "admin_payment_confirmed");
  if (alreadySent) {
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: "send_admin_payment_confirmed",
      status: "ignored",
      message: `${externalReference} admin payment notification already sent`
    });
    return;
  }

  const paymentLink = context.shortPaymentLink || context.paymentLink;
  const message = [
    "*Pembayaran Diterima*",
    "",
    `*Ref:* ${externalReference}`,
    `*Program:* ${context.programName}`,
    `*Anak:* ${context.studentName}`,
    `*Orang tua:* ${context.parentName}`,
    `*WA:* ${context.parentWhatsapp}`,
    context.levelName ? `*Level:* ${context.levelName}` : null,
    context.packageName ? `*Paket:* ${context.packageName}` : null,
    context.partnerSchoolName ? `*Sekolah partner:* ${context.partnerSchoolName}` : null,
    `*Total dibayar:* ${formatRupiah(context.total)}`,
    "*Status:* Terkonfirmasi",
    context.invoiceNumber ? `*Invoice:* ${context.invoiceNumber}` : null,
    paymentLink ? `*Link invoice:* ${paymentLink}` : null,
    paidAt ?? context.paidAt ? `_Dibayar: ${formatDateTime(paidAt ?? context.paidAt)}_` : null,
    "",
    "*Jadwal:*",
    ...(context.scheduleLines.length > 0 ? formatNumberedLines(context.scheduleLines) : ["Belum ada jadwal"])
  ].filter((line): line is string => Boolean(line)).join("\n");

  await sendAdminGroupMessage({
    registrationId: context.registrationId,
    invoiceReferenceId: context.invoiceReferenceId,
    messageType: "admin_payment_confirmed",
    action: "send_admin_payment_confirmed",
    successMessage: `${externalReference} payment update sent to admin group`,
    failureFallback: "Admin payment group notification failed",
    message
  });
}

async function sendAdminGroupMessage(input: {
  registrationId: string;
  invoiceReferenceId?: string | null;
  messageType: string;
  action: string;
  successMessage: string;
  failureFallback: string;
  message: string;
}) {
  const groupJid = process.env.EVENT_MANAGER_ADMIN_WA_GROUP_JID || DEFAULT_ADMIN_GROUP_JID;
  const alreadySent = await hasSuccessfulWhatsappLog(input.registrationId, input.messageType);
  if (alreadySent) {
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: input.action,
      status: "ignored",
      message: `${input.messageType} already sent to admin group`
    });
    return;
  }

  const lms = new LmsClient();
  try {
    const response = await lms.sendWhatsAppMessage({
      to: groupJid,
      message: input.message
    });
    await recordWhatsappLog({
      registrationId: input.registrationId,
      invoiceReferenceId: input.invoiceReferenceId,
      messageType: input.messageType,
      recipient: groupJid,
      messagePreview: input.message.slice(0, 480),
      response,
      status: "success"
    });
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: input.action,
      status: "success",
      message: input.successMessage
    });
  } catch (error) {
    const messageError = error instanceof Error ? error.message : input.failureFallback;
    await recordWhatsappLog({
      registrationId: input.registrationId,
      invoiceReferenceId: input.invoiceReferenceId,
      messageType: input.messageType,
      recipient: groupJid,
      messagePreview: input.message.slice(0, 480),
      status: "failed",
      errorMessage: messageError
    });
    await recordIntegrationLog({
      integration: "LMS WhatsApp",
      action: input.action,
      status: "failed",
      message: messageError
    });
  }
}

function formatDateTime(value?: string | null) {
  if (!value) return "";
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  }).format(new Date(value));
}

function formatNumberedLines(lines: string[]) {
  return lines.map((line, index) => `${index + 1}. ${line}`);
}
