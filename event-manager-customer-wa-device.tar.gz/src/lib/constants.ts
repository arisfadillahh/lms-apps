export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || "/event-manager";
export const DEFAULT_EVENT_MANAGER_PORT = 3007;

export function appPath(path: string) {
  return path.startsWith("/") ? path : `/${path}`;
}

export function apiPath(path: string) {
  const normalized = path.startsWith("/api") ? path : `/api${path}`;
  return `${BASE_PATH}${normalized}`;
}
