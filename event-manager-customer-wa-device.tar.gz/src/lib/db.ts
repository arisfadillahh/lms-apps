import { Pool, type PoolClient, type QueryResultRow } from "pg";

let pool: Pool | null = null;

export function hasDatabase() {
  return Boolean(process.env.EVENT_MANAGER_DATABASE_URL || process.env.DATABASE_URL);
}

function getConnectionString() {
  return process.env.EVENT_MANAGER_DATABASE_URL || process.env.DATABASE_URL;
}

export function getPool() {
  const connectionString = getConnectionString();
  if (!connectionString) {
    throw new Error("Missing EVENT_MANAGER_DATABASE_URL or DATABASE_URL");
  }

  if (!pool) {
    pool = new Pool({
      connectionString,
      max: Number(process.env.EVENT_MANAGER_DB_POOL_MAX ?? 8),
      ssl: process.env.EVENT_MANAGER_DB_SSL === "true" ? { rejectUnauthorized: false } : undefined
    });
  }

  return pool;
}

export async function query<T extends QueryResultRow = QueryResultRow>(text: string, params: unknown[] = []) {
  return getPool().query<T>(text, params);
}

export async function withTransaction<T>(fn: (client: PoolClient) => Promise<T>) {
  const client = await getPool().connect();
  try {
    await client.query("begin");
    const result = await fn(client);
    await client.query("commit");
    return result;
  } catch (error) {
    await client.query("rollback");
    throw error;
  } finally {
    client.release();
  }
}
