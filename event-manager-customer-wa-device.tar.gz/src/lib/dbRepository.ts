import crypto, { randomUUID } from "node:crypto";
import type { PoolClient, QueryResultRow } from "pg";
import { buildAvailability, calculateQuote, normalizeGrade, parseAccessToken, signAccessToken } from "@/lib/formEngine";
import { query, withTransaction } from "@/lib/db";
import { buildEventCertificateWhatsAppMessage, LmsClient, type LmsInvoicePayload } from "@/lib/lmsClient";
import type {
  AdminSnapshot,
  AvailabilityItem,
  FormConfig,
  FormErrorCode,
  InvoiceReference,
  PaymentConfirmationWhatsappContext,
  Program,
  ProgramAddon,
  ProgramBatch,
  ProgramClass,
  ProgramForm,
  ProgramFormField,
  ProgramFormStep,
  ProgramLevel,
  ProgramPackage,
  ProgramPricing,
  ProgramSession,
  PartnerSchool,
  QuoteResult,
  RegistrationPaymentContext,
  RegistrationStatus,
  SubmitRequest
} from "@/lib/types";

type IntegrationLogInput = {
  integration: string;
  action: string;
  status: string;
  message: string;
};

type WhatsAppLogInput = {
  registrationId?: string | null;
  invoiceReferenceId?: string | null;
  messageType: string;
  recipient: string;
  messagePreview?: string | null;
  response?: unknown;
  status: string;
  errorMessage?: string | null;
};

type WebhookPayload = {
  invoice_id: string;
  external_reference: string;
  status: "paid" | "expired" | "cancelled" | string;
  paid_at?: string;
  amount?: number;
};

type NormalizedLmsInvoicePayload = WebhookPayload & {
  invoice_number?: string | null;
  payment_link?: string | null;
  short_payment_link?: string | null;
  expired_at?: string | null;
};

type RuntimeRegistration = {
  id: string;
  externalReference: string;
  status: RegistrationStatus;
};

type AdminActor = {
  adminId?: string;
  ipAddress?: string | null;
  userAgent?: string | null;
};

type CertificateTemplateInput = {
  programId?: string | null;
  name?: string;
  backgroundUrl?: string | null;
  previewImageUrl?: string | null;
  primaryColor?: string | null;
  accentColor?: string | null;
  logoUrl?: string | null;
  signatureName?: string | null;
  notes?: string | null;
};

type ConfigRows = {
  formRow: QueryResultRow;
  levels: QueryResultRow[];
  classes: QueryResultRow[];
  packages: QueryResultRow[];
  pricings: QueryResultRow[];
  addons: QueryResultRow[];
  batches: QueryResultRow[];
  sessions: QueryResultRow[];
  steps: QueryResultRow[];
  fields: QueryResultRow[];
};

const ACCESS_RATE_LIMIT = 5;
const ACCESS_RATE_WINDOW_MINUTES = 10;

function toDateString(value: unknown) {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return String(value ?? "");
}

function toIsoString(value: unknown) {
  if (value instanceof Date) return value.toISOString();
  return String(value ?? "");
}

function formatScheduleDate(value: unknown) {
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  }).format(new Date(value instanceof Date ? value : String(value)));
}

function formatAddonChoiceLabel(choice?: string | null) {
  if (choice === "buy") return "Beli dari Clevio";
  if (choice === "own") return "Punya sendiri";
  if (choice === "simulator") return "Pakai simulator";
  return choice || "-";
}

function formatCertificateDate(value: unknown) {
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Asia/Jakarta"
  }).format(new Date(value instanceof Date ? value : String(value)));
}

function formatProgramDateRange(start: unknown, end: unknown) {
  if (!start || !end) return null;
  return `${formatCertificateDate(start)} - ${formatCertificateDate(end)}`;
}

function toInt(value: unknown) {
  return Number(value ?? 0);
}

function sha256(value: string) {
  return crypto.createHash("sha256").update(value.trim()).digest("hex");
}

function mapProgram(row: QueryResultRow): Program {
  return {
    id: row.program_id,
    slug: row.program_slug,
    name: row.program_name,
    description: row.program_description ?? undefined,
    periodStart: toDateString(row.period_start),
    periodEnd: toDateString(row.period_end),
    mode: row.mode,
    platform: row.platform ?? "",
    registrationOpenAt: row.registration_open_at ? toIsoString(row.registration_open_at) : undefined,
    registrationCloseAt: row.registration_close_at ? toIsoString(row.registration_close_at) : undefined,
    registrationDeadlineRule: row.registration_deadline_rule ?? row.registration_cutoff_rule ?? undefined,
    defaultSessionDurationMinutes: toInt(row.default_session_duration_minutes),
    defaultQuotaPerBatch: toInt(row.default_quota_per_batch),
    noMinimumParticipant: row.no_minimum_participant === true,
    hasLevels: row.has_levels === true,
    hasPackages: row.has_packages !== false,
    hasBundling: row.has_bundling === true,
    hasAddons: row.has_addons === true,
    hasScheduleSelection: row.has_schedule_selection !== false,
    hasAttendance: row.has_attendance === true,
    hasPitchingDay: row.has_pitching_day === true,
    hasCertificates: row.has_certificates === true,
    hasLivestreamPermission: row.has_livestream_permission === true,
    hasWhatsappAutomation: row.has_whatsapp_automation !== false,
    adminNotes: row.program_admin_notes ?? undefined
  };
}

function mapForm(row: QueryResultRow): ProgramForm {
  return {
    id: row.form_id,
    programId: row.program_id,
    slug: row.form_slug,
    name: row.form_name,
    description: row.form_description ?? "",
    templateKey: row.template_key,
    priceType: row.price_type,
    accessType: row.access_type,
    status: row.form_status,
    maxSubmissions: row.max_submissions,
    successTitle: row.success_title ?? "Invoice berhasil dibuat",
    successMessage: row.success_message ?? "Silakan lanjutkan pembayaran melalui link invoice."
  };
}

function mapPartnerSchool(row: QueryResultRow): PartnerSchool {
  return {
    id: row.id,
    programId: row.program_id,
    slug: row.slug,
    name: row.name,
    status: row.status,
    priceType: row.price_type ?? undefined,
    adminNotes: row.admin_notes ?? undefined
  };
}

function mapLevel(row: QueryResultRow): ProgramLevel {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    gradeMin: toInt(row.grade_min),
    gradeMax: toInt(row.grade_max),
    gradeLabel: row.grade_label,
    description: row.description ?? undefined,
    isActive: row.is_active !== false,
    sortOrder: toInt(row.sort_order)
  };
}

function mapClass(row: QueryResultRow): ProgramClass {
  return {
    id: row.id,
    levelId: row.level_id,
    slug: row.slug,
    name: row.name,
    softwareKey: row.software_key,
    requiresDevice: row.requires_device === true,
    description: row.description ?? undefined,
    outputDescription: row.output_description ?? undefined,
    requirements: row.requirements ?? undefined,
    deviceRequirementSetting: row.device_requirement_setting ?? undefined,
    isActive: row.is_active !== false,
    sortOrder: toInt(row.sort_order)
  };
}

function mapPackage(row: QueryResultRow): ProgramPackage {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    description: row.description ?? "",
    minClasses: toInt(row.min_classes),
    maxClasses: toInt(row.max_classes),
    sameLevelOnly: row.same_level_only === true,
    uniqueClassRequired: row.unique_class_required === true,
    uniqueSoftwareRequired: row.unique_software_required === true,
    oneClassPerWeek: row.one_class_per_week === true,
    requiredWeekCount: row.required_week_count ?? undefined,
    allowCustomSelection: row.allow_custom_selection !== false,
    isActive: row.is_active !== false
  };
}

function mapPricing(row: QueryResultRow): ProgramPricing {
  return {
    id: row.id,
    priceType: row.price_type,
    levelId: row.level_id,
    packageId: row.package_id,
    price: toInt(row.price),
    currency: row.currency,
    effectiveFrom: row.effective_from ? toIsoString(row.effective_from) : undefined,
    effectiveUntil: row.effective_until ? toIsoString(row.effective_until) : undefined,
    isActive: row.is_active !== false,
    lastEditedByAdmin: row.last_edited_by_admin ?? undefined
  };
}

function mapAddon(row: QueryResultRow): ProgramAddon {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    price: toInt(row.price),
    appliesToClassId: row.applies_to_class_id,
    selectionType: row.selection_type,
    isRequiredChoice: row.is_required_choice === true,
    description: row.description ?? row.admin_notes ?? undefined,
    choices: Array.isArray(row.choices_json) ? row.choices_json : undefined,
    isActive: row.is_active !== false
  };
}

function mapBatch(row: QueryResultRow): ProgramBatch {
  return {
    id: row.id,
    classId: row.class_id,
    levelId: row.level_id ?? null,
    batchCode: row.batch_code,
    batchName: row.batch_name ?? undefined,
    weekNo: toInt(row.week_no),
    startsAt: toIsoString(row.starts_at),
    endsAt: toIsoString(row.ends_at),
    timezone: row.timezone,
    quota: toInt(row.quota),
    reservedCount: toInt(row.actual_reserved_count ?? row.reserved_count),
    confirmedCount: toInt(row.actual_confirmed_count ?? row.confirmed_count),
    status: row.status,
    notes: row.notes ?? undefined
  };
}

function mapSession(row: QueryResultRow): ProgramSession {
  return {
    id: row.id,
    batchId: row.batch_id,
    sessionNo: toInt(row.session_no),
    title: row.title ?? `Session ${row.session_no}`,
    startsAt: toIsoString(row.starts_at),
    endsAt: toIsoString(row.ends_at),
    durationMinutes: toInt(row.duration_minutes),
    meetingPlatform: row.meeting_platform ?? "",
    meetingUrl: row.meeting_url ?? undefined,
    meetingLocation: row.meeting_location ?? undefined,
    notes: row.notes ?? undefined
  };
}

function mapStep(row: QueryResultRow): ProgramFormStep {
  return {
    id: row.id,
    stepKey: row.step_key,
    title: row.title,
    description: row.description ?? "",
    adminReviewNotes: row.admin_review_notes ?? undefined,
    sortOrder: toInt(row.sort_order)
  };
}

function mapField(row: QueryResultRow): ProgramFormField {
  return {
    id: row.id,
    stepKey: row.step_key,
    fieldKey: row.field_key,
    label: row.label,
    helpText: row.help_text ?? undefined,
    placeholder: row.placeholder ?? undefined,
    fieldType: row.field_type,
    isRequired: row.is_required === true,
    options: Array.isArray(row.options_json) ? row.options_json : undefined,
    validation: row.validation_json ?? undefined,
    visibility: row.visibility_json ?? undefined,
    ui: row.ui_json ?? undefined,
    sortOrder: toInt(row.sort_order)
  };
}

async function loadConfigRowsBySlug(slug: string): Promise<ConfigRows | null> {
  const formResult = await query(
    `
      select
        f.id as form_id,
        f.slug as form_slug,
        f.name as form_name,
        f.description as form_description,
        f.template_key,
        f.price_type,
        f.access_type,
        f.status as form_status,
        f.starts_at,
        f.ends_at,
        f.max_submissions,
        f.success_title,
        f.success_message,
        f.access_code_hash,
        p.id as program_id,
        p.slug as program_slug,
        p.name as program_name,
        p.description as program_description,
        p.period_start,
        p.period_end,
        p.mode,
        p.platform,
        p.registration_open_at,
        p.registration_close_at,
        p.registration_cutoff_rule,
        p.registration_deadline_rule,
        p.default_session_duration_minutes,
        p.default_quota_per_batch,
        p.no_minimum_participant,
        p.has_levels,
        p.has_packages,
        p.has_bundling,
        p.has_addons,
        p.has_schedule_selection,
        p.has_attendance,
        p.has_pitching_day,
        p.has_certificates,
        p.has_livestream_permission,
        p.has_whatsapp_automation,
        p.admin_notes as program_admin_notes
      from program_forms f
      join programs p on p.id = f.program_id
      where f.slug = $1
        and f.is_active = true
      limit 1
    `,
    [slug]
  );

  const formRow = formResult.rows[0];
  if (!formRow) return null;

  return loadConfigRowsByFormRow(formRow);
}

async function loadConfigRowsByProgramId(programId: string): Promise<ConfigRows | null> {
  const formResult = await query(
    `
      select
        f.id as form_id,
        f.slug as form_slug,
        f.name as form_name,
        f.description as form_description,
        f.template_key,
        f.price_type,
        f.access_type,
        f.status as form_status,
        f.starts_at,
        f.ends_at,
        f.max_submissions,
        f.success_title,
        f.success_message,
        f.access_code_hash,
        p.id as program_id,
        p.slug as program_slug,
        p.name as program_name,
        p.description as program_description,
        p.period_start,
        p.period_end,
        p.mode,
        p.platform,
        p.registration_open_at,
        p.registration_close_at,
        p.registration_cutoff_rule,
        p.registration_deadline_rule,
        p.default_session_duration_minutes,
        p.default_quota_per_batch,
        p.no_minimum_participant,
        p.has_levels,
        p.has_packages,
        p.has_bundling,
        p.has_addons,
        p.has_schedule_selection,
        p.has_attendance,
        p.has_pitching_day,
        p.has_certificates,
        p.has_livestream_permission,
        p.has_whatsapp_automation,
        p.admin_notes as program_admin_notes
      from programs p
      join program_forms f on f.program_id = p.id and f.is_active = true
      where p.id = $1
      order by case when f.access_type = 'public' then 0 else 1 end, f.created_at
      limit 1
    `,
    [programId]
  );

  const formRow = formResult.rows[0];
  if (!formRow) return null;

  return loadConfigRowsByFormRow(formRow);
}

async function loadConfigRowsByFormRow(formRow: QueryResultRow): Promise<ConfigRows> {
  const programId = formRow.program_id;
  const formId = formRow.form_id;
  const [
    levels,
    classes,
    packages,
    pricings,
    addons,
    batches,
    sessions,
    steps,
    fields
  ] = await Promise.all([
    query("select * from program_levels where program_id = $1 order by sort_order, grade_min", [programId]),
    query("select * from program_classes where program_id = $1 and is_active = true order by sort_order, name", [programId]),
    query("select * from program_packages where program_id = $1 and is_active = true order by min_classes, name", [programId]),
    query(
      "select * from program_pricings where program_id = $1 and is_active = true and (effective_from is null or effective_from <= now()) and (effective_until is null or effective_until >= now())",
      [programId]
    ),
    query("select * from program_addons where program_id = $1 and is_active = true order by code", [programId]),
    query(
      `
        select
          b.*,
          coalesce(count(ri.id) filter (
            where ri.slot_status = 'reserved'
              and r.status in ('pending_invoice', 'waiting_payment')
              and (r.reservation_expires_at is null or r.reservation_expires_at > now())
          ), 0)::int as actual_reserved_count,
          coalesce(count(ri.id) filter (
            where ri.slot_status = 'confirmed'
              and r.status in ('paid', 'confirmed', 'completed')
          ), 0)::int as actual_confirmed_count
        from program_batches b
        left join registration_items ri on ri.program_batch_id = b.id
        left join registrations r on r.id = ri.registration_id
        where b.program_id = $1
        group by b.id
        order by b.week_no, b.starts_at
      `,
      [programId]
    ),
    query(
      `
        select s.*
        from program_sessions s
        join program_batches b on b.id = s.batch_id
        where b.program_id = $1
        order by b.week_no, b.starts_at, s.session_no
      `,
      [programId]
    ),
    query("select * from program_form_steps where form_id = $1 and is_active = true order by sort_order", [formId]),
    query("select * from program_form_fields where form_id = $1 and is_active = true order by sort_order", [formId])
  ]);

  return {
    formRow,
    levels: levels.rows,
    classes: classes.rows,
    packages: packages.rows,
    pricings: pricings.rows,
    addons: addons.rows,
    batches: batches.rows,
    sessions: sessions.rows,
    steps: steps.rows,
    fields: fields.rows
  };
}

function buildConfig(rows: ConfigRows, accessGranted: boolean, accessContext?: FormConfig["accessContext"]): FormConfig {
  const form = mapForm(rows.formRow);
  const locked = form.accessType !== "public" && !accessGranted;
  const reviewNotes = [
    rows.formRow.program_admin_notes,
    ...rows.steps.map((step) => step.admin_review_notes)
  ].filter((note): note is string => typeof note === "string" && note.trim().length > 0);

  return {
    locked,
    accessContext: locked ? undefined : accessContext,
    program: mapProgram(rows.formRow),
    form,
    steps: rows.steps.map(mapStep),
    fields: rows.fields.map(mapField),
    levels: rows.levels.map(mapLevel),
    classes: rows.classes.map(mapClass),
    packages: rows.packages.map(mapPackage),
    pricings: locked ? undefined : rows.pricings.map(mapPricing).filter((pricing) => pricing.priceType === form.priceType),
    addons: rows.addons.map(mapAddon),
    batches: rows.batches.map(mapBatch),
    sessions: rows.sessions.map(mapSession),
    reviewNotes
  };
}

export async function getDbFormConfig(slug: string, accessToken?: string) {
  const rows = await loadConfigRowsBySlug(slug);
  if (!rows) return null;
  const form = mapForm(rows.formRow);
  const parsedAccessToken = parseAccessToken(form.id, accessToken);
  const accessContext = parsedAccessToken.ok ? await getPartnerSchoolAccessContext(form.programId, parsedAccessToken.partnerSchoolId) : undefined;
  const accessGranted = form.accessType === "public" || (parsedAccessToken.ok && (!parsedAccessToken.partnerSchoolId || Boolean(accessContext?.partnerSchool)));
  const config = buildConfig(rows, Boolean(accessGranted), accessContext);
  if (isOutsideFormWindow(rows.formRow) || (await isFormAtSubmissionLimit(config.form.id, config.form.maxSubmissions))) {
    config.form.status = "closed";
  }
  return config;
}

export async function getDbAvailabilityForProgram(programId: string, levelId?: string) {
  const rows = await loadConfigRowsByProgramId(programId);
  if (!rows) return [];
  const config = buildConfig(rows, true);
  return buildAvailability(config, levelId);
}

async function getPartnerSchoolAccessContext(programId: string, partnerSchoolId?: string): Promise<FormConfig["accessContext"] | undefined> {
  if (!partnerSchoolId) return undefined;
  const result = await query(
    `
      select id, program_id, slug, name, status, price_type, admin_notes
      from partner_schools
      where id = $1
        and program_id = $2
        and status = 'active'
        and is_active = true
      limit 1
    `,
    [partnerSchoolId, programId]
  );
  const partnerSchool = result.rows[0] ? mapPartnerSchool(result.rows[0]) : null;
  return partnerSchool
    ? {
        partnerSchool: {
          id: partnerSchool.id,
          slug: partnerSchool.slug,
          name: partnerSchool.name
        }
      }
    : undefined;
}

export async function validateDbFormAccess(slug: string, code: string, ipAddress?: string | null, userAgent?: string | null) {
  const rows = await loadConfigRowsBySlug(slug);
  if (!rows) {
    return { ok: false as const, code: "FORM_CLOSED" as FormErrorCode, message: "Form tidak ditemukan." };
  }

  const form = mapForm(rows.formRow);
  if (form.accessType === "public") {
    return { ok: true as const, accessToken: null };
  }

  const failedAttempts = await query<{ count: string }>(
    `
      select count(*)::text as count
      from form_submission_events
      where form_id = $1
        and event_type = 'access_failed'
        and ip_address = nullif($2, '')::inet
        and occurred_at >= now() - ($3::text || ' minutes')::interval
    `,
    [form.id, ipAddress ?? "", ACCESS_RATE_WINDOW_MINUTES]
  );
  if (Number(failedAttempts.rows[0]?.count ?? 0) >= ACCESS_RATE_LIMIT) {
    await insertFormEvent(form.id, "access_rate_limited", undefined, ipAddress, userAgent, {});
    return { ok: false as const, code: "RATE_LIMITED" as FormErrorCode, message: "Terlalu banyak percobaan kode. Coba lagi beberapa menit lagi." };
  }

  const codeHash = sha256(code);
  const token = await query(
    `
      select
        fat.id,
        ps.id as partner_school_id,
        ps.slug as partner_school_slug,
        ps.name as partner_school_name
      from form_access_tokens fat
      left join partner_schools ps on ps.id = fat.partner_school_id
      where fat.form_id = $1
        and fat.is_active = true
        and (fat.starts_at is null or fat.starts_at <= now())
        and (fat.expires_at is null or fat.expires_at >= now())
        and (fat.max_uses is null or fat.used_count < fat.max_uses)
        and fat.code_hash = $2
        and (
          fat.partner_school_id is null
          or (
            ps.status = 'active'
            and ps.is_active = true
          )
        )
      limit 1
    `,
    [form.id, codeHash]
  );
  const valid = rows.formRow.access_code_hash === codeHash || Boolean(token.rows[0]);

  if (!valid) {
    await insertFormEvent(form.id, "access_failed", undefined, ipAddress, userAgent, { codeHash: codeHash.slice(0, 12) });
    return { ok: false as const, code: "INVALID_ACCESS" as FormErrorCode, message: "Kode akses tidak valid." };
  }

  if (token.rows[0]) {
    await query("update form_access_tokens set used_count = used_count + 1 where id = $1", [token.rows[0].id]);
  }
  await insertFormEvent(form.id, "access_granted", undefined, ipAddress, userAgent, {
    partnerSchoolId: token.rows[0]?.partner_school_id ?? null,
    partnerSchoolName: token.rows[0]?.partner_school_name ?? null
  });
  return {
    ok: true as const,
    accessToken: signAccessToken(form.id, token.rows[0]?.partner_school_id ? { partnerSchoolId: token.rows[0].partner_school_id } : {}),
    partnerSchool: token.rows[0]?.partner_school_id
      ? {
          id: token.rows[0].partner_school_id,
          slug: token.rows[0].partner_school_slug,
          name: token.rows[0].partner_school_name
        }
      : undefined
  };
}

export async function reserveDbRegistration(input: SubmitRequest, quote: QuoteResult, config: FormConfig) {
  return withTransaction(async (client) => {
    await client.query("select pg_advisory_xact_lock(hashtext($1))", [`event-registration:${config.program.id}`]);

    if (config.form.maxSubmissions && config.form.maxSubmissions > 0) {
      const submissionCount = await client.query<{ count: string }>(
        `
          select count(*)::text as count
          from registrations
          where form_id = $1
            and status not in ('invoice_failed', 'expired', 'cancelled')
        `,
        [config.form.id]
      );
      if (Number(submissionCount.rows[0]?.count ?? 0) >= config.form.maxSubmissions) {
        throw new ReservationError("FORM_CLOSED", "Kuota submission form sudah penuh.");
      }
    }

    const selectedBatchIds = quote.selectedBatches.map((batch) => batch.id);
    const lockedBatches = await client.query(
      "select id, quota, status from program_batches where id = any($1::uuid[]) for update",
      [selectedBatchIds]
    );
    if (lockedBatches.rowCount !== selectedBatchIds.length) {
      throw new ReservationError("INVALID_SCHEDULE", "Ada jadwal yang tidak ditemukan.");
    }

    const counts = await getBatchCounts(client, selectedBatchIds);
    for (const batch of lockedBatches.rows) {
      const count = counts.get(batch.id) ?? { reserved: 0, confirmed: 0 };
      const available = Number(batch.quota) - count.confirmed;
      if (batch.status !== "open" || available <= 0) {
        throw new ReservationError("SCHEDULE_FULL", "Jadwal baru saja penuh. Silakan pilih jadwal lain.");
      }
    }

    const grade = normalizeGrade(input.student.studentGradeRaw);
    const nextNumber = await client.query<{ seq: string }>(
      "select (count(*) + 1)::text as seq from registrations where program_id = $1",
      [config.program.id]
    );
    const externalReference = buildExternalReference(config.program.slug, Number(nextNumber.rows[0]?.seq ?? 1));
    const reservationExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const registrationResult = await client.query<{ id: string }>(
      `
        insert into registrations (
          program_id,
          form_id,
          external_reference,
          parent_name,
          parent_whatsapp,
          parent_email,
          student_name,
          student_grade_raw,
          student_grade_normalized,
          student_school,
          partner_school_id,
          partner_school_name,
          partner_school_slug,
          level_id,
          package_id,
          livestream_permission,
          policy_agreed_at,
          status,
          payment_status,
          reservation_expires_at,
          subtotal,
          addon_total,
          total,
          currency
        )
        values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11::uuid, $12, $13, $14, $15, $16, now(), 'pending_invoice', 'pending_invoice', $17, $18, $19, $20, $21)
        returning id
      `,
      [
        config.program.id,
        config.form.id,
        externalReference,
        input.parent.parentName,
        input.parent.parentWhatsapp,
        input.parent.parentEmail ?? null,
        input.student.studentName,
        input.student.studentGradeRaw,
        grade?.normalized ?? input.student.studentGradeRaw,
        input.student.studentSchool ?? null,
        config.accessContext?.partnerSchool?.id ?? null,
        config.accessContext?.partnerSchool?.name ?? null,
        config.accessContext?.partnerSchool?.slug ?? null,
        quote.level.id,
        quote.package.id,
        input.livestreamPermission ?? null,
        reservationExpiresAt,
        quote.subtotal,
        quote.addonTotal,
        quote.total,
        quote.currency
      ]
    );

    const registrationId = registrationResult.rows[0].id;
    for (const batch of quote.selectedBatches) {
      const klass = quote.selectedClasses.find((item) => item.id === batch.classId);
      await client.query(
        `
          insert into registration_items (
            registration_id,
            program_class_id,
            program_batch_id,
            week_no,
            item_name,
            qty,
            unit_price,
            line_total,
            slot_status,
            reserved_at
          )
          values ($1, $2, $3, $4, $5, 1, 0, 0, 'reserved', now())
        `,
        [registrationId, batch.classId, batch.id, batch.weekNo, `${klass?.name ?? "Kelas"} - Minggu ${batch.weekNo}`]
      );
      await client.query("update program_batches set reserved_count = reserved_count + 1 where id = $1", [batch.id]);
    }

    for (const selection of input.addons ?? []) {
      const addon = config.addons.find((item) => item.code === selection.addonCode);
      if (!addon) continue;
      const isBuy = selection.choice === "buy";
      await client.query(
        `
          insert into registration_addons (
            registration_id,
            program_addon_id,
            program_class_id,
            choice,
            qty,
            unit_price,
            line_total
          )
          values ($1, $2, $3, $4, 1, $5, $6)
        `,
        [registrationId, addon.id, addon.appliesToClassId, selection.choice, addon.price, isBuy ? addon.price : 0]
      );
    }

    await insertAuditLog(client, {
      action: "registration_create",
      entityType: "registration",
      entityId: registrationId,
      newValue: { externalReference, status: "pending_invoice", total: quote.total }
    });

    return {
      id: registrationId,
      externalReference,
      status: "pending_invoice" as RegistrationStatus
    };
  });
}

export async function attachDbInvoice(registrationId: string, invoice: InvoiceReference) {
  await withTransaction(async (client) => {
    const registration = await client.query("select external_reference, total from registrations where id = $1 for update", [registrationId]);
    const row = registration.rows[0];
    if (!row) return;

    await client.query(
      `
        insert into invoice_references (
          registration_id,
          external_reference,
          lms_invoice_id,
          invoice_number,
          payment_link,
          short_payment_link,
          status,
          amount,
          expired_at,
          last_synced_at,
          raw_response_json
        )
        values ($1, $2, $3, $4, $5, $6, $7, $8, $9, now(), $10::jsonb)
        on conflict (external_reference) do update set
          lms_invoice_id = excluded.lms_invoice_id,
          invoice_number = excluded.invoice_number,
          payment_link = excluded.payment_link,
          short_payment_link = excluded.short_payment_link,
          status = excluded.status,
          amount = excluded.amount,
          expired_at = excluded.expired_at,
          last_synced_at = now(),
          raw_response_json = excluded.raw_response_json
      `,
      [
        registrationId,
        row.external_reference,
        invoice.invoiceId,
        invoice.invoiceNumber,
        invoice.paymentLink,
        invoice.shortPaymentLink ?? null,
        invoice.status,
        row.total,
        invoice.expiredAt,
        JSON.stringify(invoice)
      ]
    );

    await client.query("update registrations set status = 'waiting_payment', payment_status = $2 where id = $1", [registrationId, invoice.status]);
  });
}

export async function markDbInvoiceFailed(registrationId: string, message: string) {
  await withTransaction(async (client) => {
    const registration = await client.query("select id from registrations where id = $1 for update", [registrationId]);
    if (!registration.rows[0]) return;
    await client.query(
      `
        update registrations
        set status = 'invoice_failed',
            payment_status = 'invoice_failed',
            invoice_error_message = $2,
            invoice_retryable = true
        where id = $1
      `,
      [registrationId, message]
    );
    await releaseReservedItems(client, registrationId, "released");
    await insertIntegrationLog(client, {
      integration: "LMS Core",
      action: "create_invoice",
      status: "failed",
      message
    });
  });
}

export async function prepareDbInvoiceRetry(registrationId: string, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const registration = await client.query<QueryResultRow>(
      `
        select
          r.*,
          p.name as program_name,
          pp.name as package_name,
          pl.name as level_name,
          f.max_submissions
        from registrations r
        join programs p on p.id = r.program_id
        join program_packages pp on pp.id = r.package_id
        join program_levels pl on pl.id = r.level_id
        join program_forms f on f.id = r.form_id
        where r.id = $1
        for update
      `,
      [registrationId]
    );
    const row = registration.rows[0];
    if (!row) {
      throw new ReservationError("SERVER_ERROR", "Registrasi tidak ditemukan.");
    }
    if (row.status !== "invoice_failed" || row.invoice_retryable !== true) {
      throw new ReservationError("SERVER_ERROR", "Registrasi ini tidak dalam status retry invoice.");
    }

    if (row.max_submissions && Number(row.max_submissions) > 0) {
      const submissionCount = await client.query<{ count: string }>(
        `
          select count(*)::text as count
          from registrations
          where form_id = $1
            and id <> $2
            and status not in ('invoice_failed', 'expired', 'cancelled')
        `,
        [row.form_id, registrationId]
      );
      if (Number(submissionCount.rows[0]?.count ?? 0) >= Number(row.max_submissions)) {
        throw new ReservationError("FORM_CLOSED", "Kuota submission form sudah penuh.");
      }
    }

    const items = await client.query<QueryResultRow>(
      `
        select
          ri.id,
          ri.program_batch_id,
          ri.program_class_id,
          ri.week_no,
          ri.slot_status,
          pc.name as class_name,
          b.starts_at
        from registration_items ri
        join program_classes pc on pc.id = ri.program_class_id
        join program_batches b on b.id = ri.program_batch_id
        where ri.registration_id = $1
        order by ri.week_no, ri.id
        for update
      `,
      [registrationId]
    );
    if (items.rowCount === 0) {
      throw new ReservationError("INVALID_SCHEDULE", "Tidak ada jadwal yang bisa diretry.");
    }

    const selectedBatchIds = [...new Set(items.rows.map((item) => item.program_batch_id as string))];
    const lockedBatches = await client.query(
      "select id, quota, status from program_batches where id = any($1::uuid[]) for update",
      [selectedBatchIds]
    );
    if (lockedBatches.rowCount !== selectedBatchIds.length) {
      throw new ReservationError("INVALID_SCHEDULE", "Ada jadwal yang tidak ditemukan.");
    }

    const counts = await getBatchCounts(client, selectedBatchIds);
    for (const batch of lockedBatches.rows) {
      const count = counts.get(batch.id) ?? { reserved: 0, confirmed: 0 };
      const available = Number(batch.quota) - count.confirmed;
      if (batch.status !== "open" || available <= 0) {
        throw new ReservationError("SCHEDULE_FULL", "Jadwal retry sudah penuh. Minta peserta pilih jadwal baru.");
      }
    }

    const reservationExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
    const reservedItems = await client.query<{ program_batch_id: string }>(
      `
        update registration_items
        set slot_status = 'reserved',
            reserved_at = now(),
            confirmed_at = null,
            released_at = null
        where registration_id = $1
          and slot_status in ('released', 'expired', 'cancelled')
        returning program_batch_id
      `,
      [registrationId]
    );

    if (reservedItems.rowCount !== items.rowCount) {
      throw new ReservationError("SERVER_ERROR", "Slot registrasi tidak bisa diretry dari status saat ini.");
    }

    for (const item of reservedItems.rows) {
      await client.query("update program_batches set reserved_count = reserved_count + 1 where id = $1", [item.program_batch_id]);
    }

    await client.query(
      `
        update registrations
        set status = 'pending_invoice',
            payment_status = 'pending_invoice',
            reservation_expires_at = $2,
            invoice_error_message = null,
            invoice_retryable = false
        where id = $1
      `,
      [registrationId, reservationExpiresAt]
    );

    await insertAuditLog(client, {
      action: "invoice_retry",
      entityType: "registration",
      entityId: registrationId,
      oldValue: { status: "invoice_failed", paymentStatus: "invoice_failed" },
      newValue: { status: "pending_invoice", paymentStatus: "pending_invoice" },
      reason: "Retry LMS invoice creation",
      adminId: actor?.adminId,
      ipAddress: actor?.ipAddress,
      userAgent: actor?.userAgent
    });

    const addonRows = await client.query<QueryResultRow>(
      `
        select pa.name, ra.choice, ra.qty, ra.line_total
        from registration_addons ra
        join program_addons pa on pa.id = ra.program_addon_id
        where ra.registration_id = $1
        order by pa.name
      `,
      [registrationId]
    );

    const callbackBase = process.env.EVENT_MANAGER_PUBLIC_URL || "https://lms.clev.io/event-manager";
    const invoicePayload: LmsInvoicePayload = {
      external_reference: row.external_reference,
      customer: {
        name: row.parent_name,
        whatsapp: row.parent_whatsapp,
        email: row.parent_email ?? ""
      },
      student: {
        name: row.student_name
      },
      items: [
        {
          name: `${row.package_name} - ${row.level_name} - ${row.program_name}`,
          qty: 1,
          price: Number(row.subtotal)
        },
        ...addonRows.rows
          .filter((addon) => Number(addon.line_total) > 0)
          .map((addon) => ({
            name: String(addon.name),
            qty: Number(addon.qty),
            price: Math.round(Number(addon.line_total) / Math.max(1, Number(addon.qty)))
          }))
      ],
      total: Number(row.total),
      expired_at: reservationExpiresAt.toISOString(),
      callback_url: `${callbackBase}/webhooks/lms/invoice`
    };

    return {
      id: registrationId,
      externalReference: row.external_reference as string,
      parentName: row.parent_name as string,
      parentWhatsapp: row.parent_whatsapp as string,
      studentName: row.student_name as string,
      programName: row.program_name as string,
      packageName: row.package_name as string,
      levelName: row.level_name as string,
      total: Number(row.total),
      scheduleLines: items.rows.map((item) => {
        return [`Minggu ${item.week_no ?? "-"}`, item.class_name ? String(item.class_name) : "Class", item.starts_at ? formatScheduleDate(item.starts_at as string | Date) : ""]
          .filter(Boolean)
          .join(" - ");
      }),
      addonLines: addonRows.rows
        .map((addon) => addon.name ? `${String(addon.name)}: ${formatAddonChoiceLabel(addon.choice as string | null | undefined)}` : null)
        .filter((line): line is string => Boolean(line)),
      invoicePayload
    };
  });
}

export async function applyDbInvoiceWebhook(payload: WebhookPayload) {
  return applyDbInvoiceStatus(payload, { source: "lms_webhook", rawResponse: payload });
}

export async function refreshDbInvoiceStatusFromLms(invoiceId: string, lmsResponse: unknown, actor?: AdminActor) {
  const invoice = await query(
    `
      select
        id,
        external_reference,
        lms_invoice_id,
        status,
        amount
      from invoice_references
      where lms_invoice_id = $1 or id::text = $1
      limit 1
    `,
    [invoiceId]
  );
  const invoiceRow = invoice.rows[0];
  if (!invoiceRow) return { updated: false, reason: "invoice_not_found" };

  const normalized = normalizeLmsInvoiceResponse(lmsResponse, {
    invoiceId: invoiceRow.lms_invoice_id,
    externalReference: invoiceRow.external_reference,
    amount: Number(invoiceRow.amount ?? 0)
  });

  return applyDbInvoiceStatus(
    normalized,
    {
      source: "lms_admin_refresh",
      actor,
      rawResponse: lmsResponse,
      invoiceNumber: normalized.invoice_number,
      paymentLink: normalized.payment_link,
      shortPaymentLink: normalized.short_payment_link,
      expiredAt: normalized.expired_at
    }
  );
}

function normalizeLmsInvoiceResponse(
  response: unknown,
  fallback: { invoiceId: string; externalReference: string; amount: number }
): NormalizedLmsInvoicePayload {
  const value = isRecord(response) ? response : {};
  const status = readString(value, ["status", "payment_status", "invoice_status"]);
  if (!status) {
    throw new Error("Response LMS tidak berisi status invoice.");
  }

  return {
    invoice_id: readString(value, ["invoice_id", "id", "lms_invoice_id"]) ?? fallback.invoiceId,
    external_reference: readString(value, ["external_reference", "reference", "registration_reference"]) ?? fallback.externalReference,
    status,
    paid_at: readString(value, ["paid_at", "paidAt", "payment_paid_at"]) ?? undefined,
    amount: readNumber(value, ["amount", "total", "paid_amount"]) ?? fallback.amount,
    invoice_number: readString(value, ["invoice_number", "number"]) ?? null,
    payment_link: readString(value, ["payment_link", "paymentLink", "payment_url"]) ?? null,
    short_payment_link: readString(value, ["short_payment_link", "shortPaymentLink", "short_url", "shortUrl"]) ?? null,
    expired_at: readString(value, ["expired_at", "expiredAt"]) ?? null
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function readString(value: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const candidate = value[key];
    if (typeof candidate === "string" && candidate.trim()) return candidate.trim();
  }
  return undefined;
}

function readNumber(value: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const candidate = value[key];
    if (typeof candidate === "number" && Number.isFinite(candidate)) return candidate;
    if (typeof candidate === "string" && candidate.trim() && Number.isFinite(Number(candidate))) return Number(candidate);
  }
  return undefined;
}

async function applyDbInvoiceStatus(
  payload: WebhookPayload,
  options: {
    source: string;
    actor?: AdminActor;
    rawResponse?: unknown;
    invoiceNumber?: string | null;
    paymentLink?: string | null;
    shortPaymentLink?: string | null;
    expiredAt?: string | null;
  }
) {
  return withTransaction(async (client) => {
    const registration = await client.query(
      "select id, status, payment_status from registrations where external_reference = $1 for update",
      [payload.external_reference]
    );
    const registrationRow = registration.rows[0];
    if (!registrationRow) return { updated: false, reason: "registration_not_found" };

    const invoiceReference = await client.query(
      "select id, status from invoice_references where external_reference = $1 for update",
      [payload.external_reference]
    );
    const invoiceReferenceRow = invoiceReference.rows[0];

    await client.query(
      `
        update invoice_references
        set status = $2,
            invoice_number = coalesce($5, invoice_number),
            payment_link = coalesce($6, payment_link),
            short_payment_link = coalesce($7, short_payment_link),
            expired_at = coalesce($8::timestamptz, expired_at),
            paid_at = case when $2 = 'paid' then coalesce($3::timestamptz, now()) else paid_at end,
            amount = coalesce($4, amount),
            last_synced_at = now(),
            updated_at = now(),
            raw_response_json = $9::jsonb
        where external_reference = $1
      `,
      [
        payload.external_reference,
        payload.status,
        payload.paid_at ?? null,
        payload.amount ?? null,
        options.invoiceNumber ?? null,
        options.paymentLink ?? null,
        options.shortPaymentLink ?? null,
        options.expiredAt ?? null,
        JSON.stringify(options.rawResponse ?? payload)
      ]
    );

    await client.query(
      `
        insert into payment_status_events (
          registration_id,
          invoice_reference_id,
          external_reference,
          old_status,
          new_status,
          source,
          amount,
          raw_payload_json
        )
        select
          $1,
          ir.id,
          $2,
          $3,
          $4,
          $5,
          $6,
          $7::jsonb
        from invoice_references ir
        where ir.external_reference = $2
      `,
      [
        registrationRow.id,
        payload.external_reference,
        registrationRow.payment_status ?? registrationRow.status,
        payload.status,
        options.source,
        payload.amount ?? null,
        JSON.stringify(options.rawResponse ?? payload)
      ]
    );

    if (payload.status === "paid") {
      await client.query(
        `
          update registrations
          set status = 'confirmed',
              payment_status = 'paid',
              invoice_retryable = false,
              confirmed_at = coalesce($2::timestamptz, now())
          where id = $1
        `,
        [registrationRow.id, payload.paid_at ?? null]
      );
      await confirmReservedItems(client, registrationRow.id);
      await activateDeviceOrders(client, registrationRow.id);
    } else if (payload.status === "expired" || payload.status === "cancelled") {
      await client.query(
        `
          update registrations
          set status = $2::registration_status,
              payment_status = $2,
              expired_at = case when $2 = 'expired' then now() else expired_at end,
              cancelled_at = case when $2 = 'cancelled' then now() else cancelled_at end
          where id = $1
        `,
        [registrationRow.id, payload.status]
      );
      await releaseReservedItems(client, registrationRow.id, payload.status);
    } else if (payload.status === "waiting_payment" || payload.status === "pending" || payload.status === "pending_invoice") {
      await client.query(
        `
          update registrations
          set status = 'waiting_payment',
              payment_status = $2
          where id = $1
            and status not in ('paid', 'confirmed', 'completed')
        `,
        [registrationRow.id, payload.status]
      );
    } else {
      await client.query("update registrations set payment_status = $2 where id = $1", [registrationRow.id, payload.status]);
    }

    if (options.actor || options.source === "lms_admin_refresh") {
      await insertAuditLog(client, {
        action: "invoice_status_refresh",
        entityType: "invoice_reference",
        entityId: invoiceReferenceRow?.id,
        oldValue: {
          invoiceStatus: invoiceReferenceRow?.status,
          registrationStatus: registrationRow.status,
          paymentStatus: registrationRow.payment_status
        },
        newValue: {
          invoiceStatus: payload.status,
          amount: payload.amount ?? null,
          paidAt: payload.paid_at ?? null
        },
        reason: "Update status invoice dari LMS",
        ...options.actor
      });
    }

    await reconcileBatchCountersForRegistration(client, registrationRow.id);
    return { updated: true, status: payload.status, source: options.source };
  });
}

export async function getDbPaymentConfirmationWhatsappContext(externalReference: string): Promise<PaymentConfirmationWhatsappContext | null> {
  const result = await query(
    `
      select
        r.id as registration_id,
        r.parent_name,
        r.parent_whatsapp,
        r.student_name,
        r.partner_school_name,
        p.name as program_name,
        pp.name as package_name,
        pl.name as level_name,
        r.total,
        ir.id as invoice_reference_id,
        ir.lms_invoice_id,
        ir.invoice_number,
        ir.payment_link,
        ir.short_payment_link,
        ir.paid_at,
        coalesce(
          jsonb_agg(
            jsonb_build_object(
              'weekNo', ri.week_no,
              'className', pc.name,
              'startsAt', b.starts_at
            )
            order by ri.week_no, pc.name
          ) filter (where ri.id is not null),
          '[]'::jsonb
        ) as schedules_json,
        coalesce(
          (
            select jsonb_agg(
              jsonb_build_object(
                'name', pa.name,
                'choice', ra.choice
              )
              order by pa.name
            )
            from registration_addons ra
            join program_addons pa on pa.id = ra.program_addon_id
            where ra.registration_id = r.id
          ),
          '[]'::jsonb
        ) as addons_json
      from registrations r
      join programs p on p.id = r.program_id
      join program_packages pp on pp.id = r.package_id
      join program_levels pl on pl.id = r.level_id
      left join invoice_references ir on ir.registration_id = r.id
      left join registration_items ri on ri.registration_id = r.id
      left join program_classes pc on pc.id = ri.program_class_id
      left join program_batches b on b.id = ri.program_batch_id
      where r.external_reference = $1
      group by r.id, p.name, pp.name, pl.name, ir.id, ir.lms_invoice_id, ir.invoice_number, ir.payment_link, ir.short_payment_link, ir.paid_at
      limit 1
    `,
    [externalReference]
  );
  const row = result.rows[0];
  if (!row) return null;
  const schedules = Array.isArray(row.schedules_json) ? row.schedules_json : JSON.parse(String(row.schedules_json ?? "[]"));
  const addons = Array.isArray(row.addons_json) ? row.addons_json : JSON.parse(String(row.addons_json ?? "[]"));

  return {
    registrationId: row.registration_id,
    invoiceReferenceId: row.invoice_reference_id ?? null,
    invoiceId: row.lms_invoice_id ?? null,
    invoiceNumber: row.invoice_number ?? null,
    paymentLink: row.payment_link ?? null,
    shortPaymentLink: row.short_payment_link ?? null,
    parentName: row.parent_name,
    parentWhatsapp: row.parent_whatsapp,
    studentName: row.student_name,
    programName: row.program_name,
    packageName: row.package_name,
    levelName: row.level_name,
    partnerSchoolName: row.partner_school_name ?? null,
    total: Number(row.total ?? 0),
    paidAt: row.paid_at ? toIsoString(row.paid_at) : null,
    scheduleLines: schedules.map((item: { weekNo?: number; className?: string; startsAt?: string | Date | null }) => {
      const startsAt = item.startsAt ? formatScheduleDate(item.startsAt) : "";
      return [`Minggu ${item.weekNo ?? "-"}`, item.className ?? "Kelas", startsAt].filter(Boolean).join(" - ");
    }),
    addonLines: addons
      .map((item: { name?: string; choice?: string }) => item.name ? `${item.name}: ${formatAddonChoiceLabel(item.choice)}` : null)
      .filter((line: string | null): line is string => Boolean(line))
  };
}

export async function hasDbSuccessfulWhatsappLog(registrationId: string, messageType: string) {
  const result = await query(
    `
      select exists (
        select 1
        from whatsapp_logs
        where registration_id = $1
          and message_type = $2
          and status = 'success'
      ) as exists
    `,
    [registrationId, messageType]
  );
  return result.rows[0]?.exists === true;
}

export async function getDbRegistrationPaymentContext(registrationId: string): Promise<RegistrationPaymentContext | null> {
  const result = await query(
    `
      select
        r.id,
        r.external_reference,
        r.status,
        r.payment_status,
        ir.lms_invoice_id,
        ir.invoice_number,
        ir.payment_link,
        ir.short_payment_link,
        ir.status as invoice_status
      from registrations r
      left join invoice_references ir on ir.registration_id = r.id
      where r.id = $1
      limit 1
    `,
    [registrationId]
  );
  const row = result.rows[0];
  if (!row) return null;
  return {
    id: row.id,
    externalReference: row.external_reference,
    status: row.status,
    paymentStatus: row.payment_status,
    invoiceId: row.lms_invoice_id ?? null,
    invoiceNumber: row.invoice_number ?? null,
    paymentLink: row.payment_link ?? null,
    shortPaymentLink: row.short_payment_link ?? null,
    invoiceStatus: row.invoice_status ?? null
  };
}

export async function recordDbWebhookLog(input: {
  source: string;
  eventType: string;
  eventId?: string | null;
  externalReference?: string | null;
  payload: unknown;
  signatureValid: boolean;
  processingStatus: string;
  errorMessage?: string | null;
}) {
  await query(
    `
      insert into webhook_logs (
        source,
        event_type,
        event_id,
        external_reference,
        payload_json,
        signature_valid,
        processing_status,
        error_message,
        processed_at
      )
      values ($1, $2, $3, $4, $5::jsonb, $6, $7, $8, now())
    `,
    [
      input.source,
      input.eventType,
      input.eventId ?? null,
      input.externalReference ?? null,
      JSON.stringify(input.payload),
      input.signatureValid,
      input.processingStatus,
      input.errorMessage ?? null
    ]
  );
}

export async function recordDbFormEvent(event: {
  formId?: string;
  eventType: string;
  stepKey?: string;
  ipAddress?: string | null;
  userAgent?: string | null;
}) {
  await insertFormEvent(event.formId, event.eventType, event.stepKey, event.ipAddress, event.userAgent, {});
}

export async function recordDbIntegrationLog(log: IntegrationLogInput) {
  await query(
    "insert into integration_logs (integration, action, status, error_message) values ($1, $2, $3, $4)",
    [log.integration, log.action, log.status, log.message]
  );
}

export async function recordDbWhatsappLog(log: WhatsAppLogInput) {
  await query(
    `
      insert into whatsapp_logs (
        registration_id,
        invoice_reference_id,
        message_type,
        recipient,
        message_preview,
        lms_response_json,
        status,
        error_message
      )
      values ($1, $2, $3, $4, $5, $6::jsonb, $7, $8)
    `,
    [
      log.registrationId ?? null,
      log.invoiceReferenceId ?? null,
      log.messageType,
      log.recipient,
      log.messagePreview ?? null,
      JSON.stringify(log.response ?? null),
      log.status,
      log.errorMessage ?? null
    ]
  );
}

export async function getDbAdminSnapshot(): Promise<AdminSnapshot> {
  const programResult = await query(
    `
      select
        p.id as program_id,
        p.slug as program_slug,
        p.name as program_name,
        p.description as program_description,
        p.period_start,
        p.period_end,
        p.mode,
        p.platform,
        p.registration_open_at,
        p.registration_close_at,
        p.registration_cutoff_rule,
        p.registration_deadline_rule,
        p.default_session_duration_minutes,
        p.default_quota_per_batch,
        p.no_minimum_participant,
        p.has_levels,
        p.has_packages,
        p.has_bundling,
        p.has_addons,
        p.has_schedule_selection,
        p.has_attendance,
        p.has_pitching_day,
        p.has_certificates,
        p.has_livestream_permission,
        p.has_whatsapp_automation,
        p.admin_notes as program_admin_notes
      from programs p
      where p.status = 'active'
      order by p.period_start desc
      limit 1
    `
  );
  const programRow = programResult.rows[0];
  if (!programRow) {
    throw new Error("No active Event Manager program configured");
  }

  const rows = await loadConfigRowsByProgramId(programRow.program_id);
  if (!rows) {
    throw new Error("No active Event Manager form configured");
  }
  const config = buildConfig(rows, true);

  const [
    programsCount,
    activeFormsCount,
    registrationCounts,
    registrations,
    batchRosterRows,
    deviceOrders,
    pitchingDayEntries,
    certificates,
    certificateTemplates,
    analytics,
    integrationLogs,
    programsList,
    invoices,
    webhookLogs,
    whatsappLogs,
    auditLogs,
    reconciliationLogs,
    attendanceSummary
  ] = await Promise.all([
    query<{ count: string }>("select count(*)::text as count from programs"),
    query<{ count: string }>("select count(*)::text as count from program_forms where status = 'active' and is_active = true"),
    query(
      `
        select
          count(*)::int as total,
          count(*) filter (where status = 'waiting_payment')::int as waiting_payment,
          count(*) filter (where status in ('paid', 'confirmed'))::int as paid,
          count(*) filter (where status = 'expired')::int as expired,
          count(*) filter (where status = 'cancelled')::int as cancelled,
          count(*) filter (where status = 'invoice_failed')::int as invoice_failed,
          coalesce(sum(total) filter (where status in ('paid', 'confirmed', 'completed')), 0)::int as revenue_paid,
          coalesce(sum(total) filter (where status = 'waiting_payment'), 0)::int as revenue_waiting,
          count(*) filter (where status in ('paid', 'confirmed', 'completed'))::int as certificate_eligible,
          (select count(*)::int from invoice_references ir join registrations rr on rr.id = ir.registration_id where rr.program_id = $1)::int as invoice_created
        from registrations
        where program_id = $1
      `,
      [config.program.id]
    ),
    query(
      `
        select
          r.id,
          r.external_reference,
          r.parent_name,
          r.parent_whatsapp,
          r.parent_email,
          r.student_name,
          r.student_grade_raw,
          r.student_grade_normalized,
          r.student_school,
          r.partner_school_name,
          r.partner_school_slug,
          l.name as level_name,
          p.name as package_name,
          f.name as source_form,
          f.price_type,
          r.status,
          r.payment_status,
          r.total,
          r.livestream_permission,
          r.submitted_at,
          (select c.status from certificates c where c.registration_id = r.id order by c.generated_at desc nulls last, c.id desc limit 1) as certificate_status,
          coalesce((select array_agg(distinct pc.name) from registration_items ri join program_classes pc on pc.id = ri.program_class_id where ri.registration_id = r.id), '{}'::text[]) as selected_classes,
          coalesce((select array_agg(distinct concat('Minggu ', ri.week_no, ' - ', ri.item_name)) from registration_items ri where ri.registration_id = r.id), '{}'::text[]) as selected_schedules,
          coalesce((select array_agg(distinct concat(pa.name, ': ', ra.choice)) from registration_addons ra join program_addons pa on pa.id = ra.program_addon_id where ra.registration_id = r.id), '{}'::text[]) as addon_choices,
          r.invoice_retryable,
          r.invoice_error_message,
          ir.lms_invoice_id,
          ir.invoice_number,
          ir.status as invoice_status,
          ir.payment_link,
          ir.short_payment_link,
          r.admin_notes
        from registrations r
        join program_packages p on p.id = r.package_id
        join program_levels l on l.id = r.level_id
        join program_forms f on f.id = r.form_id
        left join invoice_references ir on ir.registration_id = r.id
        where r.program_id = $1
        order by r.submitted_at desc
        limit 80
      `,
      [config.program.id]
    ),
    query(
      `
        select
          ri.program_batch_id as batch_id,
          r.id as registration_id,
          r.external_reference,
          r.student_name,
          r.parent_name,
          r.parent_whatsapp,
          l.name as level_name,
          p.name as package_name,
          p.code as package_code,
          r.status as registration_status,
          r.payment_status,
          r.total,
          ri.slot_status,
          r.submitted_at
        from registration_items ri
        join registrations r on r.id = ri.registration_id
        join program_batches b on b.id = ri.program_batch_id
        join program_packages p on p.id = r.package_id
        join program_levels l on l.id = r.level_id
        where b.program_id = $1
        order by b.week_no, b.starts_at, p.code, r.student_name
      `,
      [config.program.id]
    ),
    query(
      `
        select
          d.id,
          d.device_type,
          r.student_name,
          r.parent_name,
          p.name as program_name,
          pc.name as class_name,
          r.payment_status,
          d.status,
          d.delivered_at,
          d.admin_notes
        from device_orders d
        join registrations r on r.id = d.registration_id
        join programs p on p.id = r.program_id
        left join registration_addons ra on ra.id = d.registration_addon_id
        left join program_classes pc on pc.id = ra.program_class_id
        where r.program_id = $1
        order by d.id desc
        limit 80
      `,
      [config.program.id]
    ),
    query(
      `
        select id, student_name, project_title, entry_status, schedule_at
        from pitching_day_entries
        where program_id = $1
        order by schedule_at nulls last, student_name
        limit 60
      `,
      [config.program.id]
    ),
    query(
      `
        select
          c.id,
          c.registration_id,
          r.external_reference,
          r.student_name,
          r.parent_name,
          r.parent_whatsapp,
          pp.name as package_name,
          pl.name as level_name,
          coalesce((select array_agg(distinct pc.name order by pc.name) from registration_items ri join program_classes pc on pc.id = ri.program_class_id where ri.registration_id = r.id), '{}'::text[]) as class_names,
          c.template_key,
          ct.name as template_name,
          c.template_version,
          c.certificate_number,
          c.status,
          c.generated_at,
          c.sent_at,
          c.issued_at,
          c.download_url,
          c.error_message
        from certificates c
        join registrations r on r.id = c.registration_id
        join program_packages pp on pp.id = r.package_id
        join program_levels pl on pl.id = r.level_id
        left join certificate_templates ct on ct.id = c.template_id
        where c.program_id = $1
        order by
          case c.status when 'failed' then 0 when 'ready' then 1 when 'generated' then 2 when 'sent' then 3 else 4 end,
          r.student_name
        limit 200
      `,
      [config.program.id]
    ),
    query(
      `
        select id, template_key, name, template_version, background_url, preview_image_url, layout_json, is_active, notes
        from certificate_templates
        where program_id = $1
        order by is_active desc, updated_at desc, created_at desc
        limit 10
      `,
      [config.program.id]
    ),
    query(
      `
        select event_type, count(*)::int as count
        from form_submission_events
        where program_id = $1 or form_id in (select id from program_forms where program_id = $1)
        group by event_type
      `,
      [config.program.id]
    ),
    query(
      `
        select id, integration, action, status, coalesce(error_message, '') as message
        from integration_logs
        order by created_at desc
        limit 12
      `
    ),
    query(
      `
        select
          id as program_id,
          slug as program_slug,
          name as program_name,
          description as program_description,
          period_start,
          period_end,
          mode,
          platform,
          registration_open_at,
          registration_close_at,
          registration_cutoff_rule,
          registration_deadline_rule,
          default_session_duration_minutes,
          default_quota_per_batch,
          no_minimum_participant,
          has_levels,
          has_packages,
          has_bundling,
          has_addons,
          has_schedule_selection,
          has_attendance,
          has_pitching_day,
          has_certificates,
          has_livestream_permission,
          has_whatsapp_automation,
          admin_notes as program_admin_notes
        from programs
        order by period_start desc
      `
    ),
    query(
      `
        select
          ir.id,
          ir.registration_id,
          ir.lms_invoice_id,
          ir.invoice_number,
          ir.external_reference,
          r.student_name,
          r.parent_name,
          ir.amount,
          ir.status,
          ir.payment_link,
          ir.short_payment_link,
          ir.created_at,
          ir.expired_at,
          ir.paid_at
        from invoice_references ir
        join registrations r on r.id = ir.registration_id
        where r.program_id = $1
        order by ir.created_at desc
        limit 100
      `,
      [config.program.id]
    ),
    query(
      `
        select id, source, event_type, external_reference, signature_valid, processing_status, error_message, received_at
        from webhook_logs
        order by received_at desc
        limit 80
      `
    ),
    query(
      `
        select id, message_type, recipient, status, error_message, created_at
        from whatsapp_logs
        order by created_at desc
        limit 80
      `
    ),
    query(
      `
        select id, admin_id, action, entity_type, entity_id, reason, created_at
        from audit_logs
        order by created_at desc
        limit 80
      `
    ),
    query(
      `
        select id, job_name, status, started_at, finished_at, error_message
        from reconciliation_logs
        order by started_at desc
        limit 60
      `
    ),
    query(
      `
        select
          count(distinct s.id)::int as sessions,
          count(r.id)::int as records,
          count(r.id) filter (where r.status = 'present')::int as present,
          count(r.id) filter (where r.status in ('absent', 'late', 'excused'))::int as absent
        from attendance_sessions s
        left join attendance_records r on r.attendance_session_id = s.id
        where s.program_id = $1
      `,
      [config.program.id]
    )
  ]);

  const counts = registrationCounts.rows[0] ?? {};
  const eventCounts = new Map(analytics.rows.map((row) => [row.event_type, Number(row.count)]));
  const availability = buildAvailability(config);
  const rosterStudentsByBatch = new Map<string, AdminSnapshot["batchRosters"][number]["students"]>();
  for (const item of batchRosterRows.rows) {
    const students = rosterStudentsByBatch.get(item.batch_id) ?? [];
    students.push({
      registrationId: item.registration_id,
      externalReference: item.external_reference,
      studentName: item.student_name,
      parentName: item.parent_name,
      parentWhatsapp: item.parent_whatsapp ?? undefined,
      levelName: item.level_name ?? undefined,
      packageName: item.package_name,
      packageCode: item.package_code ?? undefined,
      isBundling: item.package_code === "bundling" || String(item.package_name ?? "").toLowerCase().includes("bundling"),
      registrationStatus: item.registration_status,
      paymentStatus: item.payment_status,
      total: Number(item.total),
      slotStatus: item.slot_status,
      submittedAt: item.submitted_at ? toIsoString(item.submitted_at) : undefined
    });
    rosterStudentsByBatch.set(item.batch_id, students);
  }
  const batchRosters: AdminSnapshot["batchRosters"] = availability.map((batch) => ({
    batchId: batch.id,
    batchCode: batch.batchCode,
    batchName: batch.batchName,
    className: batch.className,
    weekNo: batch.weekNo,
    startsAt: batch.startsAt,
    endsAt: batch.endsAt,
    timezone: batch.timezone,
    scheduleLabel: `${formatScheduleDate(batch.startsAt)} - ${formatScheduleDate(batch.endsAt)}`,
    quota: batch.quota,
    reservedCount: batch.reservedCount,
    confirmedCount: batch.confirmedCount,
    availableSlots: batch.availableSlots,
    students: rosterStudentsByBatch.get(batch.id) ?? []
  }));

  return {
    program: config.program,
    metrics: {
      programs: Number(programsCount.rows[0]?.count ?? 0),
      activeForms: Number(activeFormsCount.rows[0]?.count ?? 0),
      availableBatches: availability.filter((item) => item.isSelectable).length,
      registrations: Number(counts.total ?? 0),
      waitingPayment: Number(counts.waiting_payment ?? 0),
      paid: Number(counts.paid ?? 0),
      expired: Number(counts.expired ?? 0),
      cancelled: Number(counts.cancelled ?? 0),
      invoiceFailed: Number(counts.invoice_failed ?? 0),
      deviceOrders: deviceOrders.rows.length,
      invoiceCreated: Number(counts.invoice_created ?? 0),
      revenuePaid: Number(counts.revenue_paid ?? 0),
      revenueWaiting: Number(counts.revenue_waiting ?? 0),
      urgentWarnings: Number(counts.invoice_failed ?? 0) + webhookLogs.rows.filter((item) => item.processing_status === "failed").length
    },
    programs: programsList.rows.map(mapProgram),
    levels: config.levels,
    classes: config.classes,
    packages: config.packages,
    pricings: rows.pricings.map(mapPricing),
    addons: config.addons,
    forms: await listDbProgramForms(config.program.id),
    batches: availability,
    sessions: config.sessions,
    batchRosters,
    registrations: registrations.rows.map((item) => ({
      id: item.id,
      externalReference: item.external_reference,
      parentName: item.parent_name,
      parentWhatsapp: item.parent_whatsapp ?? undefined,
      parentEmail: item.parent_email ?? undefined,
      studentName: item.student_name,
      studentGradeRaw: item.student_grade_raw ?? undefined,
      studentGradeNormalized: item.student_grade_normalized ?? undefined,
      studentSchool: item.student_school ?? undefined,
      partnerSchoolName: item.partner_school_name ?? undefined,
      partnerSchoolSlug: item.partner_school_slug ?? undefined,
      levelName: item.level_name ?? undefined,
      packageName: item.package_name,
      selectedClasses: Array.isArray(item.selected_classes) ? item.selected_classes : [],
      selectedSchedules: Array.isArray(item.selected_schedules) ? item.selected_schedules : [],
      addonChoices: Array.isArray(item.addon_choices) ? item.addon_choices : [],
      sourceForm: item.source_form ?? undefined,
      priceType: item.price_type ?? undefined,
      status: item.status,
      paymentStatus: item.payment_status,
      total: Number(item.total),
      livestreamPermission: item.livestream_permission,
      certificateStatus: item.certificate_status ?? undefined,
      createdAt: item.submitted_at ? toIsoString(item.submitted_at) : undefined,
      invoiceRetryable: Boolean(item.invoice_retryable),
      invoiceErrorMessage: item.invoice_error_message ?? undefined,
      invoiceId: item.lms_invoice_id ?? undefined,
      invoiceNumber: item.invoice_number ?? undefined,
      invoiceStatus: item.invoice_status ?? undefined,
      paymentLink: item.payment_link ?? undefined,
      shortPaymentLink: item.short_payment_link ?? undefined,
      adminNotes: item.admin_notes ?? undefined
    })),
    invoices: invoices.rows.map((item) => ({
      id: item.id,
      registrationId: item.registration_id,
      invoiceId: item.lms_invoice_id,
      invoiceNumber: item.invoice_number ?? undefined,
      externalReference: item.external_reference,
      studentName: item.student_name ?? undefined,
      parentName: item.parent_name ?? undefined,
      total: Number(item.amount ?? 0),
      status: item.status,
      paymentLink: item.payment_link ?? undefined,
      shortPaymentLink: item.short_payment_link ?? undefined,
      createdAt: item.created_at ? toIsoString(item.created_at) : undefined,
      expiredAt: item.expired_at ? toIsoString(item.expired_at) : undefined,
      paidAt: item.paid_at ? toIsoString(item.paid_at) : undefined
    })),
    deviceOrders: deviceOrders.rows.map((item) => ({
      id: item.id,
      deviceType: item.device_type,
      studentName: item.student_name,
      parentName: item.parent_name ?? undefined,
      programName: item.program_name ?? undefined,
      className: item.class_name ?? undefined,
      paymentStatus: item.payment_status ?? undefined,
      status: item.status,
      deliveredAt: item.delivered_at ? toIsoString(item.delivered_at) : undefined,
      adminNotes: item.admin_notes ?? undefined
    })),
    pitchingDayEntries: pitchingDayEntries.rows.map((item) => ({
      id: item.id,
      studentName: item.student_name,
      projectTitle: item.project_title ?? undefined,
      status: item.entry_status,
      scheduleAt: item.schedule_at ? toIsoString(item.schedule_at) : undefined
    })),
    certificateSummary: {
      eligible: Number(counts.certificate_eligible ?? 0),
      ready: certificates.rows.filter((item) => item.status === "ready").length,
      generated: certificates.rows.filter((item) => item.status === "generated").length,
      sent: certificates.rows.filter((item) => item.status === "sent").length,
      failed: certificates.rows.filter((item) => item.status === "failed").length
    },
    certificateTemplates: certificateTemplates.rows.map((item) => ({
      id: item.id,
      templateKey: item.template_key,
      name: item.name,
      templateVersion: Number(item.template_version ?? 1),
      backgroundUrl: item.background_url ?? null,
      previewImageUrl: item.preview_image_url ?? null,
      layout: item.layout_json && typeof item.layout_json === "object" ? item.layout_json : {},
      isActive: item.is_active === true,
      notes: item.notes ?? null
    })),
    certificates: certificates.rows.map((item) => ({
      id: item.id,
      registrationId: item.registration_id ?? null,
      externalReference: item.external_reference ?? null,
      studentName: item.student_name ?? null,
      parentName: item.parent_name ?? null,
      parentWhatsapp: item.parent_whatsapp ?? null,
      packageName: item.package_name ?? null,
      levelName: item.level_name ?? null,
      classNames: Array.isArray(item.class_names) ? item.class_names : [],
      templateKey: item.template_key ?? null,
      templateName: item.template_name ?? null,
      templateVersion: item.template_version ? Number(item.template_version) : null,
      certificateNumber: item.certificate_number ?? null,
      status: item.status,
      downloadUrl: item.download_url ?? null,
      generatedAt: item.generated_at ? toIsoString(item.generated_at) : null,
      sentAt: item.sent_at ? toIsoString(item.sent_at) : null,
      issuedAt: item.issued_at ? toDateString(item.issued_at) : null,
      errorMessage: item.error_message ?? null
    })),
    analytics: [
      { label: "Visits", value: eventCounts.get("visit") ?? 0 },
      { label: "Started", value: eventCounts.get("started") ?? 0 },
      { label: "Quote Requested", value: eventCounts.get("quote_requested") ?? 0 },
      { label: "Submitted", value: eventCounts.get("submitted") ?? 0 },
      { label: "Invoice Created", value: eventCounts.get("invoice_created") ?? 0 },
      { label: "Paid", value: Number(counts.paid ?? 0) },
      { label: "Abandoned", value: Math.max(0, (eventCounts.get("started") ?? 0) - (eventCounts.get("submitted") ?? 0)) },
      { label: "Errors", value: eventCounts.get("error") ?? 0 }
    ],
    integrationLogs: integrationLogs.rows.map((item) => ({
      id: item.id,
      integration: item.integration,
      action: item.action,
      status: item.status,
      message: item.message
    })),
    whatsappLogs: whatsappLogs.rows.map((item) => ({
      id: item.id,
      messageType: item.message_type,
      recipient: item.recipient,
      status: item.status,
      errorMessage: item.error_message ?? undefined,
      createdAt: item.created_at ? toIsoString(item.created_at) : undefined
    })),
    webhookLogs: webhookLogs.rows.map((item) => ({
      id: item.id,
      source: item.source,
      eventType: item.event_type,
      externalReference: item.external_reference ?? undefined,
      signatureValid: item.signature_valid === true,
      processingStatus: item.processing_status,
      errorMessage: item.error_message ?? undefined,
      receivedAt: toIsoString(item.received_at)
    })),
    auditLogs: auditLogs.rows.map((item) => ({
      id: item.id,
      adminId: item.admin_id ?? undefined,
      action: item.action,
      entityType: item.entity_type,
      entityId: item.entity_id ?? undefined,
      reason: item.reason ?? undefined,
      createdAt: toIsoString(item.created_at)
    })),
    reconciliationLogs: reconciliationLogs.rows.map((item) => ({
      id: item.id,
      jobName: item.job_name,
      status: item.status,
      startedAt: toIsoString(item.started_at),
      finishedAt: item.finished_at ? toIsoString(item.finished_at) : undefined,
      errorMessage: item.error_message ?? undefined
    })),
    attendanceSummary: {
      sessions: Number(attendanceSummary.rows[0]?.sessions ?? 0),
      records: Number(attendanceSummary.rows[0]?.records ?? 0),
      present: Number(attendanceSummary.rows[0]?.present ?? 0),
      absent: Number(attendanceSummary.rows[0]?.absent ?? 0)
    }
  };
}

export async function runDbMaintenanceJob(jobName: "release-expired-reservations" | "sync-invoices" | "reconcile-batch-counters") {
  const started = await query<{ id: string }>(
    "insert into reconciliation_logs (job_name, status) values ($1, 'running') returning id",
    [jobName]
  );
  const logId = started.rows[0].id;

  try {
    let summary: Record<string, unknown>;
    if (jobName === "release-expired-reservations") {
      summary = await releaseExpiredReservations();
    } else if (jobName === "reconcile-batch-counters") {
      summary = await reconcileAllBatchCounters();
    } else {
      summary = await syncWaitingInvoices();
    }
    await query(
      "update reconciliation_logs set status = 'success', finished_at = now(), summary_json = $2::jsonb where id = $1",
      [logId, JSON.stringify(summary)]
    );
    return { jobName, status: "success", summary };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown job error";
    await query(
      "update reconciliation_logs set status = 'failed', finished_at = now(), error_message = $2 where id = $1",
      [logId, message]
    );
    throw error;
  }
}

export async function listDbProgramForms(programId: string) {
  const result = await query(
    `
      select
        id as form_id,
        program_id,
        slug as form_slug,
        name as form_name,
        description as form_description,
        template_key,
        price_type,
        access_type,
        status as form_status,
        max_submissions,
        success_title,
        success_message
      from program_forms
      where program_id = $1
      order by created_at
    `,
    [programId]
  );
  return result.rows.map(mapForm);
}

export async function listDbPrograms() {
  const result = await query(
    `
      select
        id as program_id,
        slug as program_slug,
        name as program_name,
        period_start,
        period_end,
        mode,
        platform,
        default_session_duration_minutes,
        default_quota_per_batch,
        admin_notes as program_admin_notes
      from programs
      order by period_start desc, created_at desc
    `
  );
  return result.rows.map(mapProgram);
}

export async function createDbProgram(input: {
  slug: string;
  name: string;
  periodStart: string;
  periodEnd: string;
  mode: string;
  platform?: string;
  defaultSessionDurationMinutes?: number;
  defaultQuotaPerBatch?: number;
  adminNotes?: string;
  status?: string;
}, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const result = await client.query(
      `
        insert into programs (
          slug,
          name,
          period_start,
          period_end,
          mode,
          platform,
          default_session_duration_minutes,
          default_quota_per_batch,
          admin_notes,
          status
        )
        values ($1, $2, $3::date, $4::date, $5, $6, $7, $8, $9, coalesce($10::program_status, 'draft'))
        returning
          id as program_id,
          slug as program_slug,
          name as program_name,
          period_start,
          period_end,
          mode,
          platform,
          default_session_duration_minutes,
          default_quota_per_batch,
          admin_notes as program_admin_notes
      `,
      [
        input.slug,
        input.name,
        input.periodStart,
        input.periodEnd,
        input.mode,
        input.platform ?? null,
        input.defaultSessionDurationMinutes ?? 90,
        input.defaultQuotaPerBatch ?? 10,
        input.adminNotes ?? null,
        input.status ?? "draft"
      ]
    );
    const program = mapProgram(result.rows[0]);
    await insertAuditLog(client, {
      action: "program_create",
      entityType: "program",
      entityId: program.id,
      newValue: program,
      ...actor
    });
    return program;
  });
}

export async function updateDbProgram(id: string, input: Partial<{
  name: string;
  periodStart: string;
  periodEnd: string;
  mode: string;
  platform: string;
  defaultSessionDurationMinutes: number;
  defaultQuotaPerBatch: number;
  adminNotes: string;
  status: string;
}>, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query("select to_jsonb(p.*) as value from programs p where id = $1 for update", [id]);
    if (!oldValue.rows[0]) return null;
    const result = await client.query(
      `
        update programs
        set
          name = coalesce($2, name),
          period_start = coalesce($3::date, period_start),
          period_end = coalesce($4::date, period_end),
          mode = coalesce($5, mode),
          platform = coalesce($6, platform),
          default_session_duration_minutes = coalesce($7, default_session_duration_minutes),
          default_quota_per_batch = coalesce($8, default_quota_per_batch),
          admin_notes = coalesce($9, admin_notes),
          status = coalesce($10::program_status, status),
          updated_at = now()
        where id = $1
        returning
          id as program_id,
          slug as program_slug,
          name as program_name,
          period_start,
          period_end,
          mode,
          platform,
          default_session_duration_minutes,
          default_quota_per_batch,
          admin_notes as program_admin_notes
      `,
      [
        id,
        input.name ?? null,
        input.periodStart ?? null,
        input.periodEnd ?? null,
        input.mode ?? null,
        input.platform ?? null,
        input.defaultSessionDurationMinutes ?? null,
        input.defaultQuotaPerBatch ?? null,
        input.adminNotes ?? null,
        input.status ?? null
      ]
    );
    const program = mapProgram(result.rows[0]);
    await insertAuditLog(client, {
      action: "program_update",
      entityType: "program",
      entityId: id,
      oldValue: oldValue.rows[0].value,
      newValue: program,
      ...actor
    });
    return program;
  });
}

export async function updateDbProgramForm(id: string, input: Partial<{
  name: string;
  slug: string;
  description: string;
  status: string;
  accessType: string;
  accessCode: string;
  priceType: string;
  maxSubmissions: number | null;
  successTitle: string;
  successMessage: string;
  isActive: boolean;
}>, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query("select to_jsonb(f.*) as value from program_forms f where id = $1 for update", [id]);
    if (!oldValue.rows[0]) return null;
    const result = await client.query(
      `
        update program_forms
        set
          name = coalesce($2, name),
          slug = coalesce($3, slug),
          description = coalesce($4, description),
          status = coalesce($5::form_status, status),
          access_type = coalesce($6::form_access_type, access_type),
          access_code_hash = case when $7::text is null then access_code_hash else $7 end,
          price_type = coalesce($8, price_type),
          max_submissions = case when $9::boolean then $10::integer else max_submissions end,
          success_title = coalesce($11, success_title),
          success_message = coalesce($12, success_message),
          is_active = coalesce($13, is_active),
          updated_at = now()
        where id = $1
        returning
          id as form_id,
          program_id,
          slug as form_slug,
          name as form_name,
          description as form_description,
          template_key,
          price_type,
          access_type,
          status as form_status,
          max_submissions,
          success_title,
          success_message
      `,
      [
        id,
        input.name ?? null,
        input.slug ?? null,
        input.description ?? null,
        input.status ?? null,
        input.accessType ?? null,
        input.accessCode ? sha256(input.accessCode) : null,
        input.priceType ?? null,
        Object.prototype.hasOwnProperty.call(input, "maxSubmissions"),
        input.maxSubmissions ?? null,
        input.successTitle ?? null,
        input.successMessage ?? null,
        input.isActive ?? null
      ]
    );
    const form = mapForm(result.rows[0]);
    await insertAuditLog(client, {
      action: input.accessType || input.accessCode ? "form_access_update" : "form_update",
      entityType: "program_form",
      entityId: id,
      oldValue: oldValue.rows[0].value,
      newValue: form,
      ...actor
    });
    return form;
  });
}

export async function updateDbFormField(id: string, input: Partial<{
  label: string;
  helpText: string | null;
  placeholder: string | null;
  isRequired: boolean;
  isActive: boolean;
}>, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query("select to_jsonb(ff.*) as value from program_form_fields ff where id = $1 for update", [id]);
    if (!oldValue.rows[0]) return null;
    const result = await client.query(
      `
        update program_form_fields
        set
          label = coalesce($2, label),
          help_text = case when $3::boolean then $4 else help_text end,
          placeholder = case when $5::boolean then $6 else placeholder end,
          is_required = coalesce($7, is_required),
          is_active = coalesce($8, is_active)
        where id = $1
        returning *
      `,
      [
        id,
        input.label ?? null,
        Object.prototype.hasOwnProperty.call(input, "helpText"),
        input.helpText ?? null,
        Object.prototype.hasOwnProperty.call(input, "placeholder"),
        input.placeholder ?? null,
        input.isRequired ?? null,
        input.isActive ?? null
      ]
    );
    await insertAuditLog(client, {
      action: "form_field_update",
      entityType: "program_form_field",
      entityId: id,
      oldValue: oldValue.rows[0].value,
      newValue: result.rows[0],
      ...actor
    });
    return result.rows[0];
  });
}

export async function createDbProgramPackage(input: {
  programId: string;
  code: string;
  name: string;
  description?: string;
  minClasses: number;
  maxClasses: number;
  requiredWeekCount?: number | null;
  sameLevelOnly?: boolean;
  uniqueClassRequired?: boolean;
  uniqueSoftwareRequired?: boolean;
  oneClassPerWeek?: boolean;
  allowCustomSelection?: boolean;
  isActive?: boolean;
}, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const result = await client.query(
      `
        insert into program_packages (
          program_id,
          code,
          name,
          description,
          min_classes,
          max_classes,
          required_week_count,
          same_level_only,
          unique_class_required,
          unique_software_required,
          one_class_per_week,
          allow_custom_selection,
          is_active
        )
        values ($1, $2, $3, $4, $5, $6, $7, coalesce($8, true), coalesce($9, true), coalesce($10, true), coalesce($11, false), coalesce($12, true), coalesce($13, true))
        returning *
      `,
      [
        input.programId,
        input.code,
        input.name,
        input.description ?? "",
        input.minClasses,
        input.maxClasses,
        input.requiredWeekCount ?? null,
        input.sameLevelOnly ?? true,
        input.uniqueClassRequired ?? true,
        input.uniqueSoftwareRequired ?? true,
        input.oneClassPerWeek ?? false,
        input.allowCustomSelection ?? true,
        input.isActive ?? true
      ]
    );
    await insertAuditLog(client, {
      action: "package_create",
      entityType: "program_package",
      entityId: result.rows[0].id,
      newValue: result.rows[0],
      ...actor
    });
    return mapPackage(result.rows[0]);
  });
}

export async function updateDbProgramPackage(id: string, input: Partial<{
  code: string;
  name: string;
  description: string;
  minClasses: number;
  maxClasses: number;
  requiredWeekCount: number | null;
  sameLevelOnly: boolean;
  uniqueClassRequired: boolean;
  uniqueSoftwareRequired: boolean;
  oneClassPerWeek: boolean;
  allowCustomSelection: boolean;
  isActive: boolean;
}>, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query("select to_jsonb(p.*) as value from program_packages p where id = $1 for update", [id]);
    if (!oldValue.rows[0]) return null;
    const result = await client.query(
      `
        update program_packages
        set
          code = coalesce($2, code),
          name = coalesce($3, name),
          description = coalesce($4, description),
          min_classes = coalesce($5, min_classes),
          max_classes = coalesce($6, max_classes),
          required_week_count = case when $7::boolean then $8::integer else required_week_count end,
          same_level_only = coalesce($9, same_level_only),
          unique_class_required = coalesce($10, unique_class_required),
          unique_software_required = coalesce($11, unique_software_required),
          one_class_per_week = coalesce($12, one_class_per_week),
          allow_custom_selection = coalesce($13, allow_custom_selection),
          is_active = coalesce($14, is_active)
        where id = $1
        returning *
      `,
      [
        id,
        input.code ?? null,
        input.name ?? null,
        input.description ?? null,
        input.minClasses ?? null,
        input.maxClasses ?? null,
        Object.prototype.hasOwnProperty.call(input, "requiredWeekCount"),
        input.requiredWeekCount ?? null,
        input.sameLevelOnly ?? null,
        input.uniqueClassRequired ?? null,
        input.uniqueSoftwareRequired ?? null,
        input.oneClassPerWeek ?? null,
        input.allowCustomSelection ?? null,
        input.isActive ?? null
      ]
    );
    await insertAuditLog(client, {
      action: "package_update",
      entityType: "program_package",
      entityId: id,
      oldValue: oldValue.rows[0].value,
      newValue: result.rows[0],
      ...actor
    });
    return mapPackage(result.rows[0]);
  });
}

export async function upsertDbProgramPricing(input: {
  programId: string;
  priceType: string;
  levelId: string;
  packageId: string;
  price: number;
  currency?: string;
  adminId?: string;
}, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query(
      "select to_jsonb(p.*) as value from program_pricings p where program_id = $1 and price_type = $2 and level_id = $3 and package_id = $4 for update",
      [input.programId, input.priceType, input.levelId, input.packageId]
    );
    const result = await client.query(
      `
        insert into program_pricings (
          program_id,
          price_type,
          level_id,
          package_id,
          price,
          currency,
          is_active,
          last_edited_by_admin,
          updated_at
        )
        values ($1, $2, $3, $4, $5, coalesce($6, 'IDR'), true, $7, now())
        on conflict (program_id, price_type, level_id, package_id) do update set
          price = excluded.price,
          currency = excluded.currency,
          is_active = true,
          last_edited_by_admin = excluded.last_edited_by_admin,
          updated_at = now()
        returning *
      `,
      [input.programId, input.priceType, input.levelId, input.packageId, input.price, input.currency ?? "IDR", input.adminId ?? actor?.adminId ?? null]
    );
    await insertAuditLog(client, {
      action: oldValue.rows[0] ? "pricing_update" : "pricing_create",
      entityType: "program_pricing",
      entityId: result.rows[0].id,
      oldValue: oldValue.rows[0]?.value,
      newValue: result.rows[0],
      ...actor
    });
    return mapPricing(result.rows[0]);
  });
}

export async function updateDbProgramPricing(id: string, input: Partial<{
  price: number;
  currency: string;
  isActive: boolean;
  adminId: string;
}>, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query("select to_jsonb(p.*) as value from program_pricings p where id = $1 for update", [id]);
    if (!oldValue.rows[0]) return null;
    const result = await client.query(
      `
        update program_pricings
        set
          price = coalesce($2, price),
          currency = coalesce($3, currency),
          is_active = coalesce($4, is_active),
          last_edited_by_admin = coalesce($5, last_edited_by_admin),
          updated_at = now()
        where id = $1
        returning *
      `,
      [id, input.price ?? null, input.currency ?? null, input.isActive ?? null, input.adminId ?? actor?.adminId ?? null]
    );
    await insertAuditLog(client, {
      action: "pricing_update",
      entityType: "program_pricing",
      entityId: id,
      oldValue: oldValue.rows[0].value,
      newValue: result.rows[0],
      ...actor
    });
    return mapPricing(result.rows[0]);
  });
}

export async function createDbProgramBatch(input: {
  programId: string;
  classId: string;
  batchCode?: string;
  batchName?: string | null;
  weekNo: number;
  startsAt: string;
  endsAt: string;
  timezone?: string;
  quota: number;
  status?: string;
  sessionCount?: number;
  meetingPlatform?: string;
  meetingUrl?: string | null;
  notes?: string | null;
}, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const klass = await client.query<{ id: string; level_id: string; slug: string; name: string }>(
      "select id, level_id, slug, name from program_classes where id = $1 and program_id = $2 and is_active = true",
      [input.classId, input.programId]
    );
    if (!klass.rows[0]) throw new Error("Kelas tidak ditemukan.");

    const startsAt = new Date(input.startsAt);
    const endsAt = new Date(input.endsAt);
    if (!Number.isFinite(startsAt.getTime()) || !Number.isFinite(endsAt.getTime()) || endsAt <= startsAt) {
      throw new Error("Tanggal/jam jadwal tidak valid.");
    }

    const sessionCount = Math.max(1, Math.min(14, Math.round(input.sessionCount ?? 3)));
    const generatedCode = `${klass.rows[0].slug}-w${input.weekNo}-${Date.now().toString(36)}`;
    const batchCode = input.batchCode?.trim() || generatedCode;
    const result = await client.query(
      `
        insert into program_batches (
          program_id,
          class_id,
          level_id,
          batch_code,
          batch_name,
          week_no,
          starts_at,
          ends_at,
          timezone,
          quota,
          status,
          notes
        )
        values ($1, $2, $3, $4, $5, $6, $7::timestamptz, $8::timestamptz, coalesce($9, 'Asia/Jakarta'), $10, coalesce($11, 'open'), $12)
        returning *
      `,
      [
        input.programId,
        input.classId,
        klass.rows[0].level_id,
        batchCode,
        input.batchName?.trim() || batchCode,
        input.weekNo,
        input.startsAt,
        input.endsAt,
        input.timezone ?? "Asia/Jakarta",
        input.quota,
        input.status ?? "open",
        input.notes ?? null
      ]
    );

    const durationMs = endsAt.getTime() - startsAt.getTime();
    const sessionDurationMs = Math.max(1, Math.round(durationMs / (1000 * 60))) * 60 * 1000;
    for (let sessionNo = 1; sessionNo <= sessionCount; sessionNo += 1) {
      const sessionStart = new Date(startsAt.getTime() + (sessionNo - 1) * 24 * 60 * 60 * 1000);
      const sessionEnd = new Date(sessionStart.getTime() + sessionDurationMs);
      await client.query(
        `
          insert into program_sessions (
            batch_id,
            session_no,
            title,
            starts_at,
            ends_at,
            duration_minutes,
            meeting_platform,
            meeting_url,
            notes
          )
          values ($1, $2, $3, $4::timestamptz, $5::timestamptz, $6, $7, $8, $9)
        `,
        [
          result.rows[0].id,
          sessionNo,
          `Sesi ${sessionNo}`,
          sessionStart.toISOString(),
          sessionEnd.toISOString(),
          Math.round(sessionDurationMs / (1000 * 60)),
          input.meetingPlatform ?? "Zoom",
          input.meetingUrl ?? null,
          null
        ]
      );
    }

    await insertAuditLog(client, {
      action: "batch_create",
      entityType: "program_batch",
      entityId: result.rows[0].id,
      newValue: result.rows[0],
      ...actor
    });
    return result.rows[0];
  });
}

export async function updateDbProgramBatch(id: string, input: Partial<{
  batchName: string | null;
  weekNo: number;
  quota: number;
  status: string;
  startsAt: string;
  endsAt: string;
}>, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query("select to_jsonb(b.*) as value from program_batches b where id = $1 for update", [id]);
    if (!oldValue.rows[0]) return null;
    const oldBatch = oldValue.rows[0].value;
    const oldStartsAt = oldBatch.starts_at ? String(oldBatch.starts_at) : undefined;
    const oldEndsAt = oldBatch.ends_at ? String(oldBatch.ends_at) : undefined;
    const result = await client.query(
      `
        update program_batches
        set
          batch_name = case when $2::boolean then $3 else batch_name end,
          week_no = coalesce($4, week_no),
          quota = coalesce($5, quota),
          status = coalesce($6, status),
          starts_at = coalesce($7::timestamptz, starts_at),
          ends_at = coalesce($8::timestamptz, ends_at)
        where id = $1
        returning *
      `,
      [
        id,
        Object.prototype.hasOwnProperty.call(input, "batchName"),
        input.batchName ?? null,
        input.weekNo ?? null,
        input.quota ?? null,
        input.status ?? null,
        input.startsAt ?? null,
        input.endsAt ?? null
      ]
    );
    await updateSessionTimesForBatch(client, id, {
      oldStartsAt,
      oldEndsAt,
      startsAt: input.startsAt,
      endsAt: input.endsAt
    });
    await insertAuditLog(client, {
      action: "batch_quota_status_update",
      entityType: "program_batch",
      entityId: id,
      oldValue: oldValue.rows[0].value,
      newValue: result.rows[0],
      ...actor
    });
    return result.rows[0];
  });
}

export async function deleteDbRegistration(id: string, input: { reason?: string }, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query(
      `
        select
          to_jsonb(r.*) ||
          jsonb_build_object(
            'invoice_references',
            coalesce((select jsonb_agg(to_jsonb(ir.*)) from invoice_references ir where ir.registration_id = r.id), '[]'::jsonb),
            'registration_items',
            coalesce((select jsonb_agg(to_jsonb(ri.*)) from registration_items ri where ri.registration_id = r.id), '[]'::jsonb),
            'registration_addons',
            coalesce((select jsonb_agg(to_jsonb(ra.*)) from registration_addons ra where ra.registration_id = r.id), '[]'::jsonb)
          ) as value
        from registrations r
        where r.id = $1
        for update
      `,
      [id]
    );
    if (!oldValue.rows[0]) return null;

    const batchIds = await client.query<{ program_batch_id: string }>(
      "select distinct program_batch_id from registration_items where registration_id = $1",
      [id]
    );

    await client.query("delete from device_orders where registration_id = $1", [id]);
    await client.query("delete from registrations where id = $1", [id]);

    if (batchIds.rows.length > 0) {
      await reconcileBatchCounters(client, batchIds.rows.map((row) => row.program_batch_id));
    }

    await insertAuditLog(client, {
      action: "registration_delete",
      entityType: "registration",
      entityId: id,
      reason: input.reason ?? "Cleanup data testing",
      oldValue: oldValue.rows[0].value,
      ...actor
    });

    return {
      id,
      externalReference: oldValue.rows[0].value.external_reference,
      deleted: true
    };
  });
}

async function updateSessionTimesForBatch(client: PoolClient, batchId: string, input: {
  oldStartsAt?: string;
  oldEndsAt?: string;
  startsAt?: string;
  endsAt?: string;
}) {
  if (!input.startsAt && !input.endsAt) return;

  const oldStartMs = input.oldStartsAt ? Date.parse(input.oldStartsAt) : NaN;
  const nextStartMs = Date.parse(input.startsAt ?? input.oldStartsAt ?? "");
  if (!Number.isFinite(oldStartMs) || !Number.isFinite(nextStartMs)) return;

  const deltaMs = nextStartMs - oldStartMs;
  const shouldApplyDuration = Boolean(input.endsAt);
  const nextDurationMs = shouldApplyDuration
    ? getClockDurationMs(input.startsAt ?? input.oldStartsAt, input.endsAt)
    : null;

  const sessions = await client.query<{ id: string; starts_at: Date | string; ends_at: Date | string }>(
    "select id, starts_at, ends_at from program_sessions where batch_id = $1 order by session_no for update",
    [batchId]
  );

  for (const session of sessions.rows) {
    const currentStartMs = Date.parse(String(session.starts_at));
    const currentEndMs = Date.parse(String(session.ends_at));
    if (!Number.isFinite(currentStartMs) || !Number.isFinite(currentEndMs)) continue;

    const nextSessionStart = new Date(currentStartMs + deltaMs);
    const durationMs = nextDurationMs ?? Math.max(30 * 60 * 1000, currentEndMs - currentStartMs);
    const nextSessionEnd = new Date(nextSessionStart.getTime() + durationMs);

    await client.query(
      "update program_sessions set starts_at = $2, ends_at = $3, duration_minutes = greatest(1, round(extract(epoch from ($3::timestamptz - $2::timestamptz)) / 60)::int) where id = $1",
      [session.id, nextSessionStart.toISOString(), nextSessionEnd.toISOString()]
    );
  }
}

function getClockDurationMs(startsAt?: string, endsAt?: string) {
  const start = extractClockMinutes(startsAt);
  const end = extractClockMinutes(endsAt);
  if (start === null || end === null) return 90 * 60 * 1000;
  const minutes = end > start ? end - start : end + 24 * 60 - start;
  return Math.max(30, minutes) * 60 * 1000;
}

function extractClockMinutes(value?: string) {
  if (!value) return null;
  const match = value.match(/T(\d{2}):(\d{2})/);
  if (!match) return null;
  return Number(match[1]) * 60 + Number(match[2]);
}

export async function updateDbDeviceOrder(id: string, input: Partial<{
  status: string;
  adminNotes: string | null;
  fulfillmentNotes: string | null;
}>, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const oldValue = await client.query("select to_jsonb(d.*) as value from device_orders d where id = $1 for update", [id]);
    if (!oldValue.rows[0]) return null;
    const result = await client.query(
      `
        update device_orders
        set
          status = coalesce($2::device_order_status, status),
          admin_notes = case when $3::boolean then $4 else admin_notes end,
          fulfillment_notes = case when $5::boolean then $6 else fulfillment_notes end,
          delivered_at = case when $2 = 'delivered' then coalesce(delivered_at, now()) else delivered_at end
        where id = $1
        returning *
      `,
      [
        id,
        input.status ?? null,
        Object.prototype.hasOwnProperty.call(input, "adminNotes"),
        input.adminNotes ?? null,
        Object.prototype.hasOwnProperty.call(input, "fulfillmentNotes"),
        input.fulfillmentNotes ?? null
      ]
    );
    await insertAuditLog(client, {
      action: "device_status_update",
      entityType: "device_order",
      entityId: id,
      oldValue: oldValue.rows[0].value,
      newValue: result.rows[0],
      ...actor
    });
    return result.rows[0];
  });
}

export async function manualDbPaymentOverride(registrationId: string, input: {
  newStatus: RegistrationStatus;
  reason: string;
}, actor?: AdminActor) {
  return withTransaction(async (client) => {
    const targetRegistrationStatus: RegistrationStatus = input.newStatus === "paid" ? "confirmed" : input.newStatus;
    const targetPaymentStatus = ["paid", "confirmed", "completed"].includes(input.newStatus) ? "paid" : input.newStatus;
    const isPaidLike = targetPaymentStatus === "paid" || targetRegistrationStatus === "completed";
    const isExpiredOrCancelled = targetRegistrationStatus === "expired" || targetRegistrationStatus === "cancelled";
    const oldValue = await client.query(
      "select id, status, payment_status, external_reference from registrations where id = $1 for update",
      [registrationId]
    );
    const oldRow = oldValue.rows[0];
    if (!oldRow) return null;
    await client.query(
      `
        update registrations
        set
          status = $2::registration_status,
          payment_status = $3,
          confirmed_at = case when $4::boolean then coalesce(confirmed_at, now()) else confirmed_at end,
          expired_at = case when $5 = 'expired' then coalesce(expired_at, now()) else expired_at end,
          cancelled_at = case when $5 = 'cancelled' then coalesce(cancelled_at, now()) else cancelled_at end,
          invoice_retryable = case when $4::boolean or $5 = 'waiting_payment' then false else invoice_retryable end
        where id = $1
      `,
      [registrationId, targetRegistrationStatus, targetPaymentStatus, isPaidLike, targetRegistrationStatus]
    );

    if (isPaidLike) {
      await client.query(
        `
          update invoice_references
          set status = 'paid',
              paid_at = coalesce(paid_at, now()),
              last_synced_at = now(),
              updated_at = now()
          where registration_id = $1
        `,
        [registrationId]
      );
      await client.query(
        `
          insert into payment_status_events (
            registration_id,
            invoice_reference_id,
            external_reference,
            old_status,
            new_status,
            source,
            amount,
            raw_payload_json
          )
          select
            $1,
            ir.id,
            $2,
            $3,
            'paid',
            'admin_manual_override',
            ir.amount,
            $4::jsonb
          from invoice_references ir
          where ir.registration_id = $1
        `,
        [
          registrationId,
          oldRow.external_reference,
          oldRow.payment_status ?? oldRow.status,
          JSON.stringify({ newStatus: input.newStatus, reason: input.reason })
        ]
      );
      await confirmReservedItems(client, registrationId);
      await activateDeviceOrders(client, registrationId);
    } else if (isExpiredOrCancelled) {
      await releaseReservedItems(client, registrationId, targetRegistrationStatus);
    }

    await reconcileBatchCountersForRegistration(client, registrationId);
    await insertAuditLog(client, {
      action: "payment_manual_override",
      entityType: "registration",
      entityId: registrationId,
      oldValue: { status: oldRow.status, paymentStatus: oldRow.payment_status },
      newValue: { status: targetRegistrationStatus, paymentStatus: targetPaymentStatus },
      reason: input.reason,
      ...actor
    });
    return {
      id: registrationId,
      externalReference: oldRow.external_reference,
      oldStatus: oldRow.status,
      newStatus: targetRegistrationStatus,
      paymentStatus: targetPaymentStatus,
      reason: input.reason
    };
  });
}

export async function listDbAuditLogs(limit = 80) {
  const result = await query(
    `
      select id, admin_id, action, entity_type, entity_id, reason, old_value_json, new_value_json, ip_address::text, user_agent, created_at
      from audit_logs
      order by created_at desc
      limit $1
    `,
    [limit]
  );
  return result.rows;
}

export async function listDbReconciliationLogs(limit = 60) {
  const result = await query(
    `
      select id, job_name, status, started_at, finished_at, summary_json, error_message
      from reconciliation_logs
      order by started_at desc
      limit $1
    `,
    [limit]
  );
  return result.rows;
}

export async function listDbPitchingDayEntries(programId?: string) {
  const result = await query(
    `
      select id, program_id, registration_id, student_name, project_title, entry_status, schedule_at, notes
      from pitching_day_entries
      where ($1::uuid is null or program_id = $1::uuid)
      order by schedule_at nulls last, student_name
    `,
    [programId ?? null]
  );
  return result.rows;
}

export async function saveDbCertificateTemplate(input: CertificateTemplateInput, actor?: AdminActor) {
  const programId = await resolveCertificateProgramId(input.programId);
  return withTransaction(async (client) => {
    const existing = await getActiveCertificateTemplate(client, programId);
    const layout = buildCertificateLayout(input, existing?.layout_json);
    const name = input.name?.trim() || existing?.name || "Template Sertifikat Clevio";
    const result = existing
      ? await client.query(
          `
            update certificate_templates
            set name = $2,
                template_version = template_version + 1,
                background_url = $3,
                preview_image_url = $4,
                layout_json = $5::jsonb,
                notes = $6,
                updated_at = now()
            where id = $1
            returning id, template_key, name, template_version, background_url, preview_image_url, layout_json, is_active, notes
          `,
          [
            existing.id,
            name,
            input.backgroundUrl?.trim() || null,
            input.previewImageUrl?.trim() || null,
            JSON.stringify(layout),
            input.notes?.trim() || null
          ]
        )
      : await client.query(
          `
            insert into certificate_templates (
              program_id,
              template_key,
              name,
              template_version,
              background_url,
              preview_image_url,
              layout_json,
              variables_json,
              notes
            )
            values ($1, 'default', $2, 1, $3, $4, $5::jsonb, $6::jsonb, $7)
            returning id, template_key, name, template_version, background_url, preview_image_url, layout_json, is_active, notes
          `,
          [
            programId,
            name,
            input.backgroundUrl?.trim() || null,
            input.previewImageUrl?.trim() || null,
            JSON.stringify(layout),
            JSON.stringify(defaultCertificateVariables()),
            input.notes?.trim() || null
          ]
        );

    await insertAuditLog(client, {
      action: "certificate_template_update",
      entityType: "certificate_template",
      entityId: result.rows[0]?.id,
      newValue: result.rows[0] ?? null,
      reason: "Update template sertifikat",
      ...actor
    });

    return result.rows[0];
  });
}

export async function prepareDbCertificates(programId?: string | null, actor?: AdminActor) {
  const resolvedProgramId = await resolveCertificateProgramId(programId);
  return withTransaction(async (client) => {
    const template = await ensureCertificateTemplate(client, resolvedProgramId);
    const result = await client.query<{ id: string }>(
      `
        insert into certificates (
          program_id,
          registration_id,
          template_id,
          template_key,
          template_version,
          status,
          issued_at,
          raw_response_json
        )
        select
          r.program_id,
          r.id,
          $2,
          $3,
          $4,
          'ready',
          current_date,
          jsonb_build_object('prepared_at', now(), 'source', 'event_manager')
        from registrations r
        where r.program_id = $1
          and r.status in ('paid', 'confirmed', 'completed')
          and not exists (
            select 1
            from certificates c
            where c.registration_id = r.id
          )
        returning id
      `,
      [resolvedProgramId, template.id, template.template_key, template.template_version]
    );

    const updated = await client.query(
      `
        update certificates
        set status = 'ready',
            template_id = $2,
            template_key = $3,
            template_version = $4,
            error_message = null,
            updated_at = now()
        where program_id = $1
          and status in ('pending', 'failed')
          and download_url is null
      `,
      [resolvedProgramId, template.id, template.template_key, template.template_version]
    );

    await insertAuditLog(client, {
      action: "certificate_prepare",
      entityType: "program",
      entityId: resolvedProgramId,
      newValue: { inserted: result.rowCount ?? 0, resetReady: updated.rowCount ?? 0 },
      reason: "Prepare peserta siap sertifikat",
      ...actor
    });

    return {
      inserted: result.rowCount ?? 0,
      resetReady: updated.rowCount ?? 0,
      templateName: template.name
    };
  });
}

export async function generateDbCertificates(programId?: string | null, actor?: AdminActor) {
  const resolvedProgramId = await resolveCertificateProgramId(programId);
  const program = await getCertificateProgram(resolvedProgramId);
  const template = await ensureCertificateTemplateForProgram(resolvedProgramId);
  const rows = await query(
    `
      select
        c.id,
        c.certificate_number,
        r.external_reference,
        r.student_name,
        r.parent_name,
        pl.name as level_name,
        coalesce((select array_agg(distinct pc.name order by pc.name) from registration_items ri join program_classes pc on pc.id = ri.program_class_id where ri.registration_id = r.id), '{}'::text[]) as class_names
      from certificates c
      join registrations r on r.id = c.registration_id
      join program_levels pl on pl.id = r.level_id
      where c.program_id = $1
        and c.status in ('ready', 'failed')
        and c.download_url is null
      order by r.student_name
      limit 250
    `,
    [resolvedProgramId]
  );

  const lms = new LmsClient();
  let generated = 0;
  let failed = 0;
  for (const row of rows.rows) {
    const certificateNumber = row.certificate_number || buildCertificateNumber(program.slug, row.external_reference, row.id);
    try {
      const response = await lms.generateCertificate({
        external_reference: row.external_reference,
        student: { name: row.student_name },
        program: {
          name: program.name,
          date_range: formatProgramDateRange(program.period_start, program.period_end)
        },
        class_names: Array.isArray(row.class_names) ? row.class_names : [],
        level_name: row.level_name ?? null,
        issued_date: program.period_end ? toDateString(program.period_end) : new Date().toISOString().slice(0, 10),
        certificate_number: certificateNumber,
        template: {
          key: template.template_key,
          name: template.name,
          version: Number(template.template_version ?? 1),
          layout: template.layout_json && typeof template.layout_json === "object" ? template.layout_json : {}
        }
      });

      await query(
        `
          update certificates
          set status = 'generated',
              certificate_number = $2,
              lms_certificate_id = $3,
              download_url = $4,
              generated_at = now(),
              issued_at = coalesce(issued_at, current_date),
              template_id = $5,
              template_key = $6,
              template_version = $7,
              error_message = null,
              raw_response_json = $8::jsonb,
              updated_at = now()
          where id = $1
        `,
        [
          row.id,
          response.certificateNumber,
          response.certificateId,
          response.certificateUrl,
          template.id,
          template.template_key,
          Number(response.templateVersion ?? template.template_version ?? 1),
          JSON.stringify(response)
        ]
      );
      await recordDbIntegrationLog({
        integration: "LMS Core",
        action: "generate_certificate",
        status: "success",
        message: `Certificate generated for ${row.external_reference}`
      });
      generated += 1;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Generate certificate failed";
      await query(
        `
          update certificates
          set status = 'failed',
              certificate_number = $2,
              error_message = $3,
              updated_at = now()
          where id = $1
        `,
        [row.id, certificateNumber, message]
      );
      await recordDbIntegrationLog({
        integration: "LMS Core",
        action: "generate_certificate",
        status: "failed",
        message
      });
      failed += 1;
    }
  }

  await withTransaction((client) => insertAuditLog(client, {
    action: "certificate_generate_bulk",
    entityType: "program",
    entityId: resolvedProgramId,
    newValue: { generated, failed },
    reason: "Generate sertifikat serempak",
    ...actor
  }));

  return { queued: rows.rowCount ?? rows.rows.length, generated, failed };
}

export async function sendDbCertificates(programId?: string | null, actor?: AdminActor) {
  const resolvedProgramId = await resolveCertificateProgramId(programId);
  const rows = await query(
    `
      select
        c.id,
        c.download_url,
        r.id as registration_id,
        r.parent_name,
        r.parent_whatsapp,
        r.student_name,
        p.name as program_name,
        coalesce((select array_agg(distinct pc.name order by pc.name) from registration_items ri join program_classes pc on pc.id = ri.program_class_id where ri.registration_id = r.id), '{}'::text[]) as class_names
      from certificates c
      join registrations r on r.id = c.registration_id
      join programs p on p.id = r.program_id
      where c.program_id = $1
        and c.download_url is not null
        and c.status in ('generated', 'failed')
      order by r.student_name
      limit 250
    `,
    [resolvedProgramId]
  );

  const lms = new LmsClient();
  let sent = 0;
  let failed = 0;
  for (const row of rows.rows) {
    try {
      const message = buildEventCertificateWhatsAppMessage({
        parentName: row.parent_name,
        studentName: row.student_name,
        programName: row.program_name,
        certificateUrl: row.download_url,
        classNames: Array.isArray(row.class_names) ? row.class_names : []
      });
      const response = await lms.sendWhatsAppMessage({
        to: row.parent_whatsapp,
        message
      });
      await recordDbWhatsappLog({
        registrationId: row.registration_id,
        messageType: "certificate_sent",
        recipient: row.parent_whatsapp,
        messagePreview: message.slice(0, 500),
        response,
        status: "success"
      });
      await query(
        `
          update certificates
          set status = 'sent',
              sent_at = now(),
              error_message = null,
              updated_at = now()
          where id = $1
        `,
        [row.id]
      );
      sent += 1;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Send certificate WhatsApp failed";
      await recordDbWhatsappLog({
        registrationId: row.registration_id,
        messageType: "certificate_sent",
        recipient: row.parent_whatsapp,
        messagePreview: null,
        response: null,
        status: "failed",
        errorMessage: message
      });
      await query(
        `
          update certificates
          set status = 'failed',
              error_message = $2,
              updated_at = now()
          where id = $1
        `,
        [row.id, message]
      );
      failed += 1;
    }
  }

  await withTransaction((client) => insertAuditLog(client, {
    action: "certificate_send_bulk",
    entityType: "program",
    entityId: resolvedProgramId,
    newValue: { sent, failed },
    reason: "Kirim sertifikat serempak via WhatsApp",
    ...actor
  }));

  return { queued: rows.rowCount ?? rows.rows.length, sent, failed };
}

export async function listDbCertificates(programId?: string) {
  const result = await query(
    `
      select
        c.id,
        c.program_id,
        c.registration_id,
        c.template_key,
        c.template_version,
        c.certificate_number,
        c.lms_certificate_id,
        c.status,
        c.generated_at,
        c.sent_at,
        c.issued_at,
        c.download_url,
        c.error_message,
        r.student_name,
        r.parent_name,
        r.parent_whatsapp
      from certificates c
      left join registrations r on r.id = c.registration_id
      where ($1::uuid is null or c.program_id = $1::uuid)
      order by c.generated_at desc nulls last, c.id desc
    `,
    [programId ?? null]
  );
  return result.rows;
}

async function resolveCertificateProgramId(programId?: string | null) {
  if (programId) return programId;
  const result = await query<{ id: string }>(
    "select id from programs where status = 'active' order by period_start desc limit 1"
  );
  const id = result.rows[0]?.id;
  if (!id) throw new Error("Program aktif tidak ditemukan.");
  return id;
}

async function getCertificateProgram(programId: string) {
  const result = await query<{
    id: string;
    slug: string;
    name: string;
    period_start: Date | string | null;
    period_end: Date | string | null;
  }>(
    "select id, slug, name, period_start, period_end from programs where id = $1",
    [programId]
  );
  const program = result.rows[0];
  if (!program) throw new Error("Program sertifikat tidak ditemukan.");
  return program;
}

async function getActiveCertificateTemplate(client: PoolClient, programId: string) {
  const result = await client.query(
    `
      select id, template_key, name, template_version, background_url, preview_image_url, layout_json, variables_json, is_active, notes
      from certificate_templates
      where program_id = $1 and is_active = true
      order by updated_at desc, created_at desc
      limit 1
    `,
    [programId]
  );
  return result.rows[0] ?? null;
}

async function ensureCertificateTemplate(client: PoolClient, programId: string) {
  const existing = await getActiveCertificateTemplate(client, programId);
  if (existing) return existing;

  const result = await client.query(
    `
      insert into certificate_templates (
        program_id,
        template_key,
        name,
        template_version,
        layout_json,
        variables_json,
        notes
      )
      values ($1, 'default', 'Template Sertifikat Clevio', 1, $2::jsonb, $3::jsonb, 'Template default. Upload/background dapat diatur dari dashboard.')
      returning id, template_key, name, template_version, background_url, preview_image_url, layout_json, variables_json, is_active, notes
    `,
    [programId, JSON.stringify(buildCertificateLayout({})), JSON.stringify(defaultCertificateVariables())]
  );
  return result.rows[0];
}

async function ensureCertificateTemplateForProgram(programId: string) {
  return withTransaction((client) => ensureCertificateTemplate(client, programId));
}

function defaultCertificateVariables() {
  return [
    "student_name",
    "program_name",
    "class_names",
    "level_name",
    "date_range",
    "certificate_number",
    "issued_date"
  ];
}

function buildCertificateLayout(input: CertificateTemplateInput, existing?: unknown) {
  const base = existing && typeof existing === "object" && !Array.isArray(existing) ? existing as Record<string, unknown> : {};
  return {
    primaryColor: normalizeCertificateColor(input.primaryColor ?? base.primaryColor, "#057BE3"),
    accentColor: normalizeCertificateColor(input.accentColor ?? base.accentColor, "#F2B929"),
    backgroundUrl: trimOrNull(input.backgroundUrl ?? (typeof base.backgroundUrl === "string" ? base.backgroundUrl : null)),
    logoUrl: trimOrNull(input.logoUrl ?? (typeof base.logoUrl === "string" ? base.logoUrl : null)),
    signatureName: (input.signatureName?.trim() || (typeof base.signatureName === "string" ? base.signatureName : null) || "Clevio").slice(0, 100)
  };
}

function normalizeCertificateColor(value: unknown, fallback: string) {
  if (typeof value !== "string") return fallback;
  const trimmed = value.trim();
  return /^#[0-9a-fA-F]{6}$/.test(trimmed) ? trimmed : fallback;
}

function trimOrNull(value: unknown) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed || null;
}

function buildCertificateNumber(programSlug: string, externalReference: string, certificateId: string) {
  const programCode = programSlug.includes("holiday-class") ? "HC-2026" : programSlug.replace(/[^a-z0-9]/gi, "").slice(0, 10).toUpperCase() || "CERT";
  const suffix = crypto.createHash("sha1").update(`${externalReference}:${certificateId}`).digest("hex").slice(0, 6).toUpperCase();
  return `${programCode}-${suffix}`;
}

async function releaseExpiredReservations() {
  return withTransaction(async (client) => {
    const expired = await client.query<{ id: string }>(
      `
        update registrations
        set status = 'expired',
            payment_status = 'expired',
            expired_at = now()
        where status in ('pending_invoice', 'waiting_payment')
          and reservation_expires_at is not null
          and reservation_expires_at < now()
        returning id
      `
    );
    for (const row of expired.rows) {
      await releaseReservedItems(client, row.id, "expired");
    }
    return { expiredRegistrations: expired.rowCount ?? 0 };
  });
}

async function syncWaitingInvoices() {
  const invoices = await query(
    `
      select external_reference, lms_invoice_id
      from invoice_references
      where status in ('waiting_payment', 'pending', 'pending_invoice')
      order by last_synced_at nulls first
      limit 50
    `
  );
  const lms = new LmsClient();
  let synced = 0;
  for (const invoice of invoices.rows) {
    const status = await lms.getInvoice(invoice.lms_invoice_id);
    if (status?.status) {
      await applyDbInvoiceWebhook({
        invoice_id: invoice.lms_invoice_id,
        external_reference: invoice.external_reference,
        status: status.status,
        paid_at: status.paid_at,
        amount: status.amount
      });
      synced += 1;
    }
  }
  return { synced };
}

async function reconcileAllBatchCounters() {
  const result = await query("select id from program_batches");
  await withTransaction(async (client) => {
    await reconcileBatchCounters(client, result.rows.map((row) => row.id));
  });
  return { reconciledBatches: result.rowCount ?? 0 };
}

async function getBatchCounts(client: PoolClient, batchIds: string[]) {
  if (batchIds.length === 0) return new Map<string, { reserved: number; confirmed: number }>();
  const result = await client.query(
    `
      select
        b.id,
        coalesce(count(ri.id) filter (
          where ri.slot_status = 'reserved'
            and r.status in ('pending_invoice', 'waiting_payment')
            and (r.reservation_expires_at is null or r.reservation_expires_at > now())
        ), 0)::int as reserved,
        coalesce(count(ri.id) filter (
          where ri.slot_status = 'confirmed'
            and r.status in ('paid', 'confirmed', 'completed')
        ), 0)::int as confirmed
      from program_batches b
      left join registration_items ri on ri.program_batch_id = b.id
      left join registrations r on r.id = ri.registration_id
      where b.id = any($1::uuid[])
      group by b.id
    `,
    [batchIds]
  );
  return new Map(result.rows.map((row) => [row.id, { reserved: Number(row.reserved), confirmed: Number(row.confirmed) }]));
}

async function confirmReservedItems(client: PoolClient, registrationId: string) {
  const items = await client.query<{ program_batch_id: string }>(
    `
      update registration_items
      set slot_status = 'confirmed',
          confirmed_at = now()
      where registration_id = $1
        and slot_status = 'reserved'
      returning program_batch_id
    `,
    [registrationId]
  );

  for (const item of items.rows) {
    await client.query(
      "update program_batches set reserved_count = greatest(0, reserved_count - 1), confirmed_count = confirmed_count + 1 where id = $1",
      [item.program_batch_id]
    );
  }
}

async function releaseReservedItems(client: PoolClient, registrationId: string, status: "released" | "expired" | "cancelled") {
  const items = await client.query<{ program_batch_id: string }>(
    `
      update registration_items
      set slot_status = $2::slot_status,
          released_at = now()
      where registration_id = $1
        and slot_status = 'reserved'
      returning program_batch_id
    `,
    [registrationId, status]
  );

  for (const item of items.rows) {
    await client.query("update program_batches set reserved_count = greatest(0, reserved_count - 1) where id = $1", [item.program_batch_id]);
  }
}

async function reconcileBatchCounters(client: PoolClient, batchIds: string[]) {
  if (batchIds.length === 0) return;
  const counts = await getBatchCounts(client, batchIds);
  for (const batchId of batchIds) {
    const count = counts.get(batchId) ?? { reserved: 0, confirmed: 0 };
    await client.query("update program_batches set reserved_count = $2, confirmed_count = $3 where id = $1", [
      batchId,
      count.reserved,
      count.confirmed
    ]);
  }
}

async function reconcileBatchCountersForRegistration(client: PoolClient, registrationId: string) {
  const result = await client.query<{ program_batch_id: string }>(
    "select distinct program_batch_id from registration_items where registration_id = $1",
    [registrationId]
  );
  await reconcileBatchCounters(client, result.rows.map((row) => row.program_batch_id));
}

async function activateDeviceOrders(client: PoolClient, registrationId: string) {
  await client.query(
    `
      insert into device_orders (registration_id, registration_addon_id, device_type, status)
      select
        ra.registration_id,
        ra.id,
        pa.name,
        'fulfillment_needed'
      from registration_addons ra
      join program_addons pa on pa.id = ra.program_addon_id
      where ra.registration_id = $1
        and ra.choice = 'buy'
        and ra.line_total > 0
        and not exists (
          select 1 from device_orders d where d.registration_addon_id = ra.id
        )
    `,
    [registrationId]
  );
}

function isOutsideFormWindow(row: QueryResultRow) {
  const now = Date.now();
  const startsAt = row.starts_at instanceof Date ? row.starts_at.getTime() : row.starts_at ? Date.parse(String(row.starts_at)) : null;
  const endsAt = row.ends_at instanceof Date ? row.ends_at.getTime() : row.ends_at ? Date.parse(String(row.ends_at)) : null;
  return Boolean((startsAt && startsAt > now) || (endsAt && endsAt < now));
}

async function isFormAtSubmissionLimit(formId: string, maxSubmissions?: number | null) {
  if (!maxSubmissions || maxSubmissions <= 0) return false;
  const result = await query<{ count: string }>(
    `
      select count(*)::text as count
      from registrations
      where form_id = $1
        and status not in ('invoice_failed', 'expired', 'cancelled')
    `,
    [formId]
  );
  return Number(result.rows[0]?.count ?? 0) >= maxSubmissions;
}

async function insertFormEvent(
  formId: string | undefined,
  eventType: string,
  stepKey?: string,
  ipAddress?: string | null,
  userAgent?: string | null,
  metadata: Record<string, unknown> = {}
) {
  await query(
    `
      insert into form_submission_events (
        program_id,
        form_id,
        event_type,
        step_key,
        ip_address,
        user_agent,
        metadata_json
      )
      values (
        (select program_id from program_forms where id = $1),
        $1,
        $2,
        $3,
        nullif($4, '')::inet,
        $5,
        $6::jsonb
      )
    `,
    [formId ?? null, eventType, stepKey ?? null, ipAddress ?? null, userAgent ?? null, JSON.stringify(metadata)]
  );
}

async function insertIntegrationLog(client: PoolClient, log: IntegrationLogInput) {
  await client.query(
    "insert into integration_logs (integration, action, status, error_message) values ($1, $2, $3, $4)",
    [log.integration, log.action, log.status, log.message]
  );
}

async function insertAuditLog(
  client: PoolClient,
  input: {
    action: string;
    entityType: string;
    entityId?: string;
    oldValue?: unknown;
    newValue?: unknown;
    reason?: string;
    adminId?: string;
    ipAddress?: string | null;
    userAgent?: string | null;
  }
) {
  await client.query(
    `
      insert into audit_logs (
        admin_id,
        action,
        entity_type,
        entity_id,
        old_value_json,
        new_value_json,
        reason,
        ip_address,
        user_agent
      )
      values ($1, $2, $3, $4, $5::jsonb, $6::jsonb, $7, nullif($8, '')::inet, $9)
    `,
    [
      input.adminId ?? null,
      input.action,
      input.entityType,
      input.entityId ?? null,
      JSON.stringify(input.oldValue ?? null),
      JSON.stringify(input.newValue ?? null),
      input.reason ?? null,
      input.ipAddress ?? null,
      input.userAgent ?? null
    ]
  );
}

function buildExternalReference(programSlug: string, sequence: number) {
  const code = programSlug.includes("holiday-class") ? "HC2026" : programSlug.replace(/[^a-z0-9]/gi, "").slice(0, 8).toUpperCase();
  return `REG-${code}-${String(sequence).padStart(6, "0")}`;
}

export async function quoteDbFromConfig(slug: string, accessToken: string | undefined, body: unknown) {
  const config = await getDbFormConfig(slug, accessToken);
  if (!config) {
    return { ok: false as const, code: "FORM_CLOSED" as const, message: "Form tidak ditemukan." };
  }
  return calculateQuote(config, body as never);
}

export class ReservationError extends Error {
  readonly code: FormErrorCode;

  constructor(code: FormErrorCode, message: string) {
    super(message);
    this.code = code;
  }
}
