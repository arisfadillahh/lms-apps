import type {
  AdminSnapshot,
  FormConfig,
  Program,
  ProgramAddon,
  ProgramBatch,
  ProgramClass,
  ProgramForm,
  ProgramFormField,
  ProgramFormStep,
  ProgramLevel,
  ProgramPackage,
  ProgramPricing,
  ProgramSession
} from "@/lib/types";

const program: Program = {
  id: "program-hc-2026",
  slug: "holiday-class-clevio-2026",
  name: "Holiday Class Clevio 2026",
  description: "Program liburan online Clevio yang fleksibel untuk single class dan bundling journey.",
  periodStart: "2026-06-15",
  periodEnd: "2026-07-05",
  mode: "online",
  platform: "Zoom",
  registrationOpenAt: "2026-06-01T00:00:00+07:00",
  registrationCloseAt: "2026-07-04T23:59:59+07:00",
  registrationDeadlineRule: "H-1 sebelum kelas dimulai selama slot tersedia",
  defaultSessionDurationMinutes: 90,
  defaultQuotaPerBatch: 10,
  noMinimumParticipant: true,
  hasLevels: true,
  hasPackages: true,
  hasBundling: true,
  hasAddons: true,
  hasScheduleSelection: true,
  hasAttendance: true,
  hasPitchingDay: true,
  hasCertificates: true,
  hasLivestreamPermission: true,
  hasWhatsappAutomation: true
};

const levels: ProgramLevel[] = [
  { id: "level-explorer", code: "explorer", name: "Explorer", gradeMin: 1, gradeMax: 3, gradeLabel: "Kelas 1-3 SD", sortOrder: 1 },
  { id: "level-creator", code: "creator", name: "Creator", gradeMin: 4, gradeMax: 6, gradeLabel: "Kelas 4-6 SD", sortOrder: 2 },
  { id: "level-innovator", code: "innovator", name: "Innovator", gradeMin: 7, gradeMax: 12, gradeLabel: "Kelas 7 SMP-12 SMA", sortOrder: 3 }
];

const classes: ProgramClass[] = [
  { id: "class-kodu", levelId: "level-explorer", slug: "kodu", name: "Kodu", softwareKey: "kodu", requiresDevice: false, sortOrder: 1 },
  { id: "class-scratch-jr", levelId: "level-explorer", slug: "scratch-jr", name: "Scratch Jr.", softwareKey: "scratch_jr", requiresDevice: false, sortOrder: 2 },
  { id: "class-minecraft-builder", levelId: "level-explorer", slug: "minecraft-builder", name: "Minecraft Builder", softwareKey: "minecraft_builder", requiresDevice: false, sortOrder: 3 },
  { id: "class-minecraft-coding", levelId: "level-creator", slug: "minecraft-coding", name: "Minecraft Coding", softwareKey: "minecraft_coding", requiresDevice: false, sortOrder: 1 },
  { id: "class-microbit", levelId: "level-creator", slug: "microbit", name: "Microbit", softwareKey: "microbit", requiresDevice: true, sortOrder: 2 },
  { id: "class-app-inventor", levelId: "level-creator", slug: "app-inventor", name: "App Inventor", softwareKey: "app_inventor", requiresDevice: false, sortOrder: 3 },
  {
    id: "class-blender-3d",
    levelId: "level-innovator",
    slug: "blender-3d",
    name: "Blender 3D",
    softwareKey: "blender_3d",
    requiresDevice: false,
    requirements: "CPU: Ryzen 5 5000 / Intel Core i5 gen 10\nGPU: Nvidia GTX/RTX series / AMD Radeon 5500 atau 5700 series (direkomendasikan VRAM 6/8GB)\nRAM: DDR4/5 8GB (direkomendasikan 12/16GB)",
    sortOrder: 1
  },
  { id: "class-vibe-coding", levelId: "level-innovator", slug: "vibe-coding", name: "Vibe Coding", softwareKey: "vibe_coding", requiresDevice: false, sortOrder: 2 },
  { id: "class-n8n-automation", levelId: "level-innovator", slug: "n8n-automation", name: "n8n Automation", softwareKey: "n8n_automation", requiresDevice: false, sortOrder: 3 },
  { id: "class-arduino", levelId: "level-innovator", slug: "arduino", name: "Arduino", softwareKey: "arduino", requiresDevice: true, sortOrder: 4 }
];

const packages: ProgramPackage[] = [
  {
    id: "package-single",
    code: "single",
    name: "Single Class",
    description: "1 kelas dan 1 software, durasi 3 hari belajar.",
    minClasses: 1,
    maxClasses: 1,
    sameLevelOnly: true,
    uniqueClassRequired: true,
    uniqueSoftwareRequired: true,
    oneClassPerWeek: false
  },
  {
    id: "package-bundling",
    code: "bundling",
    name: "Bundling Journey",
    description: "3 kelas + 3 software berbeda, total 9 hari belajar.",
    minClasses: 3,
    maxClasses: 3,
    sameLevelOnly: true,
    uniqueClassRequired: true,
    uniqueSoftwareRequired: true,
    oneClassPerWeek: true
  }
];

const pricingRows: Array<[string, string, number, string]> = [
  ["normal", "level-explorer", 350000, "package-single"],
  ["normal", "level-explorer", 900000, "package-bundling"],
  ["normal", "level-creator", 425000, "package-single"],
  ["normal", "level-creator", 1100000, "package-bundling"],
  ["normal", "level-innovator", 500000, "package-single"],
  ["normal", "level-innovator", 1300000, "package-bundling"],
  ["alpha_omega", "level-explorer", 325000, "package-single"],
  ["alpha_omega", "level-explorer", 900000, "package-bundling"],
  ["alpha_omega", "level-creator", 400000, "package-single"],
  ["alpha_omega", "level-creator", 1100000, "package-bundling"],
  ["alpha_omega", "level-innovator", 450000, "package-single"],
  ["alpha_omega", "level-innovator", 1300000, "package-bundling"],
  ["partner_school", "level-explorer", 325000, "package-single"],
  ["partner_school", "level-explorer", 900000, "package-bundling"],
  ["partner_school", "level-creator", 400000, "package-single"],
  ["partner_school", "level-creator", 1100000, "package-bundling"],
  ["partner_school", "level-innovator", 450000, "package-single"],
  ["partner_school", "level-innovator", 1300000, "package-bundling"]
];

const pricings: ProgramPricing[] = pricingRows.map(([priceType, levelId, price, packageId], index) => ({
  id: `pricing-${index + 1}`,
  priceType: priceType as ProgramPricing["priceType"],
  levelId,
  packageId,
  price,
  currency: "IDR"
}));

const addons: ProgramAddon[] = [
  {
    id: "addon-microbit",
    code: "microbit_device",
    name: "Device Microbit",
    price: 300000,
    appliesToClassId: "class-microbit",
    selectionType: "own_or_buy",
    isRequiredChoice: true
  },
  {
    id: "addon-arduino",
    code: "arduino_device",
    name: "Device Arduino",
    price: 350000,
    appliesToClassId: "class-arduino",
    selectionType: "simulator_own_or_buy",
    isRequiredChoice: true
  }
];

const forms: ProgramForm[] = [
  {
    id: "form-public",
    programId: program.id,
    slug: "holiday-class-2026",
    name: "Pendaftaran Holiday Class Clevio 2026",
    description: "Form pendaftaran publik untuk Holiday Class Clevio 2026.",
    templateKey: "holiday_class_registration",
    priceType: "normal",
    accessType: "public",
    status: "active",
    successTitle: "Invoice berhasil dibuat",
    successMessage: "Silakan lanjutkan pembayaran melalui link invoice."
  },
  {
    id: "form-partner",
    programId: program.id,
    slug: "holiday-class-partner-2026",
    name: "Pendaftaran Sekolah Partner Holiday Class Clevio 2026",
    description: "Form penawaran khusus untuk sekolah partner Clevio. Akses wajib menggunakan kode sekolah valid.",
    templateKey: "holiday_class_registration",
    priceType: "partner_school",
    accessType: "code",
    status: "active",
    successTitle: "Invoice sekolah partner berhasil dibuat",
    successMessage: "Silakan lanjutkan pembayaran melalui link invoice."
  }
];

const steps: ProgramFormStep[] = [
  { id: "step-parent", stepKey: "parent", title: "Data Orang Tua", description: "Kontak utama untuk invoice dan WhatsApp.", sortOrder: 1 },
  { id: "step-student", stepKey: "student", title: "Data Anak", description: "Grade anak menentukan level kelas.", sortOrder: 2 },
  { id: "step-package", stepKey: "package", title: "Pilih Paket", description: "Pilih Single Class atau Bundling Journey.", sortOrder: 3 },
  { id: "step-schedule", stepKey: "schedule", title: "Pilih Jadwal", description: "Pilih jadwal tersedia sesuai kuota.", sortOrder: 4 },
  { id: "step-addons", stepKey: "addons", title: "Device/Add-on", description: "Pilihan device muncul sesuai kelas.", sortOrder: 5 },
  { id: "step-agreement", stepKey: "agreement", title: "Izin & Persetujuan", description: "Konfirmasi izin dan kebijakan program.", sortOrder: 6 },
  {
    id: "step-summary",
    stepKey: "summary",
    title: "Ringkasan",
    description: "Periksa ulang data sebelum daftar.",
    sortOrder: 7
  }
];

const fields: ProgramFormField[] = [
  { id: "field-parent-name", stepKey: "parent", fieldKey: "parentName", label: "Nama Orang Tua", fieldType: "text", isRequired: true, sortOrder: 1 },
  { id: "field-parent-wa", stepKey: "parent", fieldKey: "parentWhatsapp", label: "Nomor WhatsApp", helpText: "Gunakan format 628xxxxxxxxxx.", fieldType: "tel", isRequired: true, sortOrder: 2 },
  { id: "field-parent-email", stepKey: "parent", fieldKey: "parentEmail", label: "Email", fieldType: "email", isRequired: true, sortOrder: 3 },
  { id: "field-student-name", stepKey: "student", fieldKey: "studentName", label: "Nama Anak", fieldType: "text", isRequired: true, sortOrder: 1 },
  { id: "field-student-grade", stepKey: "student", fieldKey: "studentGradeRaw", label: "Kelas Anak", fieldType: "select", isRequired: true, sortOrder: 2 },
  { id: "field-student-school", stepKey: "student", fieldKey: "studentSchool", label: "Asal Sekolah", fieldType: "text", isRequired: false, sortOrder: 3 }
];

const holidayScheduleRows = [
  { weekNo: 1, classSlug: "kodu", startDate: "2026-06-16", endDate: "2026-06-18", startTime: "10:00", endTime: "11:30" },
  { weekNo: 1, classSlug: "scratch-jr", startDate: "2026-06-18", endDate: "2026-06-20", startTime: "10:00", endTime: "11:30" },
  { weekNo: 1, classSlug: "minecraft-builder", startDate: "2026-06-15", endDate: "2026-06-17", startTime: "10:00", endTime: "11:30" },
  { weekNo: 1, classSlug: "minecraft-coding", startDate: "2026-06-15", endDate: "2026-06-17", startTime: "10:00", endTime: "11:30" },
  { weekNo: 1, classSlug: "microbit", startDate: "2026-06-18", endDate: "2026-06-20", startTime: "12:30", endTime: "14:00" },
  { weekNo: 1, classSlug: "app-inventor", startDate: "2026-06-15", endDate: "2026-06-17", startTime: "10:00", endTime: "11:30" },
  { weekNo: 1, classSlug: "blender-3d", startDate: "2026-06-15", endDate: "2026-06-17", startTime: "10:00", endTime: "11:30" },
  { weekNo: 1, classSlug: "vibe-coding", startDate: "2026-06-15", endDate: "2026-06-17", startTime: "12:30", endTime: "14:00" },
  { weekNo: 1, classSlug: "n8n-automation", startDate: "2026-06-15", endDate: "2026-06-17", startTime: "12:30", endTime: "14:00" },
  { weekNo: 1, classSlug: "arduino", startDate: "2026-06-18", endDate: "2026-06-20", startTime: "12:30", endTime: "14:00" },
  { weekNo: 2, classSlug: "kodu", startDate: "2026-06-23", endDate: "2026-06-25", startTime: "12:30", endTime: "14:00" },
  { weekNo: 2, classSlug: "scratch-jr", startDate: "2026-06-23", endDate: "2026-06-25", startTime: "10:00", endTime: "11:30" },
  { weekNo: 2, classSlug: "minecraft-builder", startDate: "2026-06-25", endDate: "2026-06-27", startTime: "10:00", endTime: "11:30" },
  { weekNo: 2, classSlug: "minecraft-coding", startDate: "2026-06-25", endDate: "2026-06-27", startTime: "12:30", endTime: "14:00" },
  { weekNo: 2, classSlug: "microbit", startDate: "2026-06-23", endDate: "2026-06-25", startTime: "10:00", endTime: "11:30" },
  { weekNo: 2, classSlug: "app-inventor", startDate: "2026-06-22", endDate: "2026-06-24", startTime: "10:00", endTime: "11:30" },
  { weekNo: 2, classSlug: "blender-3d", startDate: "2026-06-23", endDate: "2026-06-25", startTime: "10:00", endTime: "11:30" },
  { weekNo: 2, classSlug: "vibe-coding", startDate: "2026-06-25", endDate: "2026-06-27", startTime: "12:30", endTime: "14:00" },
  { weekNo: 2, classSlug: "n8n-automation", startDate: "2026-06-22", endDate: "2026-06-24", startTime: "12:30", endTime: "14:00" },
  { weekNo: 2, classSlug: "arduino", startDate: "2026-06-22", endDate: "2026-06-24", startTime: "12:30", endTime: "14:00" },
  { weekNo: 3, classSlug: "kodu", startDate: "2026-06-29", endDate: "2026-07-01", startTime: "10:00", endTime: "11:30" },
  { weekNo: 3, classSlug: "scratch-jr", startDate: "2026-06-29", endDate: "2026-07-01", startTime: "10:00", endTime: "11:30" },
  { weekNo: 3, classSlug: "minecraft-builder", startDate: "2026-06-30", endDate: "2026-07-02", startTime: "10:00", endTime: "11:30" },
  { weekNo: 3, classSlug: "minecraft-coding", startDate: "2026-06-29", endDate: "2026-07-01", startTime: "12:30", endTime: "14:00" },
  { weekNo: 3, classSlug: "microbit", startDate: "2026-06-29", endDate: "2026-07-01", startTime: "12:30", endTime: "14:00" },
  { weekNo: 3, classSlug: "app-inventor", startDate: "2026-06-30", endDate: "2026-07-02", startTime: "12:30", endTime: "14:00" },
  { weekNo: 3, classSlug: "blender-3d", startDate: "2026-06-30", endDate: "2026-07-02", startTime: "10:00", endTime: "11:30" },
  { weekNo: 3, classSlug: "vibe-coding", startDate: "2026-06-30", endDate: "2026-07-02", startTime: "10:00", endTime: "11:30" },
  { weekNo: 3, classSlug: "n8n-automation", startDate: "2026-06-30", endDate: "2026-07-02", startTime: "10:00", endTime: "11:30" },
  { weekNo: 3, classSlug: "arduino", startDate: "2026-06-30", endDate: "2026-07-02", startTime: "10:00", endTime: "11:30" }
];

function buildBatches() {
  const result: ProgramBatch[] = [];
  const sessionsResult: ProgramSession[] = [];

  for (const row of holidayScheduleRows) {
    const klass = classes.find((item) => item.slug === row.classSlug);
    if (!klass) continue;

    const batchId = `batch-${klass.slug}-w${row.weekNo}`;

    result.push({
      id: batchId,
      classId: klass.id,
      batchCode: `${klass.slug.toUpperCase().replaceAll("-", "_")}-W${row.weekNo}`,
      batchName: `${klass.name} - Week ${row.weekNo}`,
      weekNo: row.weekNo,
      startsAt: toJakartaIso(row.startDate, row.startTime),
      endsAt: toJakartaIso(row.endDate, row.endTime),
      timezone: "Asia/Jakarta",
      quota: 10,
      reservedCount: 0,
      confirmedCount: 0,
      status: "open"
    });

    for (let sessionNo = 1; sessionNo <= 3; sessionNo += 1) {
      const sessionDate = addDaysToDate(row.startDate, sessionNo - 1);
      sessionsResult.push({
        id: `session-${klass.slug}-w${row.weekNo}-${sessionNo}`,
        batchId,
        sessionNo,
        title: `Sesi ${sessionNo}`,
        startsAt: toJakartaIso(sessionDate, row.startTime),
        endsAt: toJakartaIso(sessionDate, row.endTime),
        durationMinutes: 90,
        meetingPlatform: "Zoom"
      });
    }
  }

  return { batches: result, sessions: sessionsResult };
}

function toJakartaIso(date: string, time: string) {
  return new Date(`${date}T${time}:00+07:00`).toISOString();
}

function addDaysToDate(date: string, days: number) {
  const [year, month, day] = date.split("-").map(Number);
  const next = new Date(Date.UTC(year, month - 1, day + days));
  return `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, "0")}-${String(next.getUTCDate()).padStart(2, "0")}`;
}

const schedule = buildBatches();

export const holidayClassConfig: FormConfig = {
  locked: false,
  program,
  form: forms[0],
  steps,
  fields,
  levels,
  classes,
  packages,
  pricings,
  addons,
  batches: schedule.batches,
  sessions: schedule.sessions,
  reviewNotes: [program.adminNotes ?? ""].filter(Boolean)
};

export function getDemoConfig(slug: string, accessGranted = false): FormConfig | null {
  const form = forms.find((item) => item.slug === slug);
  if (!form) return null;

  const locked = form.accessType !== "public" && !accessGranted;
  return {
    ...holidayClassConfig,
    locked,
    form,
    pricings: locked ? undefined : pricings.filter((pricing) => pricing.priceType === form.priceType),
    reviewNotes: holidayClassConfig.reviewNotes
  };
}

export function getAdminSnapshot(): AdminSnapshot {
  return {
    program,
    metrics: {
      programs: 1,
      activeForms: forms.length,
      availableBatches: schedule.batches.filter((batch) => batch.status === "open" && batch.quota - batch.confirmedCount > 0).length,
      registrations: 0,
      waitingPayment: 0,
      paid: 0,
      expired: 0,
      cancelled: 0,
      invoiceFailed: 0,
      deviceOrders: 0,
      invoiceCreated: 0,
      revenuePaid: 0,
      revenueWaiting: 0,
      urgentWarnings: 0
    },
    programs: [program],
    levels,
    classes,
    packages,
    pricings,
    addons,
    forms,
    batches: schedule.batches.slice(0, 12).map((batch) => {
      const klass = classes.find((item) => item.id === batch.classId)!;
      const batchSessions = schedule.sessions
        .filter((session) => session.batchId === batch.id)
        .sort((a, b) => a.sessionNo - b.sessionNo || a.startsAt.localeCompare(b.startsAt));
      const availableSlots = Math.max(0, batch.quota - batch.confirmedCount);
      return {
        ...batch,
        className: klass.name,
        classSlug: klass.slug,
        softwareKey: klass.softwareKey,
        levelId: klass.levelId,
        sessionCount: batchSessions.length || 1,
        firstSessionAt: batchSessions[0]?.startsAt ?? batch.startsAt,
        lastSessionAt: batchSessions[batchSessions.length - 1]?.startsAt ?? batch.endsAt,
        availableSlots,
        isSelectable: availableSlots > 0,
        disabledReason: availableSlots <= 0 ? "Kuota penuh" : undefined
      };
    }),
    sessions: schedule.sessions.slice(0, 36),
    batchRosters: schedule.batches.slice(0, 12).map((batch) => {
      const klass = classes.find((item) => item.id === batch.classId)!;
      const availableSlots = Math.max(0, batch.quota - batch.confirmedCount);
      return {
        batchId: batch.id,
        batchCode: batch.batchCode,
        batchName: batch.batchName,
        className: klass.name,
        weekNo: batch.weekNo,
        startsAt: batch.startsAt,
        endsAt: batch.endsAt,
        timezone: batch.timezone,
        scheduleLabel: `${batch.startsAt} - ${batch.endsAt}`,
        quota: batch.quota,
        reservedCount: batch.reservedCount,
        confirmedCount: batch.confirmedCount,
        availableSlots,
        students: []
      };
    }),
    registrations: [],
    invoices: [],
    deviceOrders: [],
    pitchingDayEntries: [],
    certificates: [],
    analytics: [
      { label: "Visits", value: 0 },
      { label: "Started", value: 0 },
      { label: "Quote Requested", value: 0 },
      { label: "Submitted", value: 0 },
      { label: "Invoice Created", value: 0 },
      { label: "Paid", value: 0 },
      { label: "Abandoned", value: 0 },
      { label: "Errors", value: 0 }
    ],
    integrationLogs: [
      { id: "log-lms-ready", integration: "LMS Core", action: "invoice_api", status: "ready", message: "Koneksi invoice LMS aktif." }
    ],
    whatsappLogs: [],
    webhookLogs: [],
    auditLogs: [],
    reconciliationLogs: [],
    attendanceSummary: {
      sessions: 0,
      records: 0,
      present: 0,
      absent: 0
    }
  };
}
