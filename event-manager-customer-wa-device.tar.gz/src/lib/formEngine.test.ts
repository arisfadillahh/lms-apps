import { describe, expect, it } from "vitest";
import { getDemoConfig } from "@/lib/demoData";
import { buildAvailability, calculateQuote, detectLevel, normalizeWhatsapp, redactProtectedConfig, validateAccessCode, verifyAccessToken } from "@/lib/formEngine";

describe("Holiday Class form engine", () => {
  it("maps SD/SMP/SMA grades to the correct level", () => {
    const config = getDemoConfig("holiday-class-2026", true)!;
    expect(detectLevel(config.levels, "3 SD")?.code).toBe("explorer");
    expect(detectLevel(config.levels, "6 SD")?.code).toBe("creator");
    expect(detectLevel(config.levels, "10 SMA")?.code).toBe("innovator");
  });

  it("calculates normal Creator bundling pricing with Microbit device", () => {
    const config = getDemoConfig("holiday-class-2026", true)!;
    const result = calculateQuote(config, {
      student: { studentName: "Raka", studentGradeRaw: "5 SD" },
      packageCode: "bundling",
      schedules: [
        { weekNo: 1, batchId: "batch-minecraft-coding-w1" },
        { weekNo: 2, batchId: "batch-microbit-w2" },
        { weekNo: 3, batchId: "batch-app-inventor-w3" }
      ],
      addons: [{ addonCode: "microbit_device", choice: "buy" }]
    });

    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.subtotal).toBe(1100000);
      expect(result.addonTotal).toBe(300000);
      expect(result.total).toBe(1400000);
    }
  });

  it("keeps waiting-payment reservations from reducing public availability", () => {
    const config = getDemoConfig("holiday-class-2026", true)!;
    const batch = config.batches.find((item) => item.id === "batch-minecraft-coding-w1")!;
    batch.quota = 10;
    batch.confirmedCount = 9;
    batch.reservedCount = 10;

    const result = calculateQuote(config, {
      student: { studentName: "Raka", studentGradeRaw: "5 SD" },
      packageCode: "single",
      schedules: [{ weekNo: 1, batchId: batch.id }],
      addons: []
    });

    expect(result.ok).toBe(true);
    if (result.ok) {
      const selected = buildAvailability(config, result.level.id).find((item) => item.id === batch.id);
      expect(selected?.availableSlots).toBe(1);
    }
  });

  it("does not expose partner school pricing while locked", () => {
    const config = getDemoConfig("holiday-class-partner-2026", false)!;
    const redacted = redactProtectedConfig(config);
    expect(redacted.locked).toBe(true);
    expect(redacted.pricings).toBeUndefined();
  });

  it("accepts the Global Sevilla partner school access code", () => {
    const config = getDemoConfig("holiday-class-partner-2026", false)!;
    const result = validateAccessCode(config.form.id, "GLOBALSEVILLA2026", "127.0.0.1");
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(verifyAccessToken(config.form.id, result.accessToken)).toBe(true);
    }
  });

  it("normalizes Indonesian WhatsApp numbers to 62 prefix", () => {
    expect(normalizeWhatsapp("08123456789")).toBe("628123456789");
    expect(normalizeWhatsapp("8123456789")).toBe("628123456789");
    expect(normalizeWhatsapp("+62 812-3456-789")).toBe("628123456789");
    expect(normalizeWhatsapp("6208123456789")).toBe("628123456789");
  });

  it("rejects duplicate class/software in bundling", () => {
    const config = getDemoConfig("holiday-class-2026", true)!;
    const result = calculateQuote(config, {
      student: { studentName: "Raka", studentGradeRaw: "5 SD" },
      packageCode: "bundling",
      schedules: [
        { weekNo: 1, batchId: "batch-microbit-w1" },
        { weekNo: 2, batchId: "batch-microbit-w2" },
        { weekNo: 3, batchId: "batch-app-inventor-w3" }
      ],
      addons: [{ addonCode: "microbit_device", choice: "own" }]
    });

    expect(result.ok).toBe(false);
  });
});
