import crypto from "node:crypto";
import type {
  AddonSelection,
  AvailabilityItem,
  FormConfig,
  FormError,
  FormErrorCode,
  ProgramAddon,
  ProgramBatch,
  ProgramClass,
  ProgramLevel,
  ProgramPackage,
  QuoteRequest,
  QuoteResult,
  SubmitRequest
} from "@/lib/types";

const ACCESS_TOKEN_TTL_MS = 30 * 60 * 1000;
const failedAccessAttempts = new Map<string, { count: number; resetAt: number }>();

type AccessTokenContext = {
  partnerSchoolId?: string;
};

export function normalizeGrade(raw: string) {
  const value = raw.trim().toLowerCase().replace(/\s+/g, " ");
  const numeric = Number(value.match(/\d+/)?.[0]);

  if (!Number.isFinite(numeric)) return null;

  if (value.includes("sma") || value.includes("smk")) {
    if (numeric >= 10 && numeric <= 12) return { normalized: `sma_${numeric}`, ordinal: numeric };
    if (numeric >= 1 && numeric <= 3) return { normalized: `sma_${numeric + 9}`, ordinal: numeric + 9 };
  }

  if (value.includes("smp")) {
    if (numeric >= 7 && numeric <= 9) return { normalized: `smp_${numeric}`, ordinal: numeric };
    if (numeric >= 1 && numeric <= 3) return { normalized: `smp_${numeric + 6}`, ordinal: numeric + 6 };
  }

  if (value.includes("sd")) {
    if (numeric >= 1 && numeric <= 6) return { normalized: `sd_${numeric}`, ordinal: numeric };
  }

  if (numeric >= 1 && numeric <= 6) return { normalized: `sd_${numeric}`, ordinal: numeric };
  if (numeric >= 7 && numeric <= 9) return { normalized: `smp_${numeric}`, ordinal: numeric };
  if (numeric >= 10 && numeric <= 12) return { normalized: `sma_${numeric}`, ordinal: numeric };

  return null;
}

export function normalizeWhatsapp(raw: string) {
  const digits = raw.replace(/\D/g, "");
  if (!digits) return "";
  if (digits.startsWith("08")) return `62${digits.slice(1)}`;
  if (digits.startsWith("8")) return `62${digits}`;
  if (digits.startsWith("620")) return `62${digits.slice(3)}`;
  if (digits.startsWith("62")) return digits;
  return digits;
}

export function detectLevel(levels: ProgramLevel[], rawGrade: string): ProgramLevel | null {
  const grade = normalizeGrade(rawGrade);
  if (!grade) return null;
  return levels.find((level) => grade.ordinal >= level.gradeMin && grade.ordinal <= level.gradeMax) ?? null;
}

export function formatRupiah(value: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(value);
}

export function formatScheduleRange(batch: ProgramBatch | AvailabilityItem) {
  const start = new Date(batch.startsAt);
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: batch.timezone
  }).format(start);
}

export function formatScheduleDateRange(batch: ProgramBatch | AvailabilityItem) {
  const firstSessionAt = "firstSessionAt" in batch ? batch.firstSessionAt : batch.startsAt;
  const lastSessionAt = "lastSessionAt" in batch ? batch.lastSessionAt : batch.endsAt;
  const timezone = batch.timezone;
  const start = new Date(firstSessionAt);
  const end = new Date(lastSessionAt);

  const dayFormatter = new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "short",
    timeZone: timezone
  });
  const fullFormatter = new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: timezone
  });

  const startParts = new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: timezone
  }).formatToParts(start);
  const endParts = new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: timezone
  }).formatToParts(end);
  const part = (parts: Intl.DateTimeFormatPart[], type: Intl.DateTimeFormatPartTypes) => parts.find((item) => item.type === type)?.value;

  if (part(startParts, "year") === part(endParts, "year") && part(startParts, "month") === part(endParts, "month")) {
    return `${part(startParts, "day")}-${fullFormatter.format(end)}`;
  }

  if (part(startParts, "year") === part(endParts, "year")) {
    return `${dayFormatter.format(start)}-${fullFormatter.format(end)}`;
  }

  return `${fullFormatter.format(start)}-${fullFormatter.format(end)}`;
}

export function formatScheduleTime(batch: ProgramBatch | AvailabilityItem) {
  const start = new Date("firstSessionAt" in batch ? batch.firstSessionAt : batch.startsAt);
  return new Intl.DateTimeFormat("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: batch.timezone
  }).format(start);
}

export function buildAvailability(config: FormConfig, levelId?: string): AvailabilityItem[] {
  const classesById = new Map(config.classes.map((item) => [item.id, item]));
  const sessionsByBatchId = new Map<string, typeof config.sessions>();
  for (const session of config.sessions) {
    const existing = sessionsByBatchId.get(session.batchId) ?? [];
    existing.push(session);
    sessionsByBatchId.set(session.batchId, existing);
  }

  const items: AvailabilityItem[] = [];

  for (const batch of config.batches) {
    const klass = classesById.get(batch.classId);
    if (!klass) continue;
    const sessions = (sessionsByBatchId.get(batch.id) ?? []).sort((a, b) => a.sessionNo - b.sessionNo || a.startsAt.localeCompare(b.startsAt));
    const firstSession = sessions[0];
    const lastSession = sessions[sessions.length - 1];
    const availableSlots = Math.max(0, batch.quota - batch.confirmedCount);
    const wrongLevel = Boolean(levelId && klass.levelId !== levelId);
    const closed = batch.status !== "open";
    const full = availableSlots <= 0;

    items.push({
      ...batch,
      className: klass.name,
      classSlug: klass.slug,
      softwareKey: klass.softwareKey,
      levelId: klass.levelId,
      sessionCount: sessions.length || 1,
      firstSessionAt: firstSession?.startsAt ?? batch.startsAt,
      lastSessionAt: lastSession?.startsAt ?? batch.endsAt,
      availableSlots,
      isSelectable: !wrongLevel && !closed && !full,
      disabledReason: wrongLevel ? "Tidak sesuai level" : closed ? "Jadwal ditutup" : full ? "Jadwal tidak tersedia" : undefined
    });
  }

  return items.sort((a, b) => a.weekNo - b.weekNo || a.startsAt.localeCompare(b.startsAt));
}

export function signAccessToken(formId: string, context: AccessTokenContext = {}) {
  const expiresAt = Date.now() + ACCESS_TOKEN_TTL_MS;
  const contextRaw = context.partnerSchoolId ? `school:${context.partnerSchoolId}` : "-";
  const payload = `${formId}.${expiresAt}.${contextRaw}`;
  const signature = crypto.createHmac("sha256", getAccessSecret()).update(payload).digest("hex");
  return `${payload}.${signature}`;
}

export function parseAccessToken(formId: string, token?: string): ({ ok: true } & AccessTokenContext) | { ok: false } {
  if (!token) return { ok: false };
  const parts = token.split(".");
  const isLegacy = parts.length === 3;
  const [tokenFormId, expiresAtRaw] = parts;
  const contextRaw = isLegacy ? "-" : parts[2];
  const signature = isLegacy ? parts[2] : parts[3];
  if (!tokenFormId || !expiresAtRaw || !signature) return { ok: false };
  if (tokenFormId !== formId) return { ok: false };
  const expiresAt = Number(expiresAtRaw);
  if (!Number.isFinite(expiresAt) || expiresAt < Date.now()) return { ok: false };
  const payload = isLegacy ? `${tokenFormId}.${expiresAtRaw}` : `${tokenFormId}.${expiresAtRaw}.${contextRaw}`;
  const expected = crypto.createHmac("sha256", getAccessSecret()).update(payload).digest("hex");
  if (signature.length !== expected.length) return { ok: false };
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return { ok: false };
  const partnerSchoolId = contextRaw?.startsWith("school:") ? contextRaw.slice("school:".length) : undefined;
  return partnerSchoolId ? { ok: true, partnerSchoolId } : { ok: true };
}

export function verifyAccessToken(formId: string, token?: string) {
  return parseAccessToken(formId, token).ok;
}

export function validateAccessCode(formId: string, code: string, ipAddress: string) {
  const normalized = code.trim();
  const key = `${formId}:${ipAddress}:${hashValue(normalized).slice(0, 12)}`;
  const now = Date.now();
  const attempt = failedAccessAttempts.get(key);
  if (attempt && attempt.resetAt > now && attempt.count >= 5) {
    return { ok: false as const, code: "RATE_LIMITED" as FormErrorCode, message: "Terlalu banyak percobaan kode. Coba lagi beberapa menit lagi." };
  }

  const demoPartnerSchoolByCode: Record<string, string> = {
    AO2026: "school-alpha-omega",
    GLOBALSEVILLA2026: "school-global-sevilla"
  };
  const partnerSchoolId = demoPartnerSchoolByCode[normalized.toUpperCase()];
  if (partnerSchoolId) {
    failedAccessAttempts.delete(key);
    return { ok: true as const, accessToken: signAccessToken(formId, { partnerSchoolId }) };
  }

  failedAccessAttempts.set(key, {
    count: attempt && attempt.resetAt > now ? attempt.count + 1 : 1,
    resetAt: now + 10 * 60 * 1000
  });
  return { ok: false as const, code: "INVALID_ACCESS" as FormErrorCode, message: "Kode sekolah partner tidak valid." };
}

export function redactProtectedConfig(config: FormConfig, accessToken?: string): FormConfig {
  const locked = config.form.accessType !== "public" && !verifyAccessToken(config.form.id, accessToken);
  return {
    ...config,
    locked,
    pricings: locked ? undefined : config.pricings?.filter((pricing) => pricing.priceType === config.form.priceType)
  };
}

export function calculateQuote(config: FormConfig, request: QuoteRequest): QuoteResult | FormError {
  if (config.locked) {
    return error("FORM_LOCKED", "Masukkan kode akses yang valid terlebih dahulu.");
  }

  if (config.form.status !== "active") {
    return error("FORM_CLOSED", "Form pendaftaran sedang tidak aktif.");
  }

  const level = detectLevel(config.levels, request.student.studentGradeRaw);
  if (!level) {
    return error("INVALID_GRADE", "Grade anak belum dapat dipetakan ke level program.", { studentGradeRaw: "Pilih kelas SD/SMP/SMA yang valid." });
  }

  const selectedPackage = config.packages.find((item) => item.code === request.packageCode);
  if (!selectedPackage) {
    return error("INVALID_PACKAGE", "Paket yang dipilih tidak valid.");
  }

  const packageValidation = validatePackageSelection(config, level, selectedPackage, request.schedules);
  if (!packageValidation.ok) return packageValidation;

  const pricing = config.pricings?.find((item) => item.levelId === level.id && item.packageId === selectedPackage.id && item.priceType === config.form.priceType);
  if (!pricing) {
    return error("INVALID_PACKAGE", "Harga paket belum dikonfigurasi untuk level ini.");
  }

  const selectedBatches = request.schedules
    .map((selection) => config.batches.find((batch) => batch.id === selection.batchId))
    .filter((batch): batch is ProgramBatch => Boolean(batch));
  const selectedClasses = selectedBatches
    .map((batch) => config.classes.find((klass) => klass.id === batch.classId))
    .filter((klass): klass is ProgramClass => Boolean(klass));

  const addonValidation = validateAddonSelection(config, selectedClasses, request.addons);
  if (!addonValidation.ok) return addonValidation;

  const packageLine = {
    kind: "package" as const,
    name: `${selectedPackage.name} - ${level.name} - ${config.program.name}`,
    qty: 1,
    price: pricing.price,
    total: pricing.price
  };

  const addonLines = addonValidation.addons.map((addon) => {
    const selected = request.addons.find((item) => item.addonCode === addon.code);
    const isBuy = selected?.choice === "buy";
    return {
      kind: "addon" as const,
      name: addon.name,
      qty: isBuy ? 1 : 0,
      price: addon.price,
      total: isBuy ? addon.price : 0,
      classId: addon.appliesToClassId
    };
  });

  const addonTotal = addonLines.reduce((sum, item) => sum + item.total, 0);
  return {
    ok: true,
    level,
    package: selectedPackage,
    selectedClasses,
    selectedBatches,
    lineItems: [packageLine, ...addonLines.filter((item) => item.total > 0)],
    subtotal: pricing.price,
    addonTotal,
    total: pricing.price + addonTotal,
    currency: pricing.currency,
    warnings: []
  };
}

export function validateSubmit(config: FormConfig, request: SubmitRequest) {
  const fieldErrors: Record<string, string> = {};
  const normalizedWhatsapp = normalizeWhatsapp(request.parent.parentWhatsapp);
  if (!request.parent.parentName.trim()) fieldErrors.parentName = "Nama orang tua wajib diisi.";
  if (!/^62\d{8,15}$/.test(normalizedWhatsapp)) fieldErrors.parentWhatsapp = "Nomor WhatsApp belum valid.";
  if (request.parent.parentEmail?.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(request.parent.parentEmail.trim())) fieldErrors.parentEmail = "Email belum valid.";
  if (!request.student.studentName.trim()) fieldErrors.studentName = "Nama anak wajib diisi.";
  if (!request.student.studentGradeRaw.trim()) fieldErrors.studentGradeRaw = "Kelas anak wajib dipilih.";

  if (Object.keys(fieldErrors).length > 0) {
    return error("INVALID_FIELDS", "Lengkapi data yang wajib diisi.", fieldErrors);
  }

  return calculateQuote(config, request);
}

function validatePackageSelection(config: FormConfig, level: ProgramLevel, selectedPackage: ProgramPackage, schedules: Array<{ weekNo: number; batchId: string }>): { ok: true } | FormError {
  if (schedules.length !== selectedPackage.maxClasses) {
    return error("INVALID_SCHEDULE", selectedPackage.code === "bundling" ? "Bundling Journey wajib memilih 3 jadwal." : "Single Class wajib memilih 1 jadwal.");
  }

  const availability = buildAvailability(config, level.id);
  const selectedBatches = schedules.map((selection) => availability.find((batch) => batch.id === selection.batchId));

  if (selectedBatches.some((batch) => !batch)) {
    return error("INVALID_SCHEDULE", "Ada jadwal yang tidak ditemukan.", undefined, availability);
  }

  const unavailable = selectedBatches.find((batch) => batch && !batch.isSelectable);
  if (unavailable) {
    return error(unavailable.availableSlots <= 0 ? "SCHEDULE_FULL" : "INVALID_SCHEDULE", `${unavailable.className} tidak tersedia: ${unavailable.disabledReason ?? "tidak dapat dipilih"}.`, undefined, availability);
  }

  const classIds = selectedBatches.map((batch) => batch!.classId);
  const softwareKeys = selectedBatches.map((batch) => batch!.softwareKey);
  const weekNos = schedules.map((selection) => selection.weekNo);

  if (selectedPackage.sameLevelOnly && selectedBatches.some((batch) => batch!.levelId !== level.id)) {
    return error("INVALID_SCHEDULE", "Semua jadwal harus sesuai level anak.", undefined, availability);
  }

  if (selectedPackage.uniqueClassRequired && new Set(classIds).size !== classIds.length) {
    return error("INVALID_SCHEDULE", "Bundling wajib memilih class yang berbeda.", undefined, availability);
  }

  if (selectedPackage.uniqueSoftwareRequired && new Set(softwareKeys).size !== softwareKeys.length) {
    return error("INVALID_SCHEDULE", "Bundling wajib memilih software yang berbeda.", undefined, availability);
  }

  if (selectedPackage.oneClassPerWeek && new Set(weekNos).size !== weekNos.length) {
    return error("INVALID_SCHEDULE", "Bundling wajib memilih satu class per minggu.", undefined, availability);
  }

  return { ok: true };
}

function validateAddonSelection(config: FormConfig, selectedClasses: ProgramClass[], selections: AddonSelection[]): { ok: true; addons: ProgramAddon[] } | FormError {
  const selectedClassIds = new Set(selectedClasses.map((klass) => klass.id));
  const requiredAddons = config.addons.filter((addon) => selectedClassIds.has(addon.appliesToClassId));

  for (const addon of requiredAddons) {
    const selected = selections.find((item) => item.addonCode === addon.code);
    if (!selected) {
      return error("INVALID_ADDON", `Pilihan ${addon.name} wajib dipilih.`);
    }
    const validChoices = addon.code === "microbit_device" ? ["own", "buy"] : ["simulator", "own", "buy"];
    if (!validChoices.includes(selected.choice)) {
      return error("INVALID_ADDON", `Pilihan ${addon.name} tidak valid.`);
    }
  }

  const invalid = selections.find((selection) => !requiredAddons.some((addon) => addon.code === selection.addonCode));
  if (invalid) {
    return error("INVALID_ADDON", "Add-on tidak sesuai dengan kelas yang dipilih.");
  }

  return { ok: true, addons: requiredAddons };
}

function error(code: FormErrorCode, message: string, fieldErrors?: Record<string, string>, availability?: AvailabilityItem[]): FormError {
  return { ok: false, code, message, fieldErrors, availability };
}

function getAccessSecret() {
  return process.env.FORM_ACCESS_SECRET || "local-dev-form-access-secret";
}

function hashValue(value: string) {
  return crypto.createHash("sha256").update(value).digest("hex");
}
