import type { NextRequest } from "next/server";

export async function getParams<T extends Record<string, string>>(params: T | Promise<T>) {
  return params instanceof Promise ? params : Promise.resolve(params);
}

export function getClientIp(request: NextRequest) {
  return request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? request.headers.get("x-real-ip") ?? "127.0.0.1";
}

export function getUserAgent(request: NextRequest) {
  return request.headers.get("user-agent") ?? "unknown";
}

