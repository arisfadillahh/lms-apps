import { afterEach, describe, expect, it, vi } from "vitest";
import { buildEventInvoiceWhatsAppMessage, buildEventPaymentConfirmedWhatsAppMessage, LmsClient } from "@/lib/lmsClient";

describe("LMS client WhatsApp integration", () => {
  const originalBaseUrl = process.env.LMS_API_BASE_URL;
  const originalToken = process.env.LMS_API_TOKEN;

  afterEach(() => {
    process.env.LMS_API_BASE_URL = originalBaseUrl;
    process.env.LMS_API_TOKEN = originalToken;
    vi.restoreAllMocks();
  });

  it("treats LMS WhatsApp success=false as a failed send", async () => {
    process.env.LMS_API_BASE_URL = "https://lms.test";
    process.env.LMS_API_TOKEN = "test-token";
    vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(JSON.stringify({ success: false, error: "WhatsApp not connected" }), {
        status: 200,
        headers: { "content-type": "application/json" }
      })
    );

    await expect(new LmsClient().sendWhatsAppMessage({ to: "628123456789", message: "Halo" })).rejects.toThrow("WhatsApp not connected");
  });

  it("marks LMS invoice paid through the service API", async () => {
    process.env.LMS_API_BASE_URL = "https://lms.test";
    process.env.LMS_API_TOKEN = "test-token";
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(JSON.stringify({ invoice_id: "INV-1", status: "paid" }), {
        status: 200,
        headers: { "content-type": "application/json" }
      })
    );

    await new LmsClient().markInvoicePaid("INV-1", {
      paidAt: "2026-06-10T13:20:00+07:00",
      reason: "Dikonfirmasi admin",
      externalReference: "REG-HC2026-000001"
    });

    expect(fetchMock).toHaveBeenCalledWith(
      "https://lms.test/api/invoices/INV-1/mark-paid",
      expect.objectContaining({
        method: "POST",
        headers: expect.objectContaining({
          authorization: "Bearer test-token"
        })
      })
    );
    expect(JSON.parse(String((fetchMock.mock.calls[0]?.[1] as RequestInit).body))).toMatchObject({
      paid_at: "2026-06-10T13:20:00+07:00",
      reason: "Dikonfirmasi admin",
      external_reference: "REG-HC2026-000001",
      notify_event_manager: false
    });
  });

  it("keeps LMS long payment link and maps the short payment link", async () => {
    process.env.LMS_API_BASE_URL = "https://lms.test";
    process.env.LMS_API_TOKEN = "test-token";
    vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(JSON.stringify({
        invoice_id: "INV-1",
        invoice_number: "INV/REG-HC2026-000001",
        payment_link: "https://lms.clev.io/invoice/id/inv-1?t=long-token",
        short_payment_link: "https://lms.clev.io/i/Ab7xK2p9",
        status: "waiting_payment",
        expired_at: "2026-06-10"
      }), {
        status: 200,
        headers: { "content-type": "application/json" }
      })
    );

    const invoice = await new LmsClient().createInvoice({
      external_reference: "REG-HC2026-000001",
      customer: { name: "Budi", whatsapp: "628123456789" },
      student: { name: "Raka" },
      items: [{ name: "Single Class", qty: 1, price: 425000 }],
      total: 425000,
      expired_at: "2026-06-10T17:00:00+07:00",
      callback_url: "https://lms.clev.io/event-manager/webhooks/lms/invoice"
    });

    expect(invoice.paymentLink).toBe("https://lms.clev.io/invoice/id/inv-1?t=long-token");
    expect(invoice.shortPaymentLink).toBe("https://lms.clev.io/i/Ab7xK2p9");
  });

  it("builds a parent-friendly invoice message with WhatsApp formatting", () => {
    const message = buildEventInvoiceWhatsAppMessage({
      parentName: "Budi",
      studentName: "Raka",
      programName: "Holiday Class Clevio 2026",
      packageName: "Single Class",
      levelName: "Creator",
      total: 425000,
      expiredAt: "2026-06-10T17:00:00+07:00",
      invoiceNumber: "INV/HC/2026/000001",
      paymentLink: "https://lms.clev.io/i/Ab7xK2p9",
      scheduleLines: ["Minggu 1 - Minecraft Coding - Sen, 15 Jun, 09.00"],
      addonLines: ["Device Microbit: Beli dari Clevio"]
    });

    expect(message).toContain("Halo *Budi*");
    expect(message).toContain("*Ringkasan Pendaftaran*");
    expect(message).toContain("Pendaftaran *Raka*");
    expect(message).toContain("Total: *Rp");
    expect(message).toContain("Batas bayar: _");
    expect(message).toContain("*Invoice*");
    expect(message).toContain("https://lms.clev.io/i/Ab7xK2p9");
    expect(message).toContain("1. Minggu 1 - Minecraft Coding");
    expect(message).toContain("*Device*");
    expect(message).toContain("1. Device Microbit: Beli dari Clevio");
  });

  it("builds a parent-friendly payment confirmation message", () => {
    const message = buildEventPaymentConfirmedWhatsAppMessage({
      parentName: "Budi",
      studentName: "Raka",
      programName: "Holiday Class Clevio 2026",
      packageName: "Single Class",
      levelName: "Creator",
      total: 425000,
      paidAt: "2026-06-10T13:20:00+07:00",
      invoiceNumber: "INV/HC/2026/000001",
      paymentLink: "https://lms.clev.io/invoice/id/inv-1?t=token",
      scheduleLines: ["Minggu 1 - Minecraft Coding - Sen, 15 Jun, 09.00"],
      addonLines: ["Device Microbit: Beli dari Clevio"]
    });

    expect(message).toContain("Halo *Budi*");
    expect(message).toContain("*Pembayaran Diterima*");
    expect(message).toContain("Pembayaran untuk pendaftaran *Raka*");
    expect(message).toContain("Status: *Terkonfirmasi*");
    expect(message).toContain("Holiday Class Clevio 2026");
    expect(message).toContain("Rp");
    expect(message).toContain("INV/HC/2026/000001");
    expect(message).toContain("https://lms.clev.io/invoice/id/inv-1?t=token");
    expect(message).toContain("1. Minggu 1 - Minecraft Coding");
    expect(message).toContain("*Device*");
    expect(message).toContain("1. Device Microbit: Beli dari Clevio");
  });
});
