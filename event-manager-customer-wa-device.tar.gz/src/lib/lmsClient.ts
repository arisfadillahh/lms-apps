import type { InvoiceReference, QuoteResult, SubmitRequest } from "@/lib/types";

export type LmsInvoicePayload = {
  external_reference: string;
  customer: {
    name: string;
    whatsapp: string;
    email?: string;
  };
  student: {
    name: string;
  };
  items: Array<{
    name: string;
    qty: number;
    price: number;
  }>;
  total: number;
  expired_at: string;
  callback_url: string;
};

export type LmsCertificatePayload = {
  external_reference: string;
  student: {
    name: string;
  };
  program: {
    name: string;
    date_range?: string | null;
  };
  class_names: string[];
  level_name?: string | null;
  issued_date?: string | null;
  certificate_number?: string | null;
  template?: {
    key?: string;
    name?: string;
    version?: number;
    layout?: Record<string, unknown>;
  };
};

export type LmsCertificateResponse = {
  certificateId: string;
  certificateNumber: string;
  certificateUrl: string;
  status: string;
  templateVersion?: number | null;
};

export class LmsClient {
  private readonly baseUrl = process.env.LMS_API_BASE_URL;
  private readonly token = process.env.LMS_API_TOKEN;

  async createInvoice(payload: LmsInvoicePayload): Promise<InvoiceReference> {
    if (!this.baseUrl) {
      return {
        invoiceId: `INV-MOCK-${payload.external_reference.replace(/\D/g, "").slice(-6) || Date.now()}`,
        invoiceNumber: `INV/HC/2026/${payload.external_reference.slice(-6)}`,
        paymentLink: `https://lms.clev.io/mock-pay/${payload.external_reference}`,
        shortPaymentLink: `https://lms.clev.io/i/mock${payload.external_reference.replace(/\D/g, "").slice(-4) || "0000"}`,
        status: "waiting_payment",
        expiredAt: payload.expired_at
      };
    }

    const response = await this.request("/api/invoices", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    return {
      invoiceId: response.invoice_id,
      invoiceNumber: response.invoice_number,
      paymentLink: response.payment_link,
      shortPaymentLink: response.short_payment_link ?? response.shortPaymentLink ?? null,
      status: response.status,
      expiredAt: response.expired_at
    };
  }

  async sendWhatsAppMessage(payload: { to: string; message: string }) {
    if (!this.baseUrl) {
      return { ok: true, mocked: true };
    }

    const response = await this.request("/api/whatsapp/send", {
      method: "POST",
      body: JSON.stringify(payload)
    });
    if (response?.success === false || response?.ok === false) {
      throw new Error(response?.error ?? response?.message ?? "LMS WhatsApp send failed");
    }
    return response;
  }

  async resendInvoice(invoiceId: string) {
    if (!this.baseUrl) return { ok: true, mocked: true };
    return this.request(`/api/invoices/${encodeURIComponent(invoiceId)}/resend`, {
      method: "POST"
    });
  }

  async getInvoice(invoiceId: string) {
    if (!this.baseUrl) {
      return {
        invoice_id: invoiceId,
        status: "waiting_payment"
      };
    }
    return this.request(`/api/invoices/${encodeURIComponent(invoiceId)}`, {
      method: "GET"
    });
  }

  async markInvoicePaid(invoiceId: string, payload: {
    paidAt?: string;
    paidNotes?: string;
    reason?: string;
    externalReference?: string;
  }) {
    const paidAt = payload.paidAt ?? new Date().toISOString();
    if (!this.baseUrl) {
      return {
        ok: true,
        mocked: true,
        invoice_id: invoiceId,
        status: "paid",
        paid_at: paidAt
      };
    }
    return this.request(`/api/invoices/${encodeURIComponent(invoiceId)}/mark-paid`, {
      method: "POST",
      body: JSON.stringify({
        paid_at: paidAt,
        paid_notes: payload.paidNotes ?? payload.reason ?? "Marked paid from Event Manager",
        reason: payload.reason,
        external_reference: payload.externalReference,
        notify_event_manager: false
      })
    });
  }

  async createShortLink(payload: {
    targetUrl: string;
    linkType?: string;
    entityType?: string;
    entityId?: string | null;
    metadata?: Record<string, unknown>;
  }): Promise<{ shortUrl: string; targetUrl: string }> {
    if (!payload.targetUrl) {
      throw new Error("Target URL short link kosong.");
    }
    if (!this.baseUrl) {
      return { shortUrl: payload.targetUrl, targetUrl: payload.targetUrl };
    }

    const response = await this.request("/api/short-links", {
      method: "POST",
      body: JSON.stringify({
        target_url: payload.targetUrl,
        link_type: payload.linkType ?? "invoice",
        entity_type: payload.entityType,
        entity_id: payload.entityId,
        metadata: payload.metadata
      })
    });

    return {
      shortUrl: response.short_url ?? payload.targetUrl,
      targetUrl: response.target_url ?? payload.targetUrl
    };
  }

  async generateCertificate(payload: LmsCertificatePayload): Promise<LmsCertificateResponse> {
    const fallbackNumber = payload.certificate_number ?? `CERT-${payload.external_reference.replace(/[^a-z0-9]/gi, "").slice(-8).toUpperCase() || Date.now()}`;
    if (!this.baseUrl) {
      return {
        certificateId: `CERT-MOCK-${fallbackNumber}`,
        certificateNumber: fallbackNumber,
        certificateUrl: `https://lms.clev.io/certificate/mock-${encodeURIComponent(payload.external_reference)}`,
        status: "generated",
        templateVersion: payload.template?.version ?? 1
      };
    }

    const response = await this.request("/api/certificates/generate", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    return {
      certificateId: response.certificate_id,
      certificateNumber: response.certificate_number,
      certificateUrl: response.certificate_url,
      status: response.status ?? "generated",
      templateVersion: response.template_version ?? null
    };
  }

  private async request(path: string, init: RequestInit) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12_000);

    try {
      const response = await fetch(`${this.baseUrl}${path}`, {
        ...init,
        signal: controller.signal,
        headers: {
          "content-type": "application/json",
          authorization: this.token ? `Bearer ${this.token}` : "",
          ...(init.headers ?? {})
        }
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.message ?? data?.error ?? `LMS API failed with ${response.status}`);
      }
      return data;
    } finally {
      clearTimeout(timeout);
    }
  }
}

export function buildInvoicePayload(input: SubmitRequest, quote: QuoteResult, externalReference: string): LmsInvoicePayload {
  const expiredAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
  const callbackBase = process.env.EVENT_MANAGER_PUBLIC_URL || "https://lms.clev.io/event-manager";
  const email = input.parent.parentEmail?.trim();
  return {
    external_reference: externalReference,
    customer: {
      name: input.parent.parentName,
      whatsapp: input.parent.parentWhatsapp,
      ...(email ? { email } : {})
    },
    student: {
      name: input.student.studentName
    },
    items: quote.lineItems.map((item) => ({
      name: item.name,
      qty: item.qty,
      price: item.price
    })),
    total: quote.total,
    expired_at: expiredAt,
    callback_url: `${callbackBase}/webhooks/lms/invoice`
  };
}

export type EventInvoiceWhatsAppMessageInput = {
  parentName: string;
  studentName: string;
  programName: string;
  invoiceNumber: string;
  paymentLink: string;
  total: number;
  expiredAt?: string | null;
  packageName?: string;
  levelName?: string;
  scheduleLines?: string[];
  addonLines?: string[];
};

export type EventPaymentConfirmedWhatsAppMessageInput = {
  parentName: string;
  studentName: string;
  programName: string;
  total: number;
  paidAt?: string | null;
  invoiceNumber?: string | null;
  paymentLink?: string | null;
  packageName?: string | null;
  levelName?: string | null;
  scheduleLines?: string[];
  addonLines?: string[];
};

export type EventCertificateWhatsAppMessageInput = {
  parentName: string;
  studentName: string;
  programName: string;
  certificateUrl: string;
  classNames: string[];
};

export function buildEventInvoiceWhatsAppMessage(input: EventInvoiceWhatsAppMessageInput) {
  const summary = [
    input.levelName ? `Level: *${input.levelName}*` : null,
    input.packageName ? `Paket: *${input.packageName}*` : null,
    `Total: *${formatCurrency(input.total)}*`,
    input.expiredAt ? `Batas bayar: _${formatDateTime(input.expiredAt)}_` : null
  ].filter((line): line is string => Boolean(line));
  const schedules = input.scheduleLines && input.scheduleLines.length > 0 ? formatNumberedLines(input.scheduleLines) : [];
  const addons = input.addonLines && input.addonLines.length > 0 ? formatNumberedLines(input.addonLines) : [];

  return [
    `Halo *${input.parentName}*,`,
    "",
    `Pendaftaran *${input.studentName}* untuk *${input.programName}* sudah kami terima.`,
    "",
    "*Ringkasan Pendaftaran*",
    ...summary,
    schedules.length ? "" : null,
    schedules.length ? "*Jadwal Pilihan*" : null,
    ...schedules,
    addons.length ? "" : null,
    addons.length ? "*Device*" : null,
    ...addons,
    "",
    "*Invoice*",
    `Nomor: *${input.invoiceNumber}*`,
    "Link pembayaran:",
    input.paymentLink,
    "",
    "_Setelah pembayaran terkonfirmasi, slot kelas otomatis aman._",
    "",
    "Terima kasih,",
    "*Clevio*"
  ].filter((line): line is string => line !== null).join("\n");
}

export function buildEventPaymentConfirmedWhatsAppMessage(input: EventPaymentConfirmedWhatsAppMessageInput) {
  const summary = [
    "Status: *Terkonfirmasi*",
    input.levelName ? `Level: *${input.levelName}*` : null,
    input.packageName ? `Paket: *${input.packageName}*` : null,
    `Total diterima: *${formatCurrency(input.total)}*`,
    input.paidAt ? `Dibayar: _${formatDateTime(input.paidAt)}_` : null
  ].filter((line): line is string => Boolean(line));
  const schedules = input.scheduleLines && input.scheduleLines.length > 0 ? formatNumberedLines(input.scheduleLines) : [];
  const addons = input.addonLines && input.addonLines.length > 0 ? formatNumberedLines(input.addonLines) : [];

  return [
    `Halo *${input.parentName}*,`,
    "",
    "*Pembayaran Diterima*",
    "",
    `Pembayaran untuk pendaftaran *${input.studentName}* di *${input.programName}* sudah kami terima.`,
    "",
    "*Ringkasan*",
    ...summary,
    schedules.length ? "" : null,
    schedules.length ? "*Jadwal Kelas*" : null,
    ...schedules,
    addons.length ? "" : null,
    addons.length ? "*Device*" : null,
    ...addons,
    input.paymentLink ? "" : null,
    input.invoiceNumber ? `Invoice: *${input.invoiceNumber}*` : null,
    input.paymentLink ? "Cek status invoice/pembayaran:" : null,
    input.paymentLink ?? null,
    "",
    "_Slot kelas sudah aman. Informasi teknis kelas akan dikirim melalui WhatsApp ini._",
    "",
    "Terima kasih,",
    "*Clevio*"
  ].filter((line): line is string => line !== null).join("\n");
}

export function buildEventCertificateWhatsAppMessage(input: EventCertificateWhatsAppMessageInput) {
  return [
    `Halo ${input.parentName},`,
    "",
    `Sertifikat ${input.studentName} untuk ${input.programName} sudah siap.`,
    input.classNames.length ? `Kelas: ${input.classNames.join(", ")}` : null,
    "",
    "Silakan buka link sertifikat berikut:",
    input.certificateUrl,
    "",
    "Terima kasih sudah mengikuti kegiatan Clevio.",
    "Clevio"
  ].filter((line): line is string => line !== null).join("\n");
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(value);
}

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  }).format(new Date(value));
}

function formatNumberedLines(lines: string[]) {
  return lines.map((line, index) => `${index + 1}. ${line}`);
}
