import { LmsClient } from "@/lib/lmsClient";
import { recordIntegrationLog } from "@/lib/repository";
import type { PaymentConfirmationWhatsappContext } from "@/lib/types";

export async function resolveShortPaymentLink(context: PaymentConfirmationWhatsappContext) {
  if (context.shortPaymentLink || !context.paymentLink) {
    return context.shortPaymentLink || context.paymentLink || null;
  }

  const lms = new LmsClient();
  try {
    const result = await lms.createShortLink({
      targetUrl: context.paymentLink,
      linkType: "invoice",
      entityType: "invoice",
      entityId: context.invoiceId || context.invoiceNumber || context.invoiceReferenceId || context.registrationId,
      metadata: {
        invoice_number: context.invoiceNumber,
        registration_id: context.registrationId,
        student_name: context.studentName
      }
    });
    return result.shortUrl;
  } catch (error) {
    await recordIntegrationLog({
      integration: "LMS Core",
      action: "create_short_payment_link",
      status: "failed",
      message: error instanceof Error ? error.message : "Short payment link failed"
    });
    return context.paymentLink;
  }
}
