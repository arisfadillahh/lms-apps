import { randomUUID } from "node:crypto";
import { getAdminSnapshot as getSeedAdminSnapshot, getDemoConfig, holidayClassConfig } from "@/lib/demoData";
import { hasDatabase } from "@/lib/db";
import {
  ReservationError,
  applyDbInvoiceWebhook,
  attachDbInvoice,
  createDbProgram,
  createDbProgramBatch,
  createDbProgramPackage,
  deleteDbRegistration,
  getDbAdminSnapshot,
  getDbAvailabilityForProgram,
  getDbFormConfig,
  getDbPaymentConfirmationWhatsappContext,
  getDbRegistrationPaymentContext,
  hasDbSuccessfulWhatsappLog,
  listDbAuditLogs,
  listDbCertificates,
  listDbPitchingDayEntries,
  listDbPrograms,
  listDbReconciliationLogs,
  generateDbCertificates,
  markDbInvoiceFailed,
  manualDbPaymentOverride,
  prepareDbCertificates,
  prepareDbInvoiceRetry,
  quoteDbFromConfig,
  recordDbFormEvent,
  recordDbIntegrationLog,
  recordDbWhatsappLog,
  recordDbWebhookLog,
  refreshDbInvoiceStatusFromLms,
  reserveDbRegistration,
  runDbMaintenanceJob,
  saveDbCertificateTemplate,
  sendDbCertificates,
  updateDbDeviceOrder,
  updateDbFormField,
  updateDbProgramPackage,
  updateDbProgramPricing,
  updateDbProgram,
  updateDbProgramBatch,
  updateDbProgramForm,
  upsertDbProgramPricing,
  validateDbFormAccess
} from "@/lib/dbRepository";
import { buildAvailability, calculateQuote, normalizeGrade, parseAccessToken, verifyAccessToken } from "@/lib/formEngine";
import type {
  AdminSnapshot,
  FormErrorCode,
  FormConfig,
  InvoiceReference,
  PaymentConfirmationWhatsappContext,
  QuoteResult,
  RegistrationPaymentContext,
  RegistrationStatus,
  SubmitRequest
} from "@/lib/types";

type RuntimeRegistration = {
  id: string;
  externalReference: string;
  parentName: string;
  parentWhatsapp: string;
  parentEmail?: string;
  studentName: string;
  studentGradeRaw: string;
  studentGradeNormalized: string;
  studentSchool?: string;
  partnerSchoolName?: string;
  partnerSchoolSlug?: string;
  levelId: string;
  packageId: string;
  packageName: string;
  status: RegistrationStatus;
  paymentStatus: string;
  reservationExpiresAt: string;
  total: number;
  adminNotes?: string;
  items: Array<{ batchId: string; classId: string; slotStatus: string }>;
  addons: SubmitRequest["addons"];
  invoice?: InvoiceReference;
};

type RuntimeIntegrationLog = {
  id: string;
  integration: string;
  action: string;
  status: string;
  message: string;
};

type RuntimeWhatsappLog = {
  id: string;
  registrationId?: string | null;
  messageType: string;
  recipient: string;
  status: string;
  errorMessage?: string | null;
  createdAt: string;
};

type AdminActor = {
  adminId?: string;
  ipAddress?: string | null;
  userAgent?: string | null;
};

const registrations: RuntimeRegistration[] = [];
const integrationLogs: RuntimeIntegrationLog[] = [];
const whatsappLogs: RuntimeWhatsappLog[] = [];
const formEvents: Array<{ formId?: string; eventType: string; stepKey?: string; ipAddress?: string; userAgent?: string }> = [];

function formatScheduleDate(value: string) {
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  }).format(new Date(value));
}

export async function getFormConfig(slug: string, accessToken?: string): Promise<FormConfig | null> {
  if (hasDatabase()) return getDbFormConfig(slug, accessToken);

  const initial = getDemoConfig(slug, false);
  if (!initial) return null;
  const parsedAccessToken = parseAccessToken(initial.form.id, accessToken);
  const accessGranted = initial.form.accessType === "public" || parsedAccessToken.ok;
  const config = getDemoConfig(slug, accessGranted);
  if (!config || !parsedAccessToken.ok || !parsedAccessToken.partnerSchoolId) return config;
  const partnerSchool = getDemoPartnerSchool(parsedAccessToken.partnerSchoolId);
  return partnerSchool ? { ...config, accessContext: { partnerSchool } } : config;
}

function getDemoPartnerSchool(id: string) {
  if (id === "school-alpha-omega") return { id, slug: "alpha-omega", name: "Alpha Omega" };
  if (id === "school-global-sevilla") return { id, slug: "global-sevilla", name: "Global Sevilla" };
  return null;
}

export async function getAvailabilityForProgram(programId: string, levelId?: string) {
  if (hasDatabase()) return getDbAvailabilityForProgram(programId, levelId);

  if (programId !== holidayClassConfig.program.id) return [];
  return buildAvailability(holidayClassConfig, levelId);
}

export async function validateFormAccess(slug: string, code: string, ipAddress?: string | null, userAgent?: string | null) {
  if (hasDatabase()) return validateDbFormAccess(slug, code, ipAddress, userAgent);

  const config = getDemoConfig(slug, false);
  if (!config) {
    return { ok: false as const, code: "FORM_CLOSED" as FormErrorCode, message: "Form tidak ditemukan." };
  }
  if (config.form.accessType === "public") {
    return { ok: true as const, accessToken: null };
  }
  const { validateAccessCode } = await import("@/lib/formEngine");
  return validateAccessCode(config.form.id, code, ipAddress ?? "127.0.0.1");
}

export async function reserveRegistration(input: SubmitRequest, quote: QuoteResult, config?: FormConfig) {
  if (hasDatabase()) {
    if (!config) throw new ReservationError("SERVER_ERROR", "Form config dibutuhkan untuk reservation DB.");
    return reserveDbRegistration(input, quote, config);
  }

  const registrationId = randomUUID();
  const externalReference = `REG-HC2026-${String(registrations.length + 1).padStart(6, "0")}`;
  const grade = normalizeGrade(input.student.studentGradeRaw);
  const reservationExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

  for (const batch of quote.selectedBatches) {
    batch.reservedCount += 1;
  }

  const registration: RuntimeRegistration = {
    id: registrationId,
    externalReference,
    parentName: input.parent.parentName,
    parentWhatsapp: input.parent.parentWhatsapp,
    parentEmail: input.parent.parentEmail,
    studentName: input.student.studentName,
    studentGradeRaw: input.student.studentGradeRaw,
    studentGradeNormalized: grade?.normalized ?? input.student.studentGradeRaw,
    studentSchool: input.student.studentSchool,
    partnerSchoolName: config?.accessContext?.partnerSchool?.name,
    partnerSchoolSlug: config?.accessContext?.partnerSchool?.slug,
    levelId: quote.level.id,
    packageId: quote.package.id,
    packageName: quote.package.name,
    status: "pending_invoice",
    paymentStatus: "pending_invoice",
    reservationExpiresAt,
    total: quote.total,
    adminNotes: undefined,
    items: quote.selectedBatches.map((batch) => ({ batchId: batch.id, classId: batch.classId, slotStatus: "reserved" })),
    addons: input.addons ?? []
  };

  registrations.unshift(registration);
  return registration;
}

export async function attachInvoice(registrationId: string, invoice: InvoiceReference) {
  if (hasDatabase()) return attachDbInvoice(registrationId, invoice);

  const registration = registrations.find((item) => item.id === registrationId);
  if (!registration) return;
  registration.invoice = invoice;
  registration.status = "waiting_payment";
  registration.paymentStatus = invoice.status;
}

export async function markInvoiceFailed(registrationId: string, message: string) {
  if (hasDatabase()) return markDbInvoiceFailed(registrationId, message);

  const registration = registrations.find((item) => item.id === registrationId);
  if (!registration) return;
  registration.status = "invoice_failed";
  registration.paymentStatus = "invoice_failed";
  registration.items.forEach((item) => {
    if (item.slotStatus === "reserved") item.slotStatus = "released";
    const batch = holidayClassConfig.batches.find((candidate) => candidate.id === item.batchId);
    if (batch) batch.reservedCount = Math.max(0, batch.reservedCount - 1);
  });
  integrationLogs.unshift({
    id: randomUUID(),
    integration: "LMS Core",
    action: "create_invoice",
    status: "failed",
    message
  });
}

export async function prepareInvoiceRetry(registrationId: string, actor?: AdminActor) {
  if (hasDatabase()) return prepareDbInvoiceRetry(registrationId, actor);
  throw new ReservationError("SERVER_ERROR", "Retry invoice hanya tersedia saat database aktif.");
}

export async function applyInvoiceWebhook(payload: {
  invoice_id: string;
  external_reference: string;
  status: "paid" | "expired" | "cancelled" | string;
  paid_at?: string;
  amount?: number;
}) {
  if (hasDatabase()) return applyDbInvoiceWebhook(payload);

  const registration = registrations.find((item) => item.externalReference === payload.external_reference);
  if (!registration) return { updated: false, reason: "registration_not_found" };

  if (payload.status === "paid") {
    registration.status = "confirmed";
    registration.paymentStatus = "paid";
    registration.items.forEach((item) => {
      if (item.slotStatus === "reserved") {
        item.slotStatus = "confirmed";
        const batch = holidayClassConfig.batches.find((candidate) => candidate.id === item.batchId);
        if (batch) {
          batch.reservedCount = Math.max(0, batch.reservedCount - 1);
          batch.confirmedCount += 1;
        }
      }
    });
    activateDeviceOrders(registration);
  }

  if (payload.status === "expired" || payload.status === "cancelled") {
    registration.status = payload.status;
    registration.paymentStatus = payload.status;
    registration.items.forEach((item) => {
      if (item.slotStatus === "reserved") {
        item.slotStatus = payload.status;
        const batch = holidayClassConfig.batches.find((candidate) => candidate.id === item.batchId);
        if (batch) batch.reservedCount = Math.max(0, batch.reservedCount - 1);
      }
    });
  }

  if (payload.status !== "paid" && payload.status !== "expired" && payload.status !== "cancelled") {
    registration.paymentStatus = payload.status;
    if (["waiting_payment", "pending", "pending_invoice"].includes(payload.status) && !["paid", "confirmed", "completed"].includes(registration.status)) {
      registration.status = "waiting_payment";
    }
  }

  return { updated: true };
}

export async function refreshInvoiceStatusFromLms(invoiceId: string, lmsResponse: unknown, actor?: AdminActor) {
  if (hasDatabase()) return refreshDbInvoiceStatusFromLms(invoiceId, lmsResponse, actor);

  const response = isRecord(lmsResponse) ? lmsResponse : {};
  const status = readString(response, ["status", "payment_status", "invoice_status"]);
  if (!status) throw new Error("Response LMS tidak berisi status invoice.");

  const registration = registrations.find((item) => item.invoice?.invoiceId === invoiceId || item.invoice?.invoiceNumber === invoiceId);
  if (!registration || !registration.invoice) return { updated: false, reason: "invoice_not_found" };
  registration.invoice.status = status;

  return applyInvoiceWebhook({
    invoice_id: registration.invoice.invoiceId,
    external_reference: registration.externalReference,
    status,
    paid_at: readString(response, ["paid_at", "paidAt", "payment_paid_at"]),
    amount: readNumber(response, ["amount", "total", "paid_amount"]) ?? registration.total
  });
}

export async function getPaymentConfirmationWhatsappContext(externalReference: string): Promise<PaymentConfirmationWhatsappContext | null> {
  if (hasDatabase()) return getDbPaymentConfirmationWhatsappContext(externalReference);

  const registration = registrations.find((item) => item.externalReference === externalReference);
  if (!registration) return null;
  const level = holidayClassConfig.levels.find((item) => item.id === registration.levelId);

  return {
    registrationId: registration.id,
    invoiceReferenceId: null,
    invoiceId: registration.invoice?.invoiceId ?? null,
    invoiceNumber: registration.invoice?.invoiceNumber ?? null,
    paymentLink: registration.invoice?.paymentLink ?? null,
    shortPaymentLink: registration.invoice?.shortPaymentLink ?? null,
    parentName: registration.parentName,
    parentWhatsapp: registration.parentWhatsapp,
    studentName: registration.studentName,
    programName: holidayClassConfig.program.name,
    packageName: registration.packageName,
    levelName: level?.name ?? null,
    partnerSchoolName: registration.partnerSchoolName ?? null,
    total: registration.total,
    paidAt: registration.invoice?.status === "paid" ? new Date().toISOString() : null,
    scheduleLines: registration.items.map((item) => {
      const batch = holidayClassConfig.batches.find((candidate) => candidate.id === item.batchId);
      const klass = holidayClassConfig.classes.find((candidate) => candidate.id === item.classId);
      return [`Week ${batch?.weekNo ?? "-"}`, klass?.name ?? "Class", batch ? formatScheduleDate(batch.startsAt) : ""].filter(Boolean).join(" - ");
    }),
    addonLines: registration.addons.map((item) => {
      const addon = holidayClassConfig.addons.find((candidate) => candidate.code === item.addonCode);
      return `${addon?.name ?? item.addonCode}: ${formatAddonChoiceLabel(item.choice)}`;
    })
  };
}

export async function hasSuccessfulWhatsappLog(registrationId: string, messageType: string) {
  if (hasDatabase()) return hasDbSuccessfulWhatsappLog(registrationId, messageType);
  return whatsappLogs.some((item) => item.registrationId === registrationId && item.messageType === messageType && item.status === "success");
}

export async function getRegistrationPaymentContext(registrationId: string): Promise<RegistrationPaymentContext | null> {
  if (hasDatabase()) return getDbRegistrationPaymentContext(registrationId);
  const registration = registrations.find((item) => item.id === registrationId);
  if (!registration) return null;
  return {
    id: registration.id,
    externalReference: registration.externalReference,
    status: registration.status,
    paymentStatus: registration.paymentStatus,
    invoiceId: registration.invoice?.invoiceId ?? null,
    invoiceNumber: registration.invoice?.invoiceNumber ?? null,
    paymentLink: registration.invoice?.paymentLink ?? null,
    shortPaymentLink: registration.invoice?.shortPaymentLink ?? null,
    invoiceStatus: registration.invoice?.status ?? null
  };
}

export async function recordFormEvent(event: {
  formId?: string;
  eventType: string;
  stepKey?: string;
  ipAddress?: string | null;
  userAgent?: string | null;
}) {
  if (hasDatabase()) return recordDbFormEvent(event);

  formEvents.push({
    formId: event.formId,
    eventType: event.eventType,
    stepKey: event.stepKey,
    ipAddress: event.ipAddress ?? undefined,
    userAgent: event.userAgent ?? undefined
  });
}

export async function recordIntegrationLog(log: Omit<RuntimeIntegrationLog, "id">) {
  if (hasDatabase()) return recordDbIntegrationLog(log);

  integrationLogs.unshift({ id: randomUUID(), ...log });
}

export async function recordWhatsappLog(log: {
  registrationId?: string | null;
  invoiceReferenceId?: string | null;
  messageType: string;
  recipient: string;
  messagePreview?: string | null;
  response?: unknown;
  status: string;
  errorMessage?: string | null;
}) {
  if (hasDatabase()) return recordDbWhatsappLog(log);

  whatsappLogs.unshift({
    id: randomUUID(),
    registrationId: log.registrationId ?? null,
    messageType: log.messageType,
    recipient: log.recipient,
    status: log.status,
    errorMessage: log.errorMessage,
    createdAt: new Date().toISOString()
  });
}

export async function recordWebhookLog(input: {
  source: string;
  eventType: string;
  eventId?: string | null;
  externalReference?: string | null;
  payload: unknown;
  signatureValid: boolean;
  processingStatus: string;
  errorMessage?: string | null;
}) {
  if (hasDatabase()) return recordDbWebhookLog(input);
  return undefined;
}

export async function getAdminSnapshot(): Promise<AdminSnapshot> {
  if (hasDatabase()) return getDbAdminSnapshot();

  const seed = getSeedAdminSnapshot();
  const waitingPayment = registrations.filter((item) => item.status === "waiting_payment").length;
  const paid = registrations.filter((item) => item.status === "paid" || item.status === "confirmed").length;
  const expired = registrations.filter((item) => item.status === "expired").length;
  const cancelled = registrations.filter((item) => item.status === "cancelled").length;
  const invoiceFailed = registrations.filter((item) => item.status === "invoice_failed").length;
  const invoices = registrations
    .filter((item) => item.invoice)
    .map((item) => ({
      id: item.invoice?.invoiceId ?? item.id,
      registrationId: item.id,
      invoiceId: item.invoice?.invoiceId ?? "-",
      invoiceNumber: item.invoice?.invoiceNumber,
      externalReference: item.externalReference,
      studentName: item.studentName,
      parentName: item.parentName,
      total: item.total,
      status: item.invoice?.status ?? item.paymentStatus,
      paymentLink: item.invoice?.paymentLink,
      shortPaymentLink: item.invoice?.shortPaymentLink,
      createdAt: new Date().toISOString(),
      expiredAt: item.invoice?.expiredAt,
      paidAt: item.paymentStatus === "paid" ? new Date().toISOString() : null
    }));
  const runtimeBatches = buildAvailability(holidayClassConfig).slice(0, 18);
  const batchRosters = runtimeBatches.map((batch) => ({
    batchId: batch.id,
    batchCode: batch.batchCode,
    batchName: batch.batchName,
    className: batch.className,
    weekNo: batch.weekNo,
    startsAt: batch.startsAt,
    endsAt: batch.endsAt,
    timezone: batch.timezone,
    scheduleLabel: `${batch.batchCode} - Week ${batch.weekNo}`,
    quota: batch.quota,
    reservedCount: batch.reservedCount,
    confirmedCount: batch.confirmedCount,
    availableSlots: batch.availableSlots,
    students: registrations
      .filter((registration) => registration.items.some((item) => item.batchId === batch.id))
      .map((registration) => {
        const item = registration.items.find((candidate) => candidate.batchId === batch.id);
        const selectedPackage = holidayClassConfig.packages.find((candidate) => candidate.id === registration.packageId);
        return {
          registrationId: registration.id,
          externalReference: registration.externalReference,
          studentName: registration.studentName,
          parentName: registration.parentName,
          parentWhatsapp: registration.parentWhatsapp,
          levelName: holidayClassConfig.levels.find((level) => level.id === registration.levelId)?.name,
          packageName: registration.packageName,
          packageCode: selectedPackage?.code,
          isBundling: selectedPackage?.code === "bundling" || registration.packageName.toLowerCase().includes("bundling"),
          registrationStatus: registration.status,
          paymentStatus: registration.paymentStatus,
          total: registration.total,
          slotStatus: item?.slotStatus ?? registration.status,
          submittedAt: undefined
        };
      })
  }));

  return {
    ...seed,
    metrics: {
      ...seed.metrics,
      registrations: registrations.length,
      waitingPayment,
      paid,
      expired,
      cancelled,
      invoiceFailed,
      invoiceCreated: invoices.length,
      revenuePaid: registrations.filter((item) => item.status === "paid" || item.status === "confirmed").reduce((sum, item) => sum + item.total, 0),
      revenueWaiting: registrations.filter((item) => item.status === "waiting_payment").reduce((sum, item) => sum + item.total, 0),
      urgentWarnings: invoiceFailed
    },
    batches: runtimeBatches,
    batchRosters,
    registrations: registrations.map((item) => ({
      id: item.id,
      externalReference: item.externalReference,
      parentName: item.parentName,
      parentWhatsapp: item.parentWhatsapp,
      parentEmail: item.parentEmail,
      studentName: item.studentName,
      studentGradeRaw: item.studentGradeRaw,
      studentGradeNormalized: item.studentGradeNormalized,
      studentSchool: item.studentSchool,
      partnerSchoolName: item.partnerSchoolName,
      partnerSchoolSlug: item.partnerSchoolSlug,
      levelName: holidayClassConfig.levels.find((level) => level.id === item.levelId)?.name,
      packageName: item.packageName,
      selectedClasses: item.items.map((registrationItem) => holidayClassConfig.classes.find((klass) => klass.id === registrationItem.classId)?.name ?? "-"),
      selectedSchedules: item.items.map((registrationItem) => {
        const batch = holidayClassConfig.batches.find((candidate) => candidate.id === registrationItem.batchId);
        return batch ? `${batch.batchCode} - Week ${batch.weekNo}` : "-";
      }),
      sourceForm: holidayClassConfig.form.name,
      priceType: holidayClassConfig.form.priceType,
      status: item.status,
      paymentStatus: item.paymentStatus,
      total: item.total,
      invoiceId: item.invoice?.invoiceId,
      invoiceNumber: item.invoice?.invoiceNumber,
      invoiceStatus: item.invoice?.status,
      paymentLink: item.invoice?.paymentLink,
      shortPaymentLink: item.invoice?.shortPaymentLink,
      adminNotes: item.adminNotes
    })),
    invoices,
    analytics: [
      { label: "Visits", value: formEvents.filter((item) => item.eventType === "visit").length },
      { label: "Started", value: formEvents.filter((item) => item.eventType === "started").length },
      { label: "Submitted", value: formEvents.filter((item) => item.eventType === "submitted").length },
      { label: "Invoice Created", value: integrationLogs.filter((item) => item.action === "create_invoice" && item.status === "success").length },
      { label: "Paid", value: paid },
      { label: "Errors", value: formEvents.filter((item) => item.eventType === "error").length }
    ],
    integrationLogs: [...integrationLogs, ...seed.integrationLogs].slice(0, 8),
    whatsappLogs: [...whatsappLogs, ...seed.whatsappLogs].slice(0, 20)
  };
}

export async function listPrograms() {
  if (hasDatabase()) return listDbPrograms();
  return [holidayClassConfig.program];
}

export async function createProgram(input: Parameters<typeof createDbProgram>[0], actor?: AdminActor) {
  if (hasDatabase()) return createDbProgram(input, actor);
  throw new Error("Program CRUD needs EVENT_MANAGER_DATABASE_URL.");
}

export async function updateProgram(id: string, input: Parameters<typeof updateDbProgram>[1], actor?: AdminActor) {
  if (hasDatabase()) return updateDbProgram(id, input, actor);
  throw new Error("Program CRUD needs EVENT_MANAGER_DATABASE_URL.");
}

export async function updateProgramForm(id: string, input: Parameters<typeof updateDbProgramForm>[1], actor?: AdminActor) {
  if (hasDatabase()) return updateDbProgramForm(id, input, actor);
  throw new Error("Form settings need EVENT_MANAGER_DATABASE_URL.");
}

export async function updateFormField(id: string, input: Parameters<typeof updateDbFormField>[1], actor?: AdminActor) {
  if (hasDatabase()) return updateDbFormField(id, input, actor);
  throw new Error("Form field settings need EVENT_MANAGER_DATABASE_URL.");
}

export async function updateProgramBatch(id: string, input: Parameters<typeof updateDbProgramBatch>[1], actor?: AdminActor) {
  if (hasDatabase()) return updateDbProgramBatch(id, input, actor);
  throw new Error("Schedule management needs EVENT_MANAGER_DATABASE_URL.");
}

export async function createProgramBatch(input: Parameters<typeof createDbProgramBatch>[0], actor?: AdminActor) {
  if (hasDatabase()) return createDbProgramBatch(input, actor);
  throw new Error("Schedule management needs EVENT_MANAGER_DATABASE_URL.");
}

export async function createProgramPackage(input: Parameters<typeof createDbProgramPackage>[0], actor?: AdminActor) {
  if (hasDatabase()) return createDbProgramPackage(input, actor);
  throw new Error("Package management needs EVENT_MANAGER_DATABASE_URL.");
}

export async function updateProgramPackage(id: string, input: Parameters<typeof updateDbProgramPackage>[1], actor?: AdminActor) {
  if (hasDatabase()) return updateDbProgramPackage(id, input, actor);
  throw new Error("Package management needs EVENT_MANAGER_DATABASE_URL.");
}

export async function upsertProgramPricing(input: Parameters<typeof upsertDbProgramPricing>[0], actor?: AdminActor) {
  if (hasDatabase()) return upsertDbProgramPricing(input, actor);
  throw new Error("Pricing management needs EVENT_MANAGER_DATABASE_URL.");
}

export async function updateProgramPricing(id: string, input: Parameters<typeof updateDbProgramPricing>[1], actor?: AdminActor) {
  if (hasDatabase()) return updateDbProgramPricing(id, input, actor);
  throw new Error("Pricing management needs EVENT_MANAGER_DATABASE_URL.");
}

export async function updateDeviceOrder(id: string, input: Parameters<typeof updateDbDeviceOrder>[1], actor?: AdminActor) {
  if (hasDatabase()) return updateDbDeviceOrder(id, input, actor);
  throw new Error("Device order management needs EVENT_MANAGER_DATABASE_URL.");
}

export async function deleteRegistration(id: string, input: Parameters<typeof deleteDbRegistration>[1], actor?: AdminActor) {
  if (hasDatabase()) return deleteDbRegistration(id, input, actor);
  const index = registrations.findIndex((item) => item.id === id);
  if (index < 0) return null;
  const [registration] = registrations.splice(index, 1);
  for (const item of registration.items) {
    const batch = holidayClassConfig.batches.find((candidate) => candidate.id === item.batchId);
    if (!batch) continue;
    if (item.slotStatus === "reserved") batch.reservedCount = Math.max(0, batch.reservedCount - 1);
    if (item.slotStatus === "confirmed") batch.confirmedCount = Math.max(0, batch.confirmedCount - 1);
  }
  return { id, externalReference: registration.externalReference, deleted: true };
}

export async function manualPaymentOverride(registrationId: string, input: Parameters<typeof manualDbPaymentOverride>[1], actor?: AdminActor) {
  if (hasDatabase()) return manualDbPaymentOverride(registrationId, input, actor);
  const registration = registrations.find((item) => item.id === registrationId);
  if (!registration) return null;
  const oldStatus = registration.status;
  const targetRegistrationStatus: RegistrationStatus = input.newStatus === "paid" ? "confirmed" : input.newStatus;
  const targetPaymentStatus = ["paid", "confirmed", "completed"].includes(input.newStatus) ? "paid" : input.newStatus;
  registration.status = targetRegistrationStatus;
  registration.paymentStatus = targetPaymentStatus;
  if (registration.invoice && targetPaymentStatus === "paid") {
    registration.invoice.status = "paid";
  }
  if (targetPaymentStatus === "paid") {
    registration.items.forEach((item) => {
      if (item.slotStatus === "reserved") {
        item.slotStatus = "confirmed";
        const batch = holidayClassConfig.batches.find((candidate) => candidate.id === item.batchId);
        if (batch) {
          batch.reservedCount = Math.max(0, batch.reservedCount - 1);
          batch.confirmedCount += 1;
        }
      }
    });
    activateDeviceOrders(registration);
  }
  if (targetRegistrationStatus === "expired" || targetRegistrationStatus === "cancelled") {
    registration.items.forEach((item) => {
      if (item.slotStatus === "reserved") {
        item.slotStatus = targetRegistrationStatus;
        const batch = holidayClassConfig.batches.find((candidate) => candidate.id === item.batchId);
        if (batch) batch.reservedCount = Math.max(0, batch.reservedCount - 1);
      }
    });
  }
  return {
    id: registrationId,
    externalReference: registration.externalReference,
    oldStatus,
    newStatus: targetRegistrationStatus,
    paymentStatus: targetPaymentStatus,
    reason: input.reason
  };
}

export async function listAuditLogs() {
  if (hasDatabase()) return listDbAuditLogs();
  return [];
}

export async function listReconciliationLogs() {
  if (hasDatabase()) return listDbReconciliationLogs();
  return [];
}

export async function listPitchingDayEntries(programId?: string) {
  if (hasDatabase()) return listDbPitchingDayEntries(programId);
  return [];
}

export async function listCertificates(programId?: string) {
  if (hasDatabase()) return listDbCertificates(programId);
  return [];
}

export async function saveCertificateTemplate(input: Parameters<typeof saveDbCertificateTemplate>[0], actor?: AdminActor) {
  if (hasDatabase()) return saveDbCertificateTemplate(input, actor);
  throw new Error("Certificate template settings need EVENT_MANAGER_DATABASE_URL.");
}

export async function prepareCertificates(programId?: string | null, actor?: AdminActor) {
  if (hasDatabase()) return prepareDbCertificates(programId, actor);
  throw new Error("Certificate preparation needs EVENT_MANAGER_DATABASE_URL.");
}

export async function generateCertificates(programId?: string | null, actor?: AdminActor) {
  if (hasDatabase()) return generateDbCertificates(programId, actor);
  throw new Error("Certificate generation needs EVENT_MANAGER_DATABASE_URL.");
}

export async function sendCertificates(programId?: string | null, actor?: AdminActor) {
  if (hasDatabase()) return sendDbCertificates(programId, actor);
  throw new Error("Certificate sending needs EVENT_MANAGER_DATABASE_URL.");
}

export async function runMaintenanceJob(jobName: "release-expired-reservations" | "sync-invoices" | "reconcile-batch-counters") {
  if (hasDatabase()) return runDbMaintenanceJob(jobName);

  if (jobName === "release-expired-reservations") {
    const now = Date.now();
    let released = 0;
    for (const registration of registrations) {
      if (registration.status === "waiting_payment" && Date.parse(registration.reservationExpiresAt) < now) {
        registration.status = "expired";
        registration.paymentStatus = "expired";
        for (const item of registration.items) {
          if (item.slotStatus === "reserved") {
            item.slotStatus = "expired";
            released += 1;
            const batch = holidayClassConfig.batches.find((candidate) => candidate.id === item.batchId);
            if (batch) batch.reservedCount = Math.max(0, batch.reservedCount - 1);
          }
        }
      }
    }
    return { jobName, status: "success", summary: { released } };
  }

  if (jobName === "reconcile-batch-counters") {
    for (const batch of holidayClassConfig.batches) {
      const relatedItems = registrations.flatMap((registration) => registration.items.filter((item) => item.batchId === batch.id));
      batch.reservedCount = relatedItems.filter((item) => item.slotStatus === "reserved").length;
      batch.confirmedCount = relatedItems.filter((item) => item.slotStatus === "confirmed").length;
    }
    return { jobName, status: "success", summary: { reconciledBatches: holidayClassConfig.batches.length } };
  }

  return { jobName, status: "success", summary: { synced: 0, note: "LMS sync requires LMS_API_BASE_URL and stored invoice references." } };
}

export async function quoteFromConfig(slug: string, accessToken: string | undefined, body: unknown) {
  if (hasDatabase()) return quoteDbFromConfig(slug, accessToken, body);

  const config = await getFormConfig(slug, accessToken);
  if (!config) {
    return { ok: false as const, code: "FORM_CLOSED" as const, message: "Form tidak ditemukan." };
  }
  return calculateQuote(config, body as never);
}

function activateDeviceOrders(registration: RuntimeRegistration) {
  integrationLogs.unshift({
    id: randomUUID(),
    integration: "Device Orders",
    action: "activate_after_payment",
    status: "success",
    message: `Device order choices for ${registration.externalReference} are ready for fulfillment.`
  });
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function readString(value: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const candidate = value[key];
    if (typeof candidate === "string" && candidate.trim()) return candidate.trim();
  }
  return undefined;
}

function readNumber(value: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const candidate = value[key];
    if (typeof candidate === "number" && Number.isFinite(candidate)) return candidate;
    if (typeof candidate === "string" && candidate.trim() && Number.isFinite(Number(candidate))) return Number(candidate);
  }
  return undefined;
}

function formatAddonChoiceLabel(choice?: string | null) {
  if (choice === "buy") return "Beli dari Clevio";
  if (choice === "own") return "Punya sendiri";
  if (choice === "simulator") return "Pakai simulator";
  return choice || "-";
}
