export type PriceType = "normal" | "alpha_omega" | "partner_school";
export type AccessType = "public" | "code" | "token";
export type FormStatus = "draft" | "active" | "closed" | "archived";
export type RegistrationStatus =
  | "pending_invoice"
  | "invoice_failed"
  | "waiting_payment"
  | "paid"
  | "confirmed"
  | "expired"
  | "cancelled"
  | "completed";
export type SlotStatus = "reserved" | "confirmed" | "released" | "expired" | "cancelled";

export type Program = {
  id: string;
  slug: string;
  name: string;
  description?: string;
  periodStart: string;
  periodEnd: string;
  mode: string;
  platform: string;
  registrationOpenAt?: string;
  registrationCloseAt?: string;
  registrationDeadlineRule?: string;
  defaultSessionDurationMinutes: number;
  defaultQuotaPerBatch: number;
  noMinimumParticipant?: boolean;
  hasLevels?: boolean;
  hasPackages?: boolean;
  hasBundling?: boolean;
  hasAddons?: boolean;
  hasScheduleSelection?: boolean;
  hasAttendance?: boolean;
  hasPitchingDay?: boolean;
  hasCertificates?: boolean;
  hasLivestreamPermission?: boolean;
  hasWhatsappAutomation?: boolean;
  adminNotes?: string;
};

export type ProgramLevel = {
  id: string;
  code: "explorer" | "creator" | "innovator" | string;
  name: string;
  gradeMin: number;
  gradeMax: number;
  gradeLabel: string;
  description?: string;
  isActive?: boolean;
  sortOrder: number;
};

export type ProgramClass = {
  id: string;
  levelId: string;
  slug: string;
  name: string;
  softwareKey: string;
  requiresDevice: boolean;
  description?: string;
  outputDescription?: string;
  requirements?: string;
  deviceRequirementSetting?: string;
  isActive?: boolean;
  sortOrder: number;
};

export type ProgramPackage = {
  id: string;
  code: "single" | "bundling" | string;
  name: string;
  description: string;
  minClasses: number;
  maxClasses: number;
  sameLevelOnly: boolean;
  uniqueClassRequired: boolean;
  uniqueSoftwareRequired: boolean;
  oneClassPerWeek: boolean;
  requiredWeekCount?: number | null;
  allowCustomSelection?: boolean;
  isActive?: boolean;
};

export type ProgramPricing = {
  id: string;
  priceType: PriceType;
  levelId: string;
  packageId: string;
  price: number;
  currency: string;
  effectiveFrom?: string | null;
  effectiveUntil?: string | null;
  isActive?: boolean;
  lastEditedByAdmin?: string | null;
};

export type ProgramAddon = {
  id: string;
  code: "microbit_device" | "arduino_device" | string;
  name: string;
  price: number;
  appliesToClassId: string;
  selectionType: string;
  isRequiredChoice: boolean;
  description?: string;
  choices?: Array<{ label: string; value: string; price?: number }>;
  isActive?: boolean;
};

export type ProgramBatch = {
  id: string;
  classId: string;
  levelId?: string | null;
  batchCode: string;
  batchName?: string | null;
  weekNo: number;
  startsAt: string;
  endsAt: string;
  timezone: string;
  quota: number;
  reservedCount: number;
  confirmedCount: number;
  status: "open" | "closed" | "full" | string;
  notes?: string | null;
};

export type ProgramSession = {
  id: string;
  batchId: string;
  sessionNo: number;
  title: string;
  startsAt: string;
  endsAt: string;
  durationMinutes: number;
  meetingPlatform: string;
  meetingUrl?: string | null;
  meetingLocation?: string | null;
  notes?: string | null;
};

export type ProgramForm = {
  id: string;
  programId: string;
  slug: string;
  name: string;
  description: string;
  templateKey: string;
  priceType: PriceType;
  accessType: AccessType;
  status: FormStatus;
  maxSubmissions?: number | null;
  successTitle: string;
  successMessage: string;
};

export type PartnerSchool = {
  id: string;
  programId: string;
  slug: string;
  name: string;
  status: "active" | "inactive" | string;
  priceType?: PriceType;
  adminNotes?: string | null;
};

export type FormAccessContext = {
  partnerSchool?: Pick<PartnerSchool, "id" | "slug" | "name">;
};

export type ProgramFormStep = {
  id: string;
  stepKey: string;
  title: string;
  description: string;
  adminReviewNotes?: string;
  sortOrder: number;
};

export type ProgramFormField = {
  id: string;
  stepKey: string;
  fieldKey: string;
  label: string;
  helpText?: string;
  placeholder?: string;
  fieldType: string;
  isRequired: boolean;
  options?: Array<{ label: string; value: string }>;
  validation?: Record<string, unknown>;
  visibility?: Record<string, unknown>;
  ui?: Record<string, unknown>;
  sortOrder: number;
};

export type FormConfig = {
  locked: boolean;
  accessContext?: FormAccessContext;
  program: Program;
  form: ProgramForm;
  steps: ProgramFormStep[];
  fields: ProgramFormField[];
  levels: ProgramLevel[];
  classes: ProgramClass[];
  packages: ProgramPackage[];
  pricings?: ProgramPricing[];
  addons: ProgramAddon[];
  batches: ProgramBatch[];
  sessions: ProgramSession[];
  reviewNotes: string[];
};

export type PublicFormConfig = Omit<FormConfig, "pricings"> & {
  pricings?: ProgramPricing[];
};

export type ParentInput = {
  parentName: string;
  parentWhatsapp: string;
  parentEmail?: string;
};

export type StudentInput = {
  studentName: string;
  studentGradeRaw: string;
  studentSchool?: string;
};

export type ScheduleSelection = {
  weekNo: number;
  batchId: string;
};

export type AddonSelection = {
  addonCode: string;
  choice: string;
};

export type QuoteRequest = {
  accessToken?: string;
  parent?: Partial<ParentInput>;
  student: StudentInput;
  packageCode: string;
  schedules: ScheduleSelection[];
  addons: AddonSelection[];
  livestreamPermission?: boolean;
  policiesAccepted?: string[];
};

export type QuoteLineItem = {
  kind: "package" | "class" | "addon";
  name: string;
  qty: number;
  price: number;
  total: number;
  classId?: string;
  batchId?: string;
  weekNo?: number;
};

export type QuoteResult = {
  ok: true;
  level: ProgramLevel;
  package: ProgramPackage;
  selectedClasses: ProgramClass[];
  selectedBatches: ProgramBatch[];
  lineItems: QuoteLineItem[];
  subtotal: number;
  addonTotal: number;
  total: number;
  currency: string;
  warnings: string[];
};

export type FormErrorCode =
  | "FORM_LOCKED"
  | "FORM_CLOSED"
  | "INVALID_ACCESS"
  | "RATE_LIMITED"
  | "INVALID_FIELDS"
  | "INVALID_GRADE"
  | "INVALID_PACKAGE"
  | "INVALID_SCHEDULE"
  | "SCHEDULE_FULL"
  | "INVALID_ADDON"
  | "INVOICE_FAILED"
  | "SERVER_ERROR";

export type FormError = {
  ok: false;
  code: FormErrorCode;
  message: string;
  fieldErrors?: Record<string, string>;
  availability?: AvailabilityItem[];
};

export type AvailabilityItem = ProgramBatch & {
  className: string;
  classSlug: string;
  softwareKey: string;
  levelId: string;
  sessionCount: number;
  firstSessionAt: string;
  lastSessionAt: string;
  availableSlots: number;
  isSelectable: boolean;
  disabledReason?: string;
};

export type SubmitRequest = QuoteRequest & {
  parent: ParentInput;
  policyAgreement: boolean;
};

export type InvoiceReference = {
  invoiceId: string;
  invoiceNumber: string;
  paymentLink: string;
  shortPaymentLink?: string | null;
  status: string;
  expiredAt: string;
};

export type SubmitSuccess = {
  ok: true;
  registrationId: string;
  externalReference: string;
  status: RegistrationStatus;
  invoice: InvoiceReference;
  whatsappWarning?: string;
};

export type PaymentConfirmationWhatsappContext = {
  registrationId: string;
  invoiceReferenceId?: string | null;
  invoiceId?: string | null;
  invoiceNumber?: string | null;
  paymentLink?: string | null;
  shortPaymentLink?: string | null;
  parentName: string;
  parentWhatsapp: string;
  studentName: string;
  programName: string;
  packageName?: string | null;
  levelName?: string | null;
  partnerSchoolName?: string | null;
  total: number;
  paidAt?: string | null;
  scheduleLines: string[];
  addonLines?: string[];
};

export type RegistrationPaymentContext = {
  id: string;
  externalReference: string;
  status: RegistrationStatus;
  paymentStatus: string;
  invoiceId?: string | null;
  invoiceNumber?: string | null;
  paymentLink?: string | null;
  shortPaymentLink?: string | null;
  invoiceStatus?: string | null;
};

export type AdminSnapshot = {
  program: Program;
  metrics: {
    programs: number;
    activeForms: number;
    availableBatches: number;
    registrations: number;
    waitingPayment: number;
    paid: number;
    expired: number;
    cancelled: number;
    invoiceFailed: number;
    deviceOrders: number;
    invoiceCreated: number;
    revenuePaid: number;
    revenueWaiting: number;
    urgentWarnings: number;
  };
  programs: Program[];
  levels: ProgramLevel[];
  classes: ProgramClass[];
  packages: ProgramPackage[];
  pricings: ProgramPricing[];
  addons: ProgramAddon[];
  forms: ProgramForm[];
  partnerSchools?: PartnerSchool[];
  batches: AvailabilityItem[];
  sessions: ProgramSession[];
  batchRosters: Array<{
    batchId: string;
    batchCode: string;
    batchName?: string | null;
    className: string;
    weekNo: number;
    startsAt: string;
    endsAt: string;
    timezone: string;
    scheduleLabel: string;
    quota: number;
    reservedCount: number;
    confirmedCount: number;
    availableSlots: number;
    students: Array<{
      registrationId: string;
      externalReference: string;
      studentName: string;
      parentName: string;
      parentWhatsapp?: string | null;
      levelName?: string | null;
      packageName: string;
      packageCode?: string | null;
      isBundling: boolean;
      registrationStatus: RegistrationStatus;
      paymentStatus: string;
      total: number;
      slotStatus: string;
      submittedAt?: string | null;
    }>;
  }>;
  registrations: Array<{
    id: string;
    externalReference: string;
    parentName: string;
    parentWhatsapp?: string;
    parentEmail?: string;
    studentName: string;
    studentGradeRaw?: string;
    studentGradeNormalized?: string;
    studentSchool?: string;
    levelName?: string;
    packageName: string;
    selectedClasses?: string[];
    selectedSchedules?: string[];
    addonChoices?: string[];
    sourceForm?: string;
    priceType?: string;
    partnerSchoolName?: string | null;
    partnerSchoolSlug?: string | null;
    status: RegistrationStatus;
    paymentStatus: string;
    total: number;
    livestreamPermission?: boolean | null;
    certificateStatus?: string | null;
    createdAt?: string;
    invoiceRetryable?: boolean;
    invoiceErrorMessage?: string;
    invoiceId?: string;
    invoiceNumber?: string | null;
    invoiceStatus?: string | null;
    paymentLink?: string | null;
    shortPaymentLink?: string | null;
    adminNotes?: string;
  }>;
  invoices: Array<{
    id: string;
    registrationId: string;
    invoiceId: string;
    invoiceNumber?: string | null;
    externalReference: string;
    studentName?: string | null;
    parentName?: string | null;
    total: number;
    status: string;
    paymentLink?: string | null;
    shortPaymentLink?: string | null;
    createdAt?: string | null;
    expiredAt?: string | null;
    paidAt?: string | null;
  }>;
  deviceOrders: Array<{
    id: string;
    deviceType: string;
    studentName: string;
    parentName?: string | null;
    programName?: string | null;
    className?: string | null;
    paymentStatus?: string | null;
    status: string;
    deliveredAt?: string | null;
    adminNotes?: string;
  }>;
  pitchingDayEntries: Array<{
    id: string;
    studentName: string;
    projectTitle?: string;
    status: string;
    scheduleAt?: string;
  }>;
  certificateSummary?: {
    eligible: number;
    ready: number;
    generated: number;
    sent: number;
    failed: number;
  };
  certificateTemplates?: Array<{
    id: string;
    templateKey: string;
    name: string;
    templateVersion: number;
    backgroundUrl?: string | null;
    previewImageUrl?: string | null;
    layout: Record<string, unknown>;
    isActive: boolean;
    notes?: string | null;
  }>;
  certificates: Array<{
    id: string;
    registrationId?: string | null;
    externalReference?: string | null;
    studentName?: string | null;
    parentName?: string | null;
    parentWhatsapp?: string | null;
    packageName?: string | null;
    levelName?: string | null;
    classNames?: string[];
    templateKey?: string | null;
    templateName?: string | null;
    templateVersion?: number | null;
    certificateNumber?: string | null;
    status: string;
    downloadUrl?: string | null;
    generatedAt?: string | null;
    sentAt?: string | null;
    issuedAt?: string | null;
    errorMessage?: string | null;
  }>;
  analytics: Array<{ label: string; value: number }>;
  integrationLogs: Array<{ id: string; integration: string; action: string; status: string; message: string }>;
  whatsappLogs: Array<{
    id: string;
    messageType: string;
    recipient: string;
    status: string;
    errorMessage?: string | null;
    createdAt?: string | null;
  }>;
  webhookLogs: Array<{
    id: string;
    source: string;
    eventType: string;
    externalReference?: string | null;
    signatureValid: boolean;
    processingStatus: string;
    errorMessage?: string | null;
    receivedAt: string;
  }>;
  auditLogs: Array<{
    id: string;
    adminId?: string | null;
    action: string;
    entityType: string;
    entityId?: string | null;
    reason?: string | null;
    createdAt: string;
  }>;
  reconciliationLogs: Array<{
    id: string;
    jobName: string;
    status: string;
    startedAt: string;
    finishedAt?: string | null;
    errorMessage?: string | null;
  }>;
  attendanceSummary: {
    sessions: number;
    records: number;
    present: number;
    absent: number;
  };
};
