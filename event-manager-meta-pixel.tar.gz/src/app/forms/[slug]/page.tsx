import type { Metadata } from "next";
import Script from "next/script";
import { PublicRegistrationForm } from "@/components/PublicRegistrationForm";
import { BASE_PATH } from "@/lib/constants";
import { getParams } from "@/lib/http";

const siteUrl = "https://lms.clev.io";
const formTitle = "Form Holiday Class Clevio 2026";
const formDescription = "Daftar Holiday Class Clevio 2026. Pilih paket dan jadwal kelas liburan coding anak bersama Clevio.";
const formImage = `${siteUrl}${BASE_PATH}/holiday-class-2026/holiday-logo.png`;

export async function generateMetadata({ params }: { params: { slug: string } | Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await getParams(params);
  const url = `${siteUrl}${BASE_PATH}/forms/${slug}`;

  return {
    title: formTitle,
    description: formDescription,
    alternates: {
      canonical: url
    },
    openGraph: {
      title: formTitle,
      description: formDescription,
      url,
      siteName: "Clevio",
      type: "website",
      images: [
        {
          url: formImage,
          width: 1200,
          height: 630,
          alt: "Holiday Class Clevio 2026"
        }
      ]
    },
    twitter: {
      card: "summary_large_image",
      title: formTitle,
      description: formDescription,
      images: [formImage]
    }
  };
}

export default async function FormPage({ params }: { params: { slug: string } | Promise<{ slug: string }> }) {
  const { slug } = await getParams(params);
  const isHolidayClassForm = slug.startsWith("holiday-class");

  return (
    <>
      {isHolidayClassForm ? <HolidayClassMetaPixel /> : null}
      <PublicRegistrationForm slug={slug} />
    </>
  );
}

function HolidayClassMetaPixel() {
  return (
    <>
      <Script id="meta-pixel-holiday-class" strategy="afterInteractive">
        {`
          !function(f,b,e,v,n,t,s)
          {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
          n.callMethod.apply(n,arguments):n.queue.push(arguments)};
          if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
          n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;
          s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}
          (window, document,'script','https://connect.facebook.net/en_US/fbevents.js');
          fbq('init', '710028324574763');
          fbq('track', 'PageView');
        `}
      </Script>
      <noscript>
        <img
          alt=""
          height="1"
          src="https://www.facebook.com/tr?id=710028324574763&ev=PageView&noscript=1"
          style={{ display: "none" }}
          width="1"
        />
      </noscript>
    </>
  );
}
