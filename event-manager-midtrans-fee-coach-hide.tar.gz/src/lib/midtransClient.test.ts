import { afterEach, describe, expect, it, vi } from "vitest";
import { isMidtransForm, isMidtransTestForm, mapMidtransStatus, MidtransClient } from "@/lib/midtransClient";

const originalServerKey = process.env.MIDTRANS_SERVER_KEY;
const originalProduction = process.env.MIDTRANS_IS_PRODUCTION;
const originalPublicUrl = process.env.EVENT_MANAGER_PUBLIC_URL;

afterEach(() => {
  vi.restoreAllMocks();
  restoreEnv("MIDTRANS_SERVER_KEY", originalServerKey);
  restoreEnv("MIDTRANS_IS_PRODUCTION", originalProduction);
  restoreEnv("EVENT_MANAGER_PUBLIC_URL", originalPublicUrl);
});

describe("Midtrans production integration", () => {
  it("enables Midtrans for the regular and legacy test forms", () => {
    expect(isMidtransForm("holiday-class-2026")).toBe(true);
    expect(isMidtransForm("holiday-class-2026-midtrans-sandbox")).toBe(true);
    expect(isMidtransTestForm("holiday-class-2026-midtrans-sandbox")).toBe(true);
    expect(isMidtransForm("holiday-class-partner-2026")).toBe(false);
  });

  it("only treats verified successful statuses as paid", () => {
    expect(mapMidtransStatus({ status_code: "200", transaction_status: "settlement" })).toBe("paid");
    expect(mapMidtransStatus({ status_code: "200", transaction_status: "capture", fraud_status: "accept" })).toBe("paid");
    expect(mapMidtransStatus({ status_code: "200", transaction_status: "capture", fraud_status: "challenge" })).toBe("waiting_payment");
    expect(mapMidtransStatus({ status_code: "201", transaction_status: "settlement" })).toBe("waiting_payment");
    expect(mapMidtransStatus({ transaction_status: "expire" })).toBe("expired");
  });

  it("uses the production status endpoint with server-key authentication", async () => {
    process.env.MIDTRANS_SERVER_KEY = "server-key";
    process.env.MIDTRANS_IS_PRODUCTION = "true";
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(JSON.stringify({
        status_code: "200",
        order_id: "REG-HC2026-1",
        transaction_status: "settlement",
        gross_amount: "1.00"
      }), { status: 200, headers: { "Content-Type": "application/json" } })
    );

    const result = await new MidtransClient().getTransactionStatus("REG-HC2026-1");

    expect(result.transaction_status).toBe("settlement");
    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.midtrans.com/v2/REG-HC2026-1/status",
      expect.objectContaining({
        method: "GET",
        cache: "no-store",
        headers: expect.objectContaining({
          Authorization: `Basic ${Buffer.from("server-key:").toString("base64")}`
        })
      })
    );
  });

  it("creates a GoPay Snap transaction and forces notifications to the Event Manager webhook", async () => {
    process.env.MIDTRANS_SERVER_KEY = "server-key";
    process.env.MIDTRANS_IS_PRODUCTION = "true";
    process.env.EVENT_MANAGER_PUBLIC_URL = "https://lms.clev.io/event-manager";
    const fetchMock = vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(
      new Response(JSON.stringify({
        token: "snap-token",
        redirect_url: "https://app.midtrans.com/snap/v4/redirection/snap-token"
      }), { status: 201, headers: { "Content-Type": "application/json" } })
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({
          status_code: "201",
          transaction_id: "gopay-transaction",
          order_id: "REG-HC2026-1",
          transaction_status: "pending",
          expiry_time: "2026-06-24 13:16:04",
          qr_code_url: "https://api.midtrans.com/v2/gopay/gopay-transaction/qr-code",
          deeplink_url: "https://gopay.co.id/app/merchanttransfer"
        }), { status: 200, headers: { "Content-Type": "application/json" } })
      );

    const invoice = await new MidtransClient().createInvoice({
      external_reference: "REG-HC2026-1",
      customer: { name: "Ibu Test", whatsapp: "628123456789" },
      student: { name: "Raka" },
      items: [{ name: "Midtrans Production Test - Holiday Class Clevio 2026", qty: 1, price: 1 }],
      total: 2,
      expired_at: "2026-06-25T00:00:00.000Z",
      callback_url: "https://unused.example/webhook"
    }, {
      method: "gopay",
      label: "GoPay",
      feePercent: 0,
      baseTotal: 1,
      adminFee: 1,
      total: 2,
      options: []
    });

    expect(fetchMock).toHaveBeenNthCalledWith(
      1,
      "https://app.midtrans.com/snap/v1/transactions",
      expect.objectContaining({
        headers: expect.objectContaining({
          "X-Override-Notification": "https://lms.clev.io/event-manager/api/midtrans/notification"
        }),
        body: expect.stringContaining("\"enabled_payments\":[\"gopay\"]")
      })
    );
    const requestBody = JSON.parse(String(fetchMock.mock.calls[0]?.[1]?.body));
    expect(requestBody.enabled_payments).toEqual(["gopay"]);
    expect(requestBody.item_details[0].name).toHaveLength(50);
    expect(requestBody.item_details).toContainEqual({
      id: "ADMIN-FEE",
      name: "Biaya admin pembayaran",
      quantity: 1,
      price: 1
    });
    expect(
      requestBody.item_details.reduce(
        (sum: number, item: { price: number; quantity: number }) => sum + item.price * item.quantity,
        0
      )
    ).toBe(requestBody.transaction_details.gross_amount);
    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      "https://app.midtrans.com/snap/v2/transactions/snap-token/charge",
      expect.objectContaining({
        body: JSON.stringify({ payment_type: "gopay" })
      })
    );
    expect(invoice.paymentLink).toBe("https://lms.clev.io/event-manager/payments/midtrans/pay/REG-HC2026-1");
    expect(invoice.paymentDetails?.method).toBe("gopay");
    expect(invoice.paymentDetails?.qrCodeUrl).toBe("https://api.midtrans.com/v2/gopay/gopay-transaction/qr-code");
    expect(invoice.expiredAt).toBe("2026-06-24T06:16:04.000Z");
  });

  it("does not add the admin fee twice when quote items already include it", async () => {
    process.env.MIDTRANS_SERVER_KEY = "server-key";
    process.env.MIDTRANS_IS_PRODUCTION = "true";
    const fetchMock = vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(
        new Response(JSON.stringify({
          token: "bundle-token",
          redirect_url: "https://app.midtrans.com/snap/v4/redirection/bundle-token"
        }), { status: 201, headers: { "Content-Type": "application/json" } })
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({
          status_code: "201",
          transaction_id: "bundle-transaction",
          order_id: "REG-HC2026-BUNDLE",
          transaction_status: "pending",
          expiry_time: "2026-06-25 13:16:04",
          deeplink_url: "https://gopay.co.id/app/merchanttransfer"
        }), { status: 200, headers: { "Content-Type": "application/json" } })
      );

    await new MidtransClient().createInvoice({
      external_reference: "REG-HC2026-BUNDLE",
      customer: { name: "Ibu Test", whatsapp: "628123456789" },
      student: { name: "Raka" },
      items: [
        { name: "Bundling 2 Kelas", qty: 1, price: 600000 },
        { name: "Biaya admin GoPay (0,7%)", qty: 1, price: 4200 }
      ],
      total: 604200,
      expired_at: "2026-06-25T00:00:00.000Z",
      callback_url: "https://unused.example/webhook"
    }, {
      method: "gopay",
      label: "GoPay",
      feePercent: 0.7,
      baseTotal: 600000,
      adminFee: 4200,
      total: 604200,
      options: []
    });

    const requestBody = JSON.parse(String(fetchMock.mock.calls[0]?.[1]?.body));
    expect(requestBody.item_details).toHaveLength(2);
    expect(
      requestBody.item_details.reduce(
        (sum: number, item: { price: number; quantity: number }) => sum + item.price * item.quantity,
        0
      )
    ).toBe(604200);
  });

  it("creates BNI VA instructions and keeps the public link on the Clevio invoice", async () => {
    process.env.MIDTRANS_SERVER_KEY = "server-key";
    process.env.MIDTRANS_IS_PRODUCTION = "true";
    const fetchMock = vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(
        new Response(JSON.stringify({
          token: "va-snap-token",
          redirect_url: "https://app.midtrans.com/snap/v4/redirection/va-snap-token"
        }), { status: 201, headers: { "Content-Type": "application/json" } })
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({
          status_code: "201",
          transaction_id: "bni-transaction",
          order_id: "REG-HC2026-VA-1",
          transaction_status: "pending",
          expiry_time: "2026-06-25 13:01:04",
          va_numbers: [{ bank: "bni", va_number: "8578000012345678" }]
        }), { status: 200, headers: { "Content-Type": "application/json" } })
      );

    const invoice = await new MidtransClient().createInvoice({
      external_reference: "REG-HC2026-VA-1",
      customer: { name: "Ibu Test", whatsapp: "628123456789" },
      student: { name: "Raka" },
      items: [{ name: "Midtrans Production Test", qty: 1, price: 1 }],
      total: 1,
      expired_at: "2026-06-25T00:00:00.000Z",
      callback_url: "https://unused.example/webhook"
    }, {
      method: "bni_va",
      label: "Virtual Account BNI",
      feePercent: 0,
      baseTotal: 1,
      adminFee: 0,
      total: 1,
      options: []
    });

    const requestBody = JSON.parse(String(fetchMock.mock.calls[0]?.[1]?.body));
    expect(requestBody.enabled_payments).toEqual(["bni_va"]);
    expect(requestBody.enabled_payments).not.toContain("bca_va");
    expect(JSON.parse(String(fetchMock.mock.calls[1]?.[1]?.body))).toEqual({ payment_type: "bni_va" });
    expect(invoice.paymentLink).toBe("https://lms.clev.io/event-manager/payments/midtrans/pay/REG-HC2026-VA-1");
    expect(invoice.paymentDetails?.bank).toBe("bni");
    expect(invoice.paymentDetails?.vaNumber).toBe("8578000012345678");
    expect(invoice.expiredAt).toBe("2026-06-25T06:01:04.000Z");
  });

  it.each([
    {
      method: "qris" as const,
      label: "QRIS GoPay",
      snapMethod: "gopay",
      charge: {
        qr_code_url: "https://api.midtrans.com/v2/gopay/qris-transaction/qr-code",
        deeplink_url: "https://gopay.co.id/app/merchanttransfer"
      },
      expected: { qrCodeUrl: "https://api.midtrans.com/v2/gopay/qris-transaction/qr-code" }
    },
    {
      method: "mandiri_bill" as const,
      label: "Mandiri",
      snapMethod: "echannel",
      charge: { biller_code: "70012", bill_key: "123456789012" },
      expected: { billerCode: "70012", billKey: "123456789012" }
    },
    {
      method: "bri_va" as const,
      label: "BRI",
      snapMethod: "bri_va",
      charge: { va_numbers: [{ bank: "bri", va_number: "2621500012345678" }] },
      expected: { bank: "bri", vaNumber: "2621500012345678" }
    },
    {
      method: "permata_va" as const,
      label: "Permata",
      snapMethod: "permata_va",
      charge: { permata_va_number: "8900012345678901" },
      expected: { bank: "Permata", vaNumber: "8900012345678901" }
    },
    {
      method: "cimb_va" as const,
      label: "CIMB Niaga",
      snapMethod: "other_va",
      charge: { va_numbers: [{ bank: "other", va_number: "7777012345678901" }] },
      expected: { bank: "other", vaNumber: "7777012345678901" }
    },
    {
      method: "other_va" as const,
      label: "Other Banks",
      snapMethod: "other_va",
      charge: { va_numbers: [{ bank: "other", va_number: "8877012345678901" }] },
      expected: { bank: "other", vaNumber: "8877012345678901" }
    }
  ])("maps $method to Midtrans $snapMethod and keeps its payment instructions", async ({ method, label, snapMethod, charge, expected }) => {
    process.env.MIDTRANS_SERVER_KEY = "server-key";
    process.env.MIDTRANS_IS_PRODUCTION = "true";
    const fetchMock = vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(
        new Response(JSON.stringify({
          token: `${method}-token`,
          redirect_url: `https://app.midtrans.com/snap/v4/redirection/${method}-token`
        }), { status: 201, headers: { "Content-Type": "application/json" } })
      )
      .mockResolvedValueOnce(
        new Response(JSON.stringify({
          status_code: "201",
          transaction_id: `${method}-transaction`,
          order_id: `REG-${method}`,
          transaction_status: "pending",
          expiry_time: "2026-06-25 13:01:04",
          ...charge
        }), { status: 200, headers: { "Content-Type": "application/json" } })
      );

    const invoice = await new MidtransClient().createInvoice({
      external_reference: `REG-${method}`,
      customer: { name: "Ibu Test", whatsapp: "628123456789" },
      student: { name: "Raka" },
      items: [{ name: "Holiday Class", qty: 1, price: 1 }],
      total: 1,
      expired_at: "2026-06-25T00:00:00.000Z",
      callback_url: "https://unused.example/webhook"
    }, {
      method,
      label,
      feePercent: 0,
      baseTotal: 1,
      adminFee: 0,
      total: 1,
      options: []
    });

    const snapBody = JSON.parse(String(fetchMock.mock.calls[0]?.[1]?.body));
    const chargeBody = JSON.parse(String(fetchMock.mock.calls[1]?.[1]?.body));
    expect(snapBody.enabled_payments).toEqual([snapMethod]);
    expect(chargeBody).toEqual({ payment_type: snapMethod });
    expect(invoice.paymentDetails).toEqual(expect.objectContaining({ method, label, ...expected }));
  });

  it("rejects Midtrans business errors even when the HTTP response is 200", async () => {
    process.env.MIDTRANS_SERVER_KEY = "server-key";
    process.env.MIDTRANS_IS_PRODUCTION = "true";
    vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(JSON.stringify({
        status_code: "404",
        status_message: "Transaction doesn't exist."
      }), { status: 200, headers: { "Content-Type": "application/json" } })
    );

    await expect(new MidtransClient().getTransactionStatus("missing-order")).rejects.toThrow("Transaction doesn't exist.");
  });
});

function restoreEnv(name: string, value: string | undefined) {
  if (value === undefined) {
    delete process.env[name];
    return;
  }
  process.env[name] = value;
}
