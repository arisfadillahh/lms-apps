import crypto from "node:crypto";
import type { InvoiceReference, PaymentFeeBreakdown, PaymentMethodCode } from "@/lib/types";
import type { LmsInvoicePayload } from "@/lib/lmsClient";

const PRODUCTION_FORM_SLUG = "holiday-class-2026";
const TEST_FORM_SLUG = "holiday-class-2026-midtrans-sandbox";

type MidtransSnapResponse = {
  token?: string;
  redirect_url?: string;
  error_messages?: string[];
};

type MidtransSnapChargeResponse = MidtransChargeResponse & {
  qr_code_url?: string;
  deeplink_url?: string;
  bni_va_number?: string;
  expiry_time?: string;
};

type MidtransAction = {
  name?: string;
  method?: string;
  url?: string;
};

type MidtransChargeResponse = {
  status_code?: string;
  status_message?: string;
  transaction_id?: string;
  order_id?: string;
  gross_amount?: string;
  payment_type?: string;
  transaction_status?: string;
  fraud_status?: string;
  va_numbers?: Array<{ bank?: string; va_number?: string }>;
  permata_va_number?: string;
  biller_code?: string;
  bill_key?: string;
  actions?: MidtransAction[];
  error_messages?: string[];
};

type MidtransItemDetail = {
  id: string;
  name: string;
  quantity: number;
  price: number;
};

export type MidtransNotificationPayload = {
  order_id?: string;
  status_code?: string;
  gross_amount?: string;
  signature_key?: string;
  transaction_status?: string;
  fraud_status?: string;
  transaction_id?: string;
  settlement_time?: string;
  transaction_time?: string;
};

export function isMidtransForm(slug: string) {
  return slug === PRODUCTION_FORM_SLUG || slug === TEST_FORM_SLUG;
}

export function isMidtransTestForm(slug: string) {
  return slug === TEST_FORM_SLUG;
}

export function getMidtransConfigUrls() {
  const baseUrl = getPublicBaseUrl();
  return {
    paymentNotificationUrl: `${baseUrl}/api/midtrans/notification`,
    recurringNotificationUrl: `${baseUrl}/api/midtrans/notification`,
    payAccountNotificationUrl: `${baseUrl}/api/midtrans/notification`,
    finishRedirectUrl: `${baseUrl}/payments/midtrans/finish`,
    unfinishRedirectUrl: `${baseUrl}/payments/midtrans/unfinish`,
    errorRedirectUrl: `${baseUrl}/payments/midtrans/error`
  };
}

export class MidtransClient {
  private readonly serverKey = process.env.MIDTRANS_SERVER_KEY?.trim();
  private readonly isProduction = process.env.MIDTRANS_IS_PRODUCTION === "true";

  async createInvoice(payload: LmsInvoicePayload, payment: PaymentFeeBreakdown): Promise<InvoiceReference> {
    if (!this.serverKey) {
      throw new Error("MIDTRANS_SERVER_KEY belum dikonfigurasi.");
    }

    const itemDetails = buildMidtransItemDetails(payload, payment);
    const response = await fetch(`${this.baseUrl}/snap/v1/transactions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Basic ${Buffer.from(`${this.serverKey}:`).toString("base64")}`,
        "X-Override-Notification": getMidtransConfigUrls().paymentNotificationUrl
      },
      body: JSON.stringify({
        transaction_details: {
          order_id: payload.external_reference,
          gross_amount: payload.total
        },
        customer_details: {
          first_name: payload.customer.name,
          email: payload.customer.email || undefined,
          phone: payload.customer.whatsapp
        },
        item_details: itemDetails,
        enabled_payments: [getSnapPaymentMethod(payment.method)],
        callbacks: {
          finish: getMidtransConfigUrls().finishRedirectUrl
        },
        custom_field1: payload.external_reference,
        custom_field2: payload.student.name
      })
    });

    const data = (await response.json().catch(() => ({}))) as MidtransSnapResponse;
    if (!response.ok || !data.redirect_url || !data.token) {
      const message = data.error_messages?.join(", ") || `Midtrans Snap error ${response.status}`;
      throw new Error(message);
    }

    const chargeResponse = await fetch(`${this.baseUrl}/snap/v2/transactions/${encodeURIComponent(data.token)}/charge`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "X-Source": "snap",
        "X-Source-App-Type": "redirection",
        "X-Source-Version": "2.3.0"
      },
      body: JSON.stringify({
        payment_type: getSnapPaymentMethod(payment.method)
      })
    });
    const charge = (await chargeResponse.json().catch(() => ({}))) as MidtransSnapChargeResponse;
    if (!chargeResponse.ok || !isPendingCharge(charge)) {
      const message = charge.error_messages?.join(", ") || charge.status_message || `Midtrans payment charge error ${chargeResponse.status}`;
      throw new Error(message);
    }

    const va = charge.va_numbers?.[0];
    const expiredAt = normalizeMidtransExpiry(charge.expiry_time, payload.expired_at);
    return {
      invoiceId: charge.transaction_id ? `MIDTRANS-${charge.transaction_id}` : `MIDTRANS-${data.token}`,
      invoiceNumber: payload.external_reference,
      paymentLink: getMidtransPaymentPageUrl(payload.external_reference),
      shortPaymentLink: null,
      status: "waiting_payment",
      expiredAt,
      paymentMethod: payment.method,
      paymentMethodLabel: payment.label,
      paymentDetails: {
        method: payment.method,
        label: payment.label,
        baseAmount: payment.baseTotal,
        adminFee: payment.adminFee,
        feePercent: payment.feePercent,
        total: payment.total,
        qrCodeUrl: charge.qr_code_url ?? charge.actions?.find((action) => action.name === "generate-qr-code")?.url ?? null,
        deeplinkUrl: charge.deeplink_url ?? charge.actions?.find((action) => action.name === "deeplink-redirect")?.url ?? null,
        bank: va?.bank ?? getPaymentBankLabel(payment.method),
        vaNumber: va?.va_number ?? charge.bni_va_number ?? charge.permata_va_number ?? null,
        billerCode: charge.biller_code ?? null,
        billKey: charge.bill_key ?? null
      }
    };
  }

  async createDirectInvoice(payload: LmsInvoicePayload, payment: PaymentFeeBreakdown): Promise<InvoiceReference> {
    if (!this.serverKey) {
      throw new Error("MIDTRANS_SERVER_KEY belum dikonfigurasi.");
    }

    const method = payment.method;
    const itemDetails = buildMidtransItemDetails(payload, payment);
    const directPayment = getDirectPaymentRequest(method, payload);
    const response = await fetch(`${this.coreBaseUrl}/v2/charge`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Basic ${Buffer.from(`${this.serverKey}:`).toString("base64")}`,
        "X-Override-Notification": getMidtransConfigUrls().paymentNotificationUrl
      },
      body: JSON.stringify({
        payment_type: directPayment.paymentType,
        transaction_details: {
          order_id: payload.external_reference,
          gross_amount: payload.total
        },
        customer_details: {
          first_name: payload.customer.name,
          email: payload.customer.email || undefined,
          phone: payload.customer.whatsapp
        },
        item_details: itemDetails,
        ...directPayment.parameters,
        custom_field1: payload.external_reference,
        custom_field2: payload.student.name
      })
    });

    const data = (await response.json().catch(() => ({}))) as MidtransChargeResponse;
    if (!response.ok || !isPendingCharge(data)) {
      const message = data.error_messages?.join(", ") || data.status_message || `Midtrans charge error ${response.status}`;
      throw new Error(message);
    }

    const actionQr = data.actions?.find((action) => action.name === "generate-qr-code")?.url ?? null;
    const actionDeeplink = data.actions?.find((action) => action.name === "deeplink-redirect")?.url ?? null;
    const va = data.va_numbers?.[0];
    const paymentLink = getMidtransPaymentPageUrl(payload.external_reference);

    return {
      invoiceId: data.transaction_id ? `MIDTRANS-${data.transaction_id}` : `MIDTRANS-${payload.external_reference}`,
      invoiceNumber: payload.external_reference,
      paymentLink,
      shortPaymentLink: null,
      status: "waiting_payment",
      expiredAt: payload.expired_at,
      paymentMethod: method,
      paymentMethodLabel: payment.label,
      paymentDetails: {
        method,
        label: payment.label,
        baseAmount: payment.baseTotal,
        adminFee: payment.adminFee,
        feePercent: payment.feePercent,
        total: payment.total,
        qrCodeUrl: actionQr,
        deeplinkUrl: actionDeeplink,
        bank: va?.bank ?? getPaymentBankLabel(method),
        vaNumber: va?.va_number ?? data.permata_va_number ?? null,
        billerCode: data.biller_code ?? null,
        billKey: data.bill_key ?? null
      }
    };
  }

  async getTransactionStatus(orderId: string): Promise<MidtransNotificationPayload> {
    if (!this.serverKey) {
      throw new Error("MIDTRANS_SERVER_KEY belum dikonfigurasi.");
    }

    const response = await fetch(`${this.coreBaseUrl}/v2/${encodeURIComponent(orderId)}/status`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: `Basic ${Buffer.from(`${this.serverKey}:`).toString("base64")}`
      },
      cache: "no-store"
    });
    const data = (await response.json().catch(() => ({}))) as MidtransNotificationPayload & {
      status_message?: string;
      error_messages?: string[];
    };
    if (!response.ok || String(data.status_code ?? "") !== "200") {
      const message = data.error_messages?.join(", ") || data.status_message || `Midtrans status error ${response.status}`;
      throw new Error(message);
    }
    return data;
  }

  get baseUrl() {
    return this.isProduction ? "https://app.midtrans.com" : "https://app.sandbox.midtrans.com";
  }

  get coreBaseUrl() {
    return this.isProduction ? "https://api.midtrans.com" : "https://api.sandbox.midtrans.com";
  }
}

export function verifyMidtransSignature(payload: MidtransNotificationPayload) {
  const serverKey = process.env.MIDTRANS_SERVER_KEY?.trim();
  if (!serverKey) return false;

  const source = `${payload.order_id ?? ""}${payload.status_code ?? ""}${payload.gross_amount ?? ""}${serverKey}`;
  const expected = crypto.createHash("sha512").update(source).digest("hex");
  return safeEqual(expected, String(payload.signature_key ?? ""));
}

export function mapMidtransStatus(payload: MidtransNotificationPayload) {
  const status = String(payload.transaction_status ?? "").toLowerCase();
  const fraudStatus = String(payload.fraud_status ?? "").toLowerCase();
  const successfulStatusCode = String(payload.status_code ?? "") === "200";

  if (successfulStatusCode && status === "settlement") return "paid";
  if (successfulStatusCode && status === "capture" && fraudStatus === "accept") return "paid";
  if (status === "expire") return "expired";
  if (["cancel", "deny", "failure"].includes(status)) return "cancelled";
  return "waiting_payment";
}

export function getMidtransPaidAt(payload: MidtransNotificationPayload) {
  return payload.settlement_time || payload.transaction_time || new Date().toISOString();
}

function getPublicBaseUrl() {
  return (process.env.EVENT_MANAGER_PUBLIC_URL || "https://lms.clev.io/event-manager").replace(/\/+$/, "");
}

export function getMidtransPaymentPageUrl(externalReference: string) {
  return `${getPublicBaseUrl()}/payments/midtrans/pay/${encodeURIComponent(externalReference)}`;
}

function getMidtransVaBank() {
  return (process.env.MIDTRANS_VA_BANK || "bca").trim().toLowerCase();
}

function getSnapPaymentMethod(method: PaymentMethodCode) {
  switch (method) {
    case "gopay":
    case "qris":
      return "gopay";
    case "mandiri_bill":
      return "echannel";
    case "bri_va":
      return "bri_va";
    case "permata_va":
      return "permata_va";
    case "cimb_va":
    case "other_va":
      return "other_va";
    case "bca_va":
      return "bca_va";
    case "bni_va":
    default:
      return "bni_va";
  }
}

function getDirectPaymentRequest(method: PaymentMethodCode, payload: LmsInvoicePayload) {
  if (method === "gopay" || method === "qris") {
    return {
      paymentType: "gopay",
      parameters: {
        gopay: {
          enable_callback: true,
          callback_url: getMidtransConfigUrls().finishRedirectUrl
        }
      }
    };
  }

  if (method === "mandiri_bill") {
    return {
      paymentType: "echannel",
      parameters: {
        echannel: {
          bill_info1: "Pembayaran untuk:",
          bill_info2: payload.external_reference
        }
      }
    };
  }

  return {
    paymentType: "bank_transfer",
    parameters: {
      bank_transfer: {
        bank: getCoreBank(method)
      }
    }
  };
}

function getCoreBank(method: PaymentMethodCode) {
  switch (method) {
    case "bri_va":
      return "bri";
    case "permata_va":
      return "permata";
    case "cimb_va":
      return "cimb";
    case "bca_va":
      return "bca";
    case "other_va":
      return getMidtransVaBank();
    case "bni_va":
    default:
      return "bni";
  }
}

function getPaymentBankLabel(method: PaymentMethodCode) {
  switch (method) {
    case "mandiri_bill":
      return "Mandiri";
    case "bri_va":
      return "BRI";
    case "permata_va":
      return "Permata";
    case "cimb_va":
      return "CIMB Niaga";
    case "other_va":
      return "Other Banks";
    case "bca_va":
      return "BCA";
    case "bni_va":
      return "BNI";
    default:
      return null;
  }
}

function buildMidtransItemDetails(payload: LmsInvoicePayload, payment: PaymentFeeBreakdown): MidtransItemDetail[] {
  const items = payload.items
    .filter((item) => Number.isInteger(item.qty) && item.qty >= 1 && Number.isInteger(item.price) && item.price !== 0)
    .map((item, index) => ({
      id: `HC-${index + 1}`,
      name: normalizeMidtransItemName(item.name),
      quantity: item.qty,
      price: item.price
    }));

  const existingItemTotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  if (existingItemTotal !== payload.total && existingItemTotal + payment.adminFee === payload.total) {
    items.push({
      id: "ADMIN-FEE",
      name: "Biaya admin pembayaran",
      quantity: 1,
      price: payment.adminFee
    });
  }

  const itemTotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  if (itemTotal !== payload.total) {
    throw new Error(`Total item Midtrans (${itemTotal}) tidak sama dengan total pembayaran (${payload.total}).`);
  }

  return items;
}

function normalizeMidtransItemName(value: string) {
  const normalized = value.trim() || "Holiday Class Clevio";
  return Array.from(normalized).slice(0, 50).join("");
}

function normalizeMidtransExpiry(value: string | undefined, fallback: string) {
  if (!value) return fallback;
  const normalized = value.includes("T") ? value : `${value.replace(" ", "T")}+07:00`;
  const timestamp = new Date(normalized);
  return Number.isNaN(timestamp.getTime()) ? fallback : timestamp.toISOString();
}

function isPendingCharge(data: MidtransChargeResponse) {
  const status = String(data.transaction_status ?? "").toLowerCase();
  return data.status_code === "201" || status === "pending";
}

function safeEqual(left: string, right: string) {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}
