create table if not exists registration_sequences (
  program_id uuid primary key references programs(id) on delete cascade,
  last_number integer not null default 0,
  updated_at timestamptz not null default now()
);

insert into registration_sequences (program_id, last_number)
select
  r.program_id,
  coalesce(max((substring(r.external_reference from '([0-9]{6})$'))::integer), 0) as last_number
from registrations r
group by r.program_id
on conflict (program_id) do update set
  last_number = greatest(registration_sequences.last_number, excluded.last_number),
  updated_at = now();
