import { NextRequest, NextResponse } from "next/server";
import { getAdminActor, requireAdminRequest } from "@/lib/adminAuth";
import { getParams } from "@/lib/http";
import { LmsClient } from "@/lib/lmsClient";
import { deleteRegistration, getRegistrationPaymentContext, recordIntegrationLog } from "@/lib/repository";

export async function DELETE(request: NextRequest, context: { params: { id: string } | Promise<{ id: string }> }) {
  const unauthorized = await requireAdminRequest(request);
  if (unauthorized) return unauthorized;

  const { id } = await getParams(context.params);
  const body = await request.json().catch(() => ({}));

  try {
    const paymentContext = await getRegistrationPaymentContext(id);
    let lmsDeleteWarning: string | null = null;

    if (paymentContext?.invoiceId) {
      const lms = new LmsClient();
      try {
        await lms.deleteInvoice(paymentContext.invoiceId);
        await recordIntegrationLog({
          integration: "lms",
          action: "invoice_delete",
          status: "success",
          message: `${paymentContext.externalReference} invoice ${paymentContext.invoiceId} deleted from LMS Core`
        });
      } catch (error) {
        lmsDeleteWarning = error instanceof Error ? error.message : "Invoice LMS gagal dihapus.";
        await recordIntegrationLog({
          integration: "lms",
          action: "invoice_delete",
          status: "failed",
          message: `${paymentContext.externalReference} invoice ${paymentContext.invoiceId} delete failed: ${lmsDeleteWarning}`
        });
      }
    }

    const result = await deleteRegistration(
      id,
      {
        reason: body.reason ? String(body.reason) : "Cleanup data testing"
      },
      await getAdminActor(request)
    );
    if (!result) return NextResponse.json({ ok: false, message: "Registrasi tidak ditemukan." }, { status: 404 });
    return NextResponse.json({ ok: true, data: result, lmsDeleteWarning });
  } catch (error) {
    return NextResponse.json({ ok: false, message: error instanceof Error ? error.message : "Registration delete failed" }, { status: 400 });
  }
}
