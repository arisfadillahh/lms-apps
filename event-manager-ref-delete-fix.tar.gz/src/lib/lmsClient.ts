import type { InvoiceReference, QuoteResult, SubmitRequest } from "@/lib/types";

const DEFAULT_LMS_TIMEOUT_MS = getPositiveNumber(process.env.LMS_API_TIMEOUT_MS, 12_000);
const LMS_WHATSAPP_TIMEOUT_MS = getPositiveNumber(process.env.LMS_WHATSAPP_TIMEOUT_MS, 45_000);
const LMS_WHATSAPP_RETRIES = getPositiveNumber(process.env.LMS_WHATSAPP_RETRIES, 1);
const LMS_INVOICE_STATUS_TIMEOUT_MS = getPositiveNumber(process.env.LMS_INVOICE_STATUS_TIMEOUT_MS, 45_000);
const LMS_INVOICE_STATUS_RETRIES = getPositiveNumber(process.env.LMS_INVOICE_STATUS_RETRIES, 1);

export type LmsInvoicePayload = {
  external_reference: string;
  customer: {
    name: string;
    whatsapp: string;
    email?: string;
  };
  student: {
    name: string;
  };
  items: Array<{
    name: string;
    qty: number;
    price: number;
  }>;
  total: number;
  expired_at: string;
  callback_url: string;
};

export type LmsCertificatePayload = {
  external_reference: string;
  student: {
    name: string;
  };
  program: {
    name: string;
    date_range?: string | null;
  };
  class_names: string[];
  level_name?: string | null;
  issued_date?: string | null;
  certificate_number?: string | null;
  template?: {
    key?: string;
    name?: string;
    version?: number;
    layout?: Record<string, unknown>;
  };
};

export type LmsCertificateResponse = {
  certificateId: string;
  certificateNumber: string;
  certificateUrl: string;
  status: string;
  templateVersion?: number | null;
};

export class LmsClient {
  private readonly baseUrl = process.env.LMS_API_BASE_URL;
  private readonly token = process.env.LMS_API_TOKEN;

  async createInvoice(payload: LmsInvoicePayload): Promise<InvoiceReference> {
    if (!this.baseUrl) {
      return {
        invoiceId: `INV-MOCK-${payload.external_reference.replace(/\D/g, "").slice(-6) || Date.now()}`,
        invoiceNumber: `INV/HC/2026/${payload.external_reference.slice(-6)}`,
        paymentLink: `https://lms.clev.io/mock-pay/${payload.external_reference}`,
        shortPaymentLink: `https://lms.clev.io/i/mock${payload.external_reference.replace(/\D/g, "").slice(-4) || "0000"}`,
        status: "waiting_payment",
        expiredAt: payload.expired_at
      };
    }

    const response = await this.request("/api/invoices", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    return {
      invoiceId: response.invoice_id,
      invoiceNumber: response.invoice_number,
      paymentLink: response.payment_link,
      shortPaymentLink: response.short_payment_link ?? response.shortPaymentLink ?? null,
      status: response.status,
      expiredAt: response.expired_at
    };
  }

  async sendWhatsAppMessage(payload: { to: string; message: string }) {
    if (!this.baseUrl) {
      return { ok: true, mocked: true };
    }

    const response = await this.request("/api/whatsapp/send", {
      method: "POST",
      body: JSON.stringify(payload)
    }, {
      timeoutMs: LMS_WHATSAPP_TIMEOUT_MS,
      retries: LMS_WHATSAPP_RETRIES,
      timeoutMessage: `LMS WhatsApp timeout setelah ${Math.round(LMS_WHATSAPP_TIMEOUT_MS / 1000)} detik`
    });
    if (response?.success === false || response?.ok === false) {
      throw new Error(cleanLmsErrorMessage(response?.error ?? response?.message, "LMS WhatsApp timeout/gagal dari LMS Core"));
    }
    return response;
  }

  async resendInvoice(invoiceId: string) {
    if (!this.baseUrl) return { ok: true, mocked: true };
    return this.request(`/api/invoices/${encodeURIComponent(invoiceId)}/resend`, {
      method: "POST"
    }, {
      timeoutMs: LMS_WHATSAPP_TIMEOUT_MS,
      retries: LMS_WHATSAPP_RETRIES,
      timeoutMessage: `LMS invoice resend timeout setelah ${Math.round(LMS_WHATSAPP_TIMEOUT_MS / 1000)} detik`
    });
  }

  async deleteInvoice(invoiceId: string) {
    if (!this.baseUrl) return { ok: true, mocked: true };
    return this.request(`/api/invoices/${encodeURIComponent(invoiceId)}`, {
      method: "DELETE"
    }, {
      timeoutMs: LMS_INVOICE_STATUS_TIMEOUT_MS,
      retries: LMS_INVOICE_STATUS_RETRIES,
      timeoutMessage: `LMS invoice delete timeout setelah ${Math.round(LMS_INVOICE_STATUS_TIMEOUT_MS / 1000)} detik`
    });
  }

  async getInvoice(invoiceId: string) {
    if (!this.baseUrl) {
      return {
        invoice_id: invoiceId,
        status: "waiting_payment"
      };
    }
    return this.request(`/api/invoices/${encodeURIComponent(invoiceId)}`, {
      method: "GET"
    }, {
      timeoutMs: LMS_INVOICE_STATUS_TIMEOUT_MS,
      retries: LMS_INVOICE_STATUS_RETRIES,
      timeoutMessage: `LMS invoice status timeout setelah ${Math.round(LMS_INVOICE_STATUS_TIMEOUT_MS / 1000)} detik`
    });
  }

  async updateInvoiceMetadata(invoiceId: string, payload: {
    parentName?: string | null;
    parentWhatsapp?: string | null;
    studentName?: string | null;
  }) {
    if (!this.baseUrl) return { ok: true, mocked: true };
    return this.request(`/api/invoices/${encodeURIComponent(invoiceId)}`, {
      method: "PATCH",
      body: JSON.stringify({
        action: "update_metadata",
        customer: {
          name: payload.parentName,
          whatsapp: payload.parentWhatsapp
        },
        student: {
          name: payload.studentName
        }
      })
    }, {
      timeoutMs: LMS_INVOICE_STATUS_TIMEOUT_MS,
      retries: LMS_INVOICE_STATUS_RETRIES,
      timeoutMessage: `LMS invoice detail timeout setelah ${Math.round(LMS_INVOICE_STATUS_TIMEOUT_MS / 1000)} detik`
    });
  }

  async markInvoicePaid(invoiceId: string, payload: {
    paidAt?: string;
    paidNotes?: string;
    reason?: string;
    externalReference?: string;
  }) {
    const paidAt = payload.paidAt ?? new Date().toISOString();
    if (!this.baseUrl) {
      return {
        ok: true,
        mocked: true,
        invoice_id: invoiceId,
        status: "paid",
        paid_at: paidAt
      };
    }
    return this.request(`/api/invoices/${encodeURIComponent(invoiceId)}/mark-paid`, {
      method: "POST",
      body: JSON.stringify({
        paid_at: paidAt,
        paid_notes: payload.paidNotes ?? payload.reason ?? "Marked paid from Event Manager",
        reason: payload.reason,
        external_reference: payload.externalReference,
        notify_event_manager: false
      })
    }, {
      timeoutMs: LMS_INVOICE_STATUS_TIMEOUT_MS,
      retries: LMS_INVOICE_STATUS_RETRIES,
      timeoutMessage: `LMS invoice status timeout setelah ${Math.round(LMS_INVOICE_STATUS_TIMEOUT_MS / 1000)} detik`
    });
  }

  async createShortLink(payload: {
    targetUrl: string;
    linkType?: string;
    entityType?: string;
    entityId?: string | null;
    metadata?: Record<string, unknown>;
  }): Promise<{ shortUrl: string; targetUrl: string }> {
    if (!payload.targetUrl) {
      throw new Error("Target URL short link kosong.");
    }
    if (!this.baseUrl) {
      return { shortUrl: payload.targetUrl, targetUrl: payload.targetUrl };
    }

    const response = await this.request("/api/short-links", {
      method: "POST",
      body: JSON.stringify({
        target_url: payload.targetUrl,
        link_type: payload.linkType ?? "invoice",
        entity_type: payload.entityType,
        entity_id: payload.entityId,
        metadata: payload.metadata
      })
    });

    return {
      shortUrl: response.short_url ?? payload.targetUrl,
      targetUrl: response.target_url ?? payload.targetUrl
    };
  }

  async generateCertificate(payload: LmsCertificatePayload): Promise<LmsCertificateResponse> {
    const fallbackNumber = payload.certificate_number ?? `CERT-${payload.external_reference.replace(/[^a-z0-9]/gi, "").slice(-8).toUpperCase() || Date.now()}`;
    if (!this.baseUrl) {
      return {
        certificateId: `CERT-MOCK-${fallbackNumber}`,
        certificateNumber: fallbackNumber,
        certificateUrl: `https://lms.clev.io/certificate/mock-${encodeURIComponent(payload.external_reference)}`,
        status: "generated",
        templateVersion: payload.template?.version ?? 1
      };
    }

    const response = await this.request("/api/certificates/generate", {
      method: "POST",
      body: JSON.stringify(payload)
    });

    return {
      certificateId: response.certificate_id,
      certificateNumber: response.certificate_number,
      certificateUrl: response.certificate_url,
      status: response.status ?? "generated",
      templateVersion: response.template_version ?? null
    };
  }

  private async request(path: string, init: RequestInit, options: { timeoutMs?: number; retries?: number; timeoutMessage?: string } = {}) {
    const timeoutMs = options.timeoutMs ?? DEFAULT_LMS_TIMEOUT_MS;
    const retries = Math.max(0, Math.floor(options.retries ?? 0));
    let lastError: unknown;

    for (let attempt = 0; attempt <= retries; attempt += 1) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);

      try {
        const response = await fetch(`${this.baseUrl}${path}`, {
          ...init,
          signal: controller.signal,
          headers: {
            "content-type": "application/json",
            authorization: this.token ? `Bearer ${this.token}` : "",
            ...(init.headers ?? {})
          }
        });

        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          throw new Error(cleanLmsErrorMessage(data?.message ?? data?.error, options.timeoutMessage ?? `LMS API failed with ${response.status}`));
        }
        return data;
      } catch (error) {
        lastError = normalizeRequestError(error, options.timeoutMessage);
        if (!isRetriableRequestError(error) || attempt >= retries) {
          throw lastError;
        }
      } finally {
        clearTimeout(timeout);
      }
    }

    throw lastError instanceof Error ? lastError : new Error("LMS API request failed");
  }
}

export function buildInvoicePayload(input: SubmitRequest, quote: QuoteResult, externalReference: string): LmsInvoicePayload {
  const expiredAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
  const callbackBase = process.env.EVENT_MANAGER_PUBLIC_URL || "https://lms.clev.io/event-manager";
  const email = input.parent.parentEmail?.trim();
  return {
    external_reference: externalReference,
    customer: {
      name: cleanDisplayText(input.parent.parentName, "Orang Tua"),
      whatsapp: input.parent.parentWhatsapp.trim(),
      ...(email ? { email } : {})
    },
    student: {
      name: cleanDisplayText(input.student.studentName, "Peserta")
    },
    items: quote.lineItems.map((item) => ({
      name: item.name,
      qty: item.qty,
      price: item.price
    })),
    total: quote.total,
    expired_at: expiredAt,
    callback_url: `${callbackBase}/webhooks/lms/invoice`
  };
}

export type EventInvoiceWhatsAppMessageInput = {
  parentName: string;
  studentName: string;
  programName: string;
  invoiceNumber: string;
  paymentLink: string;
  total: number;
  expiredAt?: string | null;
  packageName?: string;
  levelName?: string;
  scheduleLines?: string[];
  addonLines?: string[];
};

export type EventPaymentConfirmedWhatsAppMessageInput = {
  parentName: string;
  studentName: string;
  programName: string;
  total: number;
  paidAt?: string | null;
  invoiceNumber?: string | null;
  paymentLink?: string | null;
  packageName?: string | null;
  levelName?: string | null;
  scheduleLines?: string[];
  addonLines?: string[];
};

export type EventCertificateWhatsAppMessageInput = {
  parentName: string;
  studentName: string;
  programName: string;
  certificateUrl: string;
  classNames: string[];
};

export function buildEventInvoiceWhatsAppMessage(input: EventInvoiceWhatsAppMessageInput) {
  const parentName = cleanDisplayText(input.parentName, "Bapak/Ibu");
  const studentName = cleanDisplayText(input.studentName, "peserta");
  const programName = cleanDisplayText(input.programName, "program Clevio");
  const summary = [
    input.levelName ? `Level: *${input.levelName}*` : null,
    input.packageName ? `Paket: *${input.packageName}*` : null,
    `Total: *${formatCurrency(input.total)}*`,
    input.expiredAt ? `Batas bayar: _${formatDateTime(input.expiredAt)}_` : null
  ].filter((line): line is string => Boolean(line));
  const schedules = input.scheduleLines && input.scheduleLines.length > 0 ? formatNumberedLines(input.scheduleLines) : [];
  const addons = input.addonLines && input.addonLines.length > 0 ? formatNumberedLines(input.addonLines) : [];

  return [
    `Halo *${parentName}*,`,
    "",
    `Pendaftaran *${studentName}* untuk *${programName}* sudah kami terima.`,
    "",
    "*Ringkasan Pendaftaran*",
    ...summary,
    schedules.length ? "" : null,
    schedules.length ? "*Jadwal Pilihan*" : null,
    ...schedules,
    addons.length ? "" : null,
    addons.length ? "*Device*" : null,
    ...addons,
    "",
    "*Invoice*",
    `Nomor: *${input.invoiceNumber}*`,
    "Link pembayaran:",
    input.paymentLink,
    "",
    "_Setelah pembayaran terkonfirmasi, slot kelas otomatis aman._",
    "",
    "Terima kasih,",
    "*Clevio*"
  ].filter((line): line is string => line !== null).join("\n");
}

export function buildEventPaymentConfirmedWhatsAppMessage(input: EventPaymentConfirmedWhatsAppMessageInput) {
  const parentName = cleanDisplayText(input.parentName, "Bapak/Ibu");
  const studentName = cleanDisplayText(input.studentName, "peserta");
  const programName = cleanDisplayText(input.programName, "program Clevio");
  const summary = [
    "Status: *Terkonfirmasi*",
    input.levelName ? `Level: *${input.levelName}*` : null,
    input.packageName ? `Paket: *${input.packageName}*` : null,
    `Total diterima: *${formatCurrency(input.total)}*`,
    input.paidAt ? `Dibayar: _${formatDateTime(input.paidAt)}_` : null
  ].filter((line): line is string => Boolean(line));
  const schedules = input.scheduleLines && input.scheduleLines.length > 0 ? formatNumberedLines(input.scheduleLines) : [];
  const addons = input.addonLines && input.addonLines.length > 0 ? formatNumberedLines(input.addonLines) : [];

  return [
    `Halo *${parentName}*,`,
    "",
    "*Pembayaran Diterima*",
    "",
    `Pembayaran untuk pendaftaran *${studentName}* di *${programName}* sudah kami terima.`,
    "",
    "*Ringkasan*",
    ...summary,
    schedules.length ? "" : null,
    schedules.length ? "*Jadwal Kelas*" : null,
    ...schedules,
    addons.length ? "" : null,
    addons.length ? "*Device*" : null,
    ...addons,
    input.paymentLink ? "" : null,
    input.invoiceNumber ? `Invoice: *${input.invoiceNumber}*` : null,
    input.paymentLink ? "Cek status invoice/pembayaran:" : null,
    input.paymentLink ?? null,
    "",
    "_Slot kelas sudah aman. Informasi teknis kelas akan dikirim melalui WhatsApp ini._",
    "",
    "Terima kasih,",
    "*Clevio*"
  ].filter((line): line is string => line !== null).join("\n");
}

export function buildEventCertificateWhatsAppMessage(input: EventCertificateWhatsAppMessageInput) {
  const parentName = cleanDisplayText(input.parentName, "Bapak/Ibu");
  const studentName = cleanDisplayText(input.studentName, "peserta");
  const programName = cleanDisplayText(input.programName, "program Clevio");
  return [
    `Halo ${parentName},`,
    "",
    `Sertifikat ${studentName} untuk ${programName} sudah siap.`,
    input.classNames.length ? `Kelas: ${input.classNames.join(", ")}` : null,
    "",
    "Silakan buka link sertifikat berikut:",
    input.certificateUrl,
    "",
    "Terima kasih sudah mengikuti kegiatan Clevio.",
    "Clevio"
  ].filter((line): line is string => line !== null).join("\n");
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(value);
}

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  }).format(new Date(value));
}

function formatNumberedLines(lines: string[]) {
  return lines.map((line, index) => `${index + 1}. ${line}`);
}

function getPositiveNumber(value: string | undefined, fallback: number) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function cleanDisplayText(value: string | null | undefined, fallback: string) {
  const cleaned = String(value ?? "").trim().replace(/\s+/g, " ");
  return cleaned || fallback;
}

function normalizeRequestError(error: unknown, timeoutMessage?: string) {
  if (isAbortError(error)) {
    return new Error(timeoutMessage ?? "LMS API timeout");
  }
  if (error instanceof Error) {
    return new Error(cleanLmsErrorMessage(error.message, "LMS API request failed"));
  }
  return new Error("LMS API request failed");
}

function isRetriableRequestError(error: unknown) {
  return isAbortError(error) || error instanceof TypeError;
}

function isAbortError(error: unknown) {
  if (!error || typeof error !== "object") return false;
  const maybeError = error as { name?: string; message?: string };
  return maybeError.name === "AbortError" || /operation was aborted|aborted/i.test(maybeError.message ?? "");
}

function cleanLmsErrorMessage(value: unknown, fallback: string) {
  const message = String(value ?? "").trim();
  if (!message) return fallback;
  if (/operation was aborted|aborted/i.test(message)) return fallback;
  return message;
}
