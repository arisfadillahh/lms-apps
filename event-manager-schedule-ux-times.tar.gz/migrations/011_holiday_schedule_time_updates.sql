do $$
declare
  v_program uuid;
  v_target record;
  v_batch uuid;
  v_session integer;
begin
  select id into v_program from programs where slug = 'holiday-class-clevio-2026';

  if v_program is null then
    return;
  end if;

  for v_target in
    select *
    from (values
      ('arduino', 1, date '2026-06-18', date '2026-06-20', time '09:00', time '10:30', 'Coach Alsa'),
      ('vibe-coding', 2, date '2026-06-25', date '2026-06-27', time '09:00', time '10:30', 'Coach Alsa')
  ) as target(class_slug, week_no, start_date, end_date, start_time, end_time, coach_note)
  loop
    v_batch := null;

    update program_batches b
    set starts_at = ((v_target.start_date + v_target.start_time) at time zone 'Asia/Jakarta'),
        ends_at = ((v_target.end_date + v_target.end_time) at time zone 'Asia/Jakarta'),
        notes = 'Jadwal resmi Holiday Class Juni-Juli 2026. ' || v_target.coach_note || '.'
    from program_classes c
    where b.program_id = v_program
      and b.class_id = c.id
      and c.slug = v_target.class_slug
      and b.week_no = v_target.week_no
    returning b.id into v_batch;

    if v_batch is null then
      raise notice 'Holiday schedule target not found: % week %', v_target.class_slug, v_target.week_no;
      continue;
    end if;

    for v_session in 1..3 loop
      update program_sessions
      set starts_at = (((v_target.start_date + (v_session - 1)) + v_target.start_time) at time zone 'Asia/Jakarta'),
          ends_at = (((v_target.start_date + (v_session - 1)) + v_target.end_time) at time zone 'Asia/Jakarta'),
          duration_minutes = 90,
          notes = v_target.coach_note
      where batch_id = v_batch
        and session_no = v_session;
    end loop;
  end loop;
end $$;
