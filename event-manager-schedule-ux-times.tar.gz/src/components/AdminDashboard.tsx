"use client";

import Link from "next/link";
import type { CSSProperties, FormEvent } from "react";
import { useEffect, useState } from "react";
import type { LucideIcon } from "lucide-react";
import {
  Activity,
  AlertTriangle,
  Award,
  BarChart3,
  Bell,
  Boxes,
  CalendarDays,
  CheckCircle2,
  CheckSquare,
  ChevronRight,
  ClipboardList,
  Clock,
  Copy,
  CreditCard,
  DollarSign,
  Download,
  ExternalLink,
  Eye,
  FileText,
  GraduationCap,
  History,
  LayoutDashboard,
  Menu,
  MessageCircle,
  Package,
  PlugZap,
  RefreshCw,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Smartphone,
  Tags,
  Trophy,
  Users,
  X,
  XCircle
} from "lucide-react";
import { BASE_PATH, apiPath, appPath } from "@/lib/constants";
import { formatRupiah, formatScheduleRange } from "@/lib/formEngine";
import type { AdminSnapshot, AvailabilityItem } from "@/lib/types";

type BatchSavePayload = {
  batchName?: string | null;
  weekNo: number;
  quota: number;
  status: string;
  startsAt: string;
  endsAt: string;
};

type CertificateTemplateItem = NonNullable<AdminSnapshot["certificateTemplates"]>[number];
type CertificateSampleItem = AdminSnapshot["certificates"][number] | AdminSnapshot["registrations"][number] | undefined;

type AdminPageId =
  | "dashboard"
  | "program"
  | "form"
  | "registrasi"
  | "schedule"
  | "classes"
  | "pricing"
  | "addons"
  | "device"
  | "attendance"
  | "pitching"
  | "certificates"
  | "analytics"
  | "integration"
  | "whatsapp"
  | "webhooks"
  | "audit";

type AdminMutation = (label: string, path: string, init: RequestInit, busyKey?: string) => Promise<void>;

const navItems: Array<{ id: AdminPageId; route: string; label: string; icon: LucideIcon; help: string }> = [
  { id: "dashboard", route: "", label: "Dashboard", icon: LayoutDashboard, help: "Ringkasan operasional" },
  { id: "program", route: "programs", label: "Program", icon: CalendarDays, help: "Setup event" },
  { id: "form", route: "forms", label: "Form", icon: FileText, help: "Link pendaftaran" },
  { id: "registrasi", route: "registrations", label: "Registrasi", icon: Users, help: "Data peserta" },
  { id: "schedule", route: "schedules", label: "Jadwal", icon: ClipboardList, help: "Jadwal dan kuota" },
  { id: "classes", route: "classes", label: "Kelas", icon: GraduationCap, help: "Level dan software" },
  { id: "pricing", route: "pricing", label: "Harga", icon: Tags, help: "Paket dan harga" },
  { id: "addons", route: "addons", label: "Add-on", icon: Boxes, help: "Pilihan device" },
  { id: "device", route: "devices", label: "Device", icon: Smartphone, help: "Pengiriman device" },
  { id: "attendance", route: "attendance", label: "Presensi", icon: CheckSquare, help: "Presensi" },
  { id: "pitching", route: "pitching", label: "Pitching", icon: Trophy, help: "Pitching Day" },
  { id: "certificates", route: "certificates", label: "Sertifikat", icon: Award, help: "Template dan status" },
  { id: "analytics", route: "analytics", label: "Analitik", icon: BarChart3, help: "Konversi form" },
  { id: "integration", route: "integration", label: "Koneksi LMS", icon: PlugZap, help: "Status koneksi" },
  { id: "whatsapp", route: "whatsapp", label: "Log WhatsApp", icon: MessageCircle, help: "Pesan via LMS" },
  { id: "webhooks", route: "webhooks", label: "Log Webhook", icon: History, help: "Update pembayaran" },
  { id: "audit", route: "audit", label: "Log Audit", icon: ShieldCheck, help: "Jejak admin" }
];

const navGroups: Array<{ label: string; items: AdminPageId[] }> = [
  { label: "Operasional", items: ["dashboard", "registrasi", "schedule", "device", "attendance"] },
  { label: "Pengaturan Program", items: ["program", "form", "classes", "pricing", "addons"] },
  { label: "Output Event", items: ["pitching", "certificates", "analytics"] },
  { label: "Sistem", items: ["integration", "whatsapp", "webhooks", "audit"] }
];

function navPath(item: { route: string }) {
  return item.route ? appPath(`/admin/${item.route}`) : appPath("/admin");
}

const pageCopy: Record<AdminPageId, { title: string; eyebrow: string; subtitle: string }> = {
  dashboard: {
    eyebrow: "Operasional",
    title: "Dashboard",
    subtitle: "Ringkasan pendaftaran, kuota kelas, invoice, dan hal yang perlu dicek hari ini."
  },
  program: {
    eyebrow: "Setup",
    title: "Program",
    subtitle: "Atur informasi event, periode, mode kelas, kuota default, dan fitur yang dipakai."
  },
  form: {
    eyebrow: "Pendaftaran",
    title: "Form",
    subtitle: "Kelola link pendaftaran, akses form, status aktif, preview, dan performa pengisian."
  },
  registrasi: {
    eyebrow: "Peserta",
    title: "Registrasi",
    subtitle: "Lihat data peserta, paket, jadwal, status pembayaran, device, dan catatan admin."
  },
  schedule: {
    eyebrow: "Jadwal",
    title: "Jadwal & Batch",
    subtitle: "Ubah tanggal, jam, kuota, status batch, dan cek peserta di tiap jadwal."
  },
  classes: {
    eyebrow: "Kelas",
    title: "Level & Kelas",
    subtitle: "Kelola level, rentang kelas sekolah, software, kebutuhan laptop, dan device."
  },
  pricing: {
    eyebrow: "Harga",
    title: "Paket & Harga",
    subtitle: "Cek paket single/bundling dan harga yang dipakai saat peserta membuat invoice."
  },
  addons: {
    eyebrow: "Device",
    title: "Add-ons & Devices",
    subtitle: "Atur pilihan Microbit/Arduino dan biaya tambahan yang muncul sesuai kelas."
  },
  device: {
    eyebrow: "Device",
    title: "Pesanan Device",
    subtitle: "Lihat device yang perlu disiapkan untuk peserta yang sudah membayar."
  },
  attendance: {
    eyebrow: "Presensi",
    title: "Presensi",
    subtitle: "Siapkan presensi per sesi kelas dan rekap kehadiran peserta."
  },
  pitching: {
    eyebrow: "Pitching Day",
    title: "Pitching Day",
    subtitle: "Atur urutan presentasi, judul proyek, izin livestream, dan kehadiran pitching."
  },
  certificates: {
    eyebrow: "Sertifikat",
    title: "Sertifikat",
    subtitle: "Preview sertifikat, kelengkapan data peserta, dan status pengiriman sertifikat."
  },
  analytics: {
    eyebrow: "Analitik",
    title: "Analitik",
    subtitle: "Pantau kunjungan form, form terkirim, invoice dibuat, pembayaran, dan konversi."
  },
  integration: {
    eyebrow: "Koneksi LMS",
    title: "Koneksi LMS",
    subtitle: "Pantau koneksi invoice, pembayaran, WhatsApp, dan perbaiki sinkronisasi bila perlu."
  },
  whatsapp: {
    eyebrow: "WhatsApp",
    title: "Log WhatsApp",
    subtitle: "Riwayat pesan invoice, reminder, dan konfirmasi pembayaran yang dikirim ke orang tua."
  },
  webhooks: {
    eyebrow: "Pembayaran",
    title: "Log Webhook",
    subtitle: "Riwayat update pembayaran dari LMS, termasuk pembayaran diterima, expired, dan batal."
  },
  audit: {
    eyebrow: "Audit",
    title: "Log Audit",
    subtitle: "Riwayat perubahan penting seperti form, jadwal, invoice, device, dan perbaikan data."
  }
};

export function AdminDashboard({ snapshot, focusSection }: { snapshot: AdminSnapshot; focusSection?: string }) {
  const selectedPage = isPageId(focusSection) ? focusSection : "dashboard";
  const [data, setData] = useState(snapshot);
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [commandOpen, setCommandOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  useEffect(() => {
    setData(snapshot);
  }, [snapshot]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setCommandOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  async function refreshDashboard() {
    const response = await fetch(apiPath("/admin/dashboard"), { cache: "no-store" });
    const result = await response.json();
    if (result.ok) setData(result.data);
  }

  async function mutate(label: string, path: string, init: RequestInit, busyKey = label) {
    setBusy(busyKey);
    setMessage(null);
    try {
      const response = await fetch(apiPath(path), {
        ...init,
        headers: {
          "content-type": "application/json",
          ...(init.headers ?? {})
        }
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || !result.ok) throw new Error(result.message ?? "Aksi gagal diproses.");
      setMessage(`${label} berhasil.`);
      await refreshDashboard();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : `${label} gagal.`);
    } finally {
      setBusy(null);
    }
  }

  async function copyFormLink(slug: string) {
    const origin = typeof window === "undefined" ? "" : window.location.origin;
    await navigator.clipboard.writeText(`${origin}${BASE_PATH}${appPath(`/forms/${slug}`)}`);
    setMessage("Link form disalin.");
  }

  const page = pageCopy[selectedPage];

  return (
    <main className="admin-shell">
      {mobileNavOpen ? <button className="admin-nav-backdrop" aria-label="Tutup menu" onClick={() => setMobileNavOpen(false)} /> : null}
      <aside className={`admin-sidebar ${mobileNavOpen ? "open" : ""}`}>
        <Link href={appPath("/admin")} className="admin-brand">
          <span className="brand-mark">C</span>
          <span className="brand-name">
            <strong>Clevio</strong>
            <small>Event Manager</small>
          </span>
        </Link>
        <nav className="admin-nav" aria-label="Admin navigation">
          {navGroups.map((group) => (
            <div className="admin-nav-group" key={group.label}>
              <span className="admin-nav-group-label">{group.label}</span>
              {group.items.map((id) => {
                const item = navItems.find((candidate) => candidate.id === id);
                if (!item) return null;
                const count = getNavCount(item.id, data);
                return (
                  <Link
                    href={navPath(item)}
                    className={item.id === selectedPage ? "active" : ""}
                    key={item.id}
                    title={item.help}
                    onClick={() => setMobileNavOpen(false)}
                  >
                    <item.icon size={18} />
                    <span>{item.label}</span>
                    {count > 0 ? <small className="nav-count">{count}</small> : null}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>
        <div className="admin-sidebar-foot">
          <div className="admin-user-chip">
            <span className="admin-avatar">AC</span>
            <span>
              <strong>Admin Clevio</strong>
              <small>Operasional event</small>
            </span>
            <Settings size={16} />
          </div>
        </div>
      </aside>

      <section className="admin-main">
        <header className="admin-topbar page-topbar">
          <button className="icon-button menu-trigger" aria-label="Buka menu" onClick={() => setMobileNavOpen(true)}>
            <Menu size={18} />
          </button>
          <div>
            <p className="section-label">{page.eyebrow}</p>
            <h1>{page.title}</h1>
            <span>{page.subtitle}</span>
          </div>
          <div className="topbar-actions">
            <button className="admin-search-button" onClick={() => setCommandOpen(true)}>
              <Search size={16} />
              <span>Cari halaman, peserta, invoice...</span>
              <kbd>Ctrl K</kbd>
            </button>
            <button className="icon-button notification-button" aria-label="Notifikasi">
              <Bell size={18} />
              {data.metrics.urgentWarnings > 0 ? <span /> : null}
            </button>
            <Link className="ghost-button" href={appPath("/forms/holiday-class-2026")}>
              Lihat Form Customer
            </Link>
            <button
              className="secondary-action"
              title="Refresh data dashboard"
              aria-label="Refresh data dashboard"
              disabled={busy === "refresh"}
              onClick={() => {
                setBusy("refresh");
                refreshDashboard().finally(() => setBusy(null));
              }}
            >
              <RefreshCw size={18} />
              Refresh
            </button>
          </div>
        </header>

        {message ? <div className="admin-toast">{message}</div> : null}
        <CommandPalette open={commandOpen} onClose={() => setCommandOpen(false)} data={data} />

        <PageFrame>
          {renderPage({
            page: selectedPage,
            data,
            busy,
            mutate,
            copyFormLink
          })}
        </PageFrame>
      </section>
    </main>
  );
}

function renderPage({
  page,
  data,
  busy,
  mutate,
  copyFormLink
}: {
  page: AdminPageId;
  data: AdminSnapshot;
  busy: string | null;
  mutate: (label: string, path: string, init: RequestInit, busyKey?: string) => Promise<void>;
  copyFormLink: (slug: string) => Promise<void>;
}) {
  switch (page) {
    case "program":
      return <ProgramsPage data={data} busy={busy} mutate={mutate} />;
    case "form":
      return <FormsPage data={data} busy={busy} mutate={mutate} copyFormLink={copyFormLink} />;
    case "registrasi":
      return <RegistrationsPage data={data} busy={busy} mutate={mutate} />;
    case "schedule":
      return <SchedulesPage data={data} busy={busy} mutate={mutate} />;
    case "classes":
      return <ClassesPage data={data} />;
    case "pricing":
      return <PricingPage data={data} busy={busy} mutate={mutate} />;
    case "addons":
      return <AddonsPage data={data} />;
    case "device":
      return <DevicePage data={data} />;
    case "attendance":
      return <AttendancePage data={data} />;
    case "pitching":
      return <PitchingPage data={data} />;
    case "certificates":
      return <CertificatesPage data={data} busy={busy} mutate={mutate} />;
    case "analytics":
      return <AnalyticsPage data={data} />;
    case "integration":
      return <IntegrationPage data={data} busy={busy} mutate={mutate} />;
    case "whatsapp":
      return <WhatsAppPage data={data} />;
    case "webhooks":
      return <WebhooksPage data={data} />;
    case "audit":
      return <AuditPage data={data} />;
    default:
      return <DashboardPage data={data} />;
  }
}

function DashboardPage({ data }: { data: AdminSnapshot }) {
  const nextBatches = data.batches
    .filter((batch) => batch.status === "open")
    .sort((a, b) => a.availableSlots - b.availableSlots || new Date(a.startsAt).getTime() - new Date(b.startsAt).getTime())
    .slice(0, 6);
  const actions = [
    { key: "invoice", href: appPath("/admin/registrations"), count: data.metrics.invoiceFailed, label: "Invoice gagal dibuat", tone: data.metrics.invoiceFailed > 0 ? "alert" : "calm", icon: AlertTriangle },
    { key: "waiting", href: appPath("/admin/registrations"), count: data.metrics.waitingPayment, label: "Menunggu pembayaran", tone: data.metrics.waitingPayment > 0 ? "warn" : "calm", icon: Clock },
    { key: "device", href: appPath("/admin/devices"), count: data.metrics.deviceOrders, label: "Device perlu disiapkan", tone: data.metrics.deviceOrders > 0 ? "info" : "calm", icon: Smartphone },
    { key: "wa", href: appPath("/admin/whatsapp"), count: data.whatsappLogs.filter((log) => log.status === "failed").length, label: "WhatsApp gagal terkirim", tone: data.whatsappLogs.some((log) => log.status === "failed") ? "warn" : "calm", icon: MessageCircle }
  ];
  const recent = buildRecentActivity(data);
  return (
    <>
      <p className="page-intro">
        Ada <strong>{data.metrics.invoiceFailed} invoice gagal</strong>, <strong>{data.metrics.waitingPayment} keluarga</strong> menunggu pembayaran, dan <strong>{data.metrics.deviceOrders} device</strong> perlu dicek.
      </p>
      <section className="action-card-grid" aria-label="Aksi cepat">
        {actions.map((action) => (
          <Link className={`action-card ${action.tone}`} href={action.href} key={action.key}>
            <span className="action-card-icon"><action.icon size={20} /></span>
            <strong>{action.count}</strong>
            <span>{action.label}</span>
            <ChevronRight className="action-card-arrow" size={18} />
          </Link>
        ))}
      </section>

      <section className="metric-grid" aria-label="Dashboard metrics">
        <Metric label="Program" value={data.metrics.programs} tone="blue" />
        <Metric label="Form Aktif" value={data.metrics.activeForms} tone="teal" />
        <Metric label="Jadwal Tersedia" value={data.metrics.availableBatches} tone="green" />
        <Metric label="Pendaftar" value={data.metrics.registrations} tone="blue" />
        <Metric label="Menunggu Bayar" value={data.metrics.waitingPayment} tone="amber" />
        <Metric label="Sudah Bayar" value={data.metrics.paid} tone="green" />
        <Metric label="Invoice Bermasalah" value={data.metrics.invoiceFailed} tone="red" />
        <Metric label="Dana Dibayar" valueText={formatRupiah(data.metrics.revenuePaid)} tone="green" />
      </section>

      <section className="admin-grid two-col">
        <div className="admin-panel">
          <PanelHeader title="Program aktif" subtitle="Program yang sedang dipantau di dashboard." />
          <InfoBlock
            title={data.program.name}
            rows={[
              ["Mode", `${data.program.mode} via ${data.program.platform}`],
              ["Periode", `${data.program.periodStart} - ${data.program.periodEnd}`],
              ["Deadline daftar", data.program.registrationDeadlineRule ?? "Belum diset"],
              ["Kuota default", `${data.program.defaultQuotaPerBatch} peserta/batch`]
            ]}
          />
        </div>
        <div className="admin-panel">
          <PanelHeader title="Aktivitas terakhir" subtitle="Update operasional terbaru yang perlu diketahui admin." />
          <div className="compact-list">
            {recent.map((item) => (
              <div className="compact-row activity-row" key={`${item.text}-${item.time}`}>
                <span className={`activity-icon ${item.tone}`}><item.icon size={17} /></span>
                <div>
                  <strong>{item.text}</strong>
                  <span>{item.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="admin-panel">
        <PanelHeader title="Jadwal terdekat" subtitle="Batch terbuka yang paling awal berjalan." />
        <div className="quick-grid">
          {nextBatches.length ? (
            nextBatches.map((batch) => (
              <article className="quick-card" key={batch.id}>
                <strong>{batch.className}</strong>
                <span>Minggu {batch.weekNo} - {formatScheduleRange(batch)}</span>
                <footer>
                  <span>{batch.availableSlots} slot tersisa</span>
                  <span className={batch.availableSlots <= 2 ? "status-chip danger" : "status-chip success"}>{formatBatchStatus(batch.status)}</span>
                </footer>
              </article>
            ))
          ) : (
            <EmptyState icon={ClipboardList} title="Belum ada batch terbuka" />
          )}
        </div>
      </section>
    </>
  );
}

function ProgramsPage({
  data,
  busy,
  mutate
}: {
  data: AdminSnapshot;
  busy: string | null;
  mutate: (label: string, path: string, init: RequestInit, busyKey?: string) => Promise<void>;
}) {
  return (
    <>
      <section className="admin-grid two-col">
        <div className="admin-panel">
          <PanelHeader title="Daftar program" subtitle="Program/event yang tersedia di Event Manager." />
          <div className="config-list">
            {(data.programs.length ? data.programs : [data.program]).map((program) => (
              <article className="config-card" key={program.id}>
                <header>
                  <div>
                    <strong>{program.name}</strong>
                    <span>{program.description ?? "Belum ada deskripsi"}</span>
                  </div>
                  <span className="status-chip success">{program.mode}</span>
                </header>
                <div className="chip-row">
                  <span className="soft-chip">{program.periodStart} - {program.periodEnd}</span>
                  <span className="soft-chip">{program.platform}</span>
                  <span className="soft-chip">{program.defaultQuotaPerBatch} kuota/batch</span>
                </div>
              </article>
            ))}
          </div>
        </div>
        <div className="admin-panel">
          <PanelHeader title="Fitur program" subtitle="Fitur yang aktif untuk program ini." />
          <div className="feature-grid">
            {[
              ["Levels", data.program.hasLevels],
              ["Paket", data.program.hasPackages],
              ["Bundling", data.program.hasBundling],
              ["Add-ons", data.program.hasAddons],
              ["Pilih jadwal", data.program.hasScheduleSelection],
              ["Presensi", data.program.hasAttendance],
              ["Pitching Day", data.program.hasPitchingDay],
              ["Sertifikat", data.program.hasCertificates],
              ["Izin livestream", data.program.hasLivestreamPermission],
              ["WhatsApp", data.program.hasWhatsappAutomation]
            ].map(([label, enabled]) => (
              <span className={enabled ? "feature-pill on" : "feature-pill"} key={String(label)}>
                {enabled ? <CheckCircle2 size={15} /> : <XCircle size={15} />}
                {label}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="admin-panel">
        <PanelHeader title="Perbaikan data" subtitle="Jalankan saat kuota atau status pembayaran terlihat belum sesuai." />
        <div className="admin-action-row">
          <button className="secondary-action" disabled={busy === "job:release-expired"} onClick={() => mutate("Lepas slot kedaluwarsa", "/admin/jobs/release-expired-reservations", { method: "POST" }, "job:release-expired")}>
            Lepas Slot Kedaluwarsa
          </button>
          <button className="secondary-action" disabled={busy === "job:sync-invoices"} onClick={() => mutate("Sinkron status bayar", "/admin/jobs/sync-invoices", { method: "POST" }, "job:sync-invoices")}>
            Sinkron Status Bayar
          </button>
          <button className="secondary-action" disabled={busy === "job:reconcile"} onClick={() => mutate("Hitung ulang kuota", "/admin/jobs/reconcile-batch-counters", { method: "POST" }, "job:reconcile")}>
            Hitung Ulang Kuota
          </button>
        </div>
      </section>
    </>
  );
}

function FormsPage({
  data,
  busy,
  mutate,
  copyFormLink
}: {
  data: AdminSnapshot;
  busy: string | null;
  mutate: (label: string, path: string, init: RequestInit, busyKey?: string) => Promise<void>;
  copyFormLink: (slug: string) => Promise<void>;
}) {
  return (
    <section className="admin-grid two-col">
      <div className="admin-panel">
        <PanelHeader title="Link form" subtitle="Link pendaftaran yang dibagikan ke orang tua." />
        <div className="form-link-list">
          {data.forms.map((form) => (
            <div className="form-link-row" key={form.id}>
              <div>
                <strong>{form.name}</strong>
                <span>{formatAccessType(form.accessType)} - {formatPriceType(form.priceType)} - {formatFormStatus(form.status)}</span>
                <span>{form.maxSubmissions ? `Maksimal ${form.maxSubmissions} pendaftar` : "Tidak dibatasi jumlah pendaftar"}</span>
              </div>
              <div className="row-actions">
                <button className="ghost-button small" onClick={() => copyFormLink(form.slug)}>
                  Salin Link
                </button>
                <button
                  className="ghost-button small"
                  disabled={busy === `form:${form.id}`}
                  onClick={() =>
                    mutate(
                      form.status === "active" ? "Tutup form" : "Aktifkan form",
                      `/admin/forms/${form.id}`,
                      { method: "PATCH", body: JSON.stringify({ status: form.status === "active" ? "closed" : "active" }) },
                      `form:${form.id}`
                    )
                  }
                >
                  {form.status === "active" ? "Tutup" : "Aktifkan"}
                </button>
                <Link className="ghost-button small" href={appPath(`/forms/${form.slug}`)}>
                  Preview
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
      <AnalyticsPanel data={data} title="Analitik form" subtitle="Performa form dari kunjungan sampai pembayaran." />
    </section>
  );
}

function RegistrationsPage({
  data,
  busy,
  mutate
}: {
  data: AdminSnapshot;
  busy: string | null;
  mutate: (label: string, path: string, init: RequestInit, busyKey?: string) => Promise<void>;
}) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [active, setActive] = useState<AdminSnapshot["registrations"][number] | null>(null);
  const [overrideTarget, setOverrideTarget] = useState<AdminSnapshot["registrations"][number] | null>(null);
  const filters = [
    { id: "all", label: "Semua", test: () => true },
    { id: "waiting", label: "Menunggu bayar", test: (item: AdminSnapshot["registrations"][number]) => item.status === "waiting_payment" || item.paymentStatus === "waiting_payment" },
    { id: "paid", label: "Sudah bayar", test: (item: AdminSnapshot["registrations"][number]) => ["paid", "confirmed", "completed"].includes(item.status) || ["paid", "confirmed"].includes(item.paymentStatus) },
    { id: "failed", label: "Invoice gagal", test: (item: AdminSnapshot["registrations"][number]) => item.status === "invoice_failed" || item.invoiceRetryable === true },
    { id: "partner", label: "Sekolah partner", test: (item: AdminSnapshot["registrations"][number]) => item.priceType === "partner_school" || item.priceType === "alpha_omega" || Boolean(item.partnerSchoolName) },
    { id: "device", label: "Perlu device", test: (item: AdminSnapshot["registrations"][number]) => (item.addonChoices ?? []).some((choice) => /buy|beli|clevio/i.test(choice)) }
  ];
  const normalizedQuery = query.trim().toLowerCase();
  const selectedFilter = filters.find((item) => item.id === filter) ?? filters[0];
  const filtered = data.registrations.filter((item) => {
    const haystack = [
      item.externalReference,
      item.studentName,
      item.parentName,
      item.parentWhatsapp,
      item.studentSchool,
      item.partnerSchoolName,
      item.packageName,
      item.levelName,
      ...(item.selectedClasses ?? []),
      ...(item.selectedSchedules ?? [])
    ].join(" ").toLowerCase();
    return selectedFilter.test(item) && (!normalizedQuery || haystack.includes(normalizedQuery));
  });

  return (
    <>
      <section className="admin-panel">
        <PanelHeader
          title="Daftar registrasi"
          subtitle="Cari nama anak, orang tua, nomor WhatsApp, paket, atau jadwal. Klik baris untuk detail."
          actions={
            <button className="ghost-button small" onClick={() => downloadRegistrationsCsv(filtered)}>
              <Download size={14} />
              Export
            </button>
          }
        />
        <div className="table-tools">
          <label className="search-field">
            <Search size={16} />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cari nama, orang tua, WhatsApp, ID..." />
          </label>
          <span className="table-count">{filtered.length} dari {data.registrations.length} peserta</span>
        </div>
        <div className="filter-strip chip-buttons">
          {filters.map((item) => (
            <button className={filter === item.id ? "soft-chip active" : "soft-chip"} key={item.id} onClick={() => setFilter(item.id)}>
              {item.label}
              <span>{data.registrations.filter(item.test).length}</span>
            </button>
          ))}
        </div>
        {filtered.length === 0 ? (
          <EmptyState icon={Users} title="Tidak ada registrasi sesuai filter" />
        ) : (
          <>
            <div className="responsive-table desktop-registration-table">
            <table className="data-table">
            <thead>
              <tr>
                <th>Peserta</th>
                <th>Orang tua</th>
                <th>Level/Paket</th>
                <th>Jadwal</th>
                <th>Status</th>
                <th>Total</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((item) => (
                <tr key={item.id} onClick={() => setActive(item)} className="clickable-row">
                  <td>
                    <strong>{item.studentName}</strong>
                    <span>{item.studentGradeRaw ?? "-"} - {item.studentSchool ?? "Sekolah belum diisi"}</span>
                    {item.partnerSchoolName ? <span>Partner: {item.partnerSchoolName}</span> : null}
                    <span>{item.externalReference}</span>
                  </td>
                  <td>
                    <strong>{item.parentName}</strong>
                    <span>{item.parentWhatsapp ?? "-"}</span>
                  </td>
                  <td>
                    <strong>{item.levelName ?? "-"}</strong>
                    <span>{item.packageName}</span>
                  </td>
                  <td>{(item.selectedSchedules ?? []).join(", ") || "-"}</td>
                  <td><span className={item.status === "invoice_failed" ? "status-chip danger" : "status-chip"}>{formatRegistrationStatus(item.status)}</span></td>
                  <td>{formatRupiah(item.total)}</td>
                  <td onClick={(event) => event.stopPropagation()}>
                    <div className="row-actions registration-row-actions">
                      {item.invoiceRetryable ? (
                        <button className="ghost-button small" disabled={busy === `retry:${item.id}`} onClick={() => mutate("Buat ulang invoice", `/admin/registrations/${item.id}/retry-invoice`, { method: "POST" }, `retry:${item.id}`)}>
                          Buat Ulang Invoice
                        </button>
                      ) : (
                        <>
                        <ManualPaidButton registration={item} onSelect={setOverrideTarget} className="primary-action small" />
                        <InvoiceRefreshButton invoiceId={item.invoiceId} busy={busy} mutate={mutate} label="Update Status" />
                        </>
                      )}
                      <DeleteRegistrationButton registration={item} busy={busy} mutate={mutate} className="ghost-button small danger-button" />
                      <button className="ghost-button small" onClick={() => setActive(item)}>
                        <Eye size={14} />
                        Detail
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
            </div>
            <div className="mobile-registration-list" aria-label="Daftar registrasi mobile">
          {filtered.map((item) => (
            <article className="mobile-registration-card" key={`${item.id}-mobile`} onClick={() => setActive(item)}>
              <header>
                <div>
                  <strong>{item.studentName}</strong>
                  <span>{item.parentName} - {item.parentWhatsapp ?? "WhatsApp belum ada"}</span>
                </div>
                <span className={item.status === "invoice_failed" ? "status-chip danger" : "status-chip"}>{formatRegistrationStatus(item.status)}</span>
              </header>
              <div className="mobile-registration-meta">
                <span>{item.levelName ?? "-"}</span>
                <span>{item.packageName}</span>
                {item.partnerSchoolName ? <span>{item.partnerSchoolName}</span> : null}
                <span>{formatRupiah(item.total)}</span>
              </div>
              <p>{(item.selectedSchedules ?? []).join(", ") || "Jadwal belum dipilih"}</p>
              <footer>
                <small>{item.externalReference}</small>
                <div className="mobile-card-actions">
                  {item.invoiceRetryable ? (
                    <button className="ghost-button small" disabled={busy === `retry:${item.id}`} onClick={(event) => {
                      event.stopPropagation();
                      mutate("Buat ulang invoice", `/admin/registrations/${item.id}/retry-invoice`, { method: "POST" }, `retry:${item.id}`);
                    }}>
                      Buat Ulang Invoice
                    </button>
                  ) : (
                    <>
                    <ManualPaidButton registration={item} onSelect={setOverrideTarget} className="primary-action small" />
                    <InvoiceRefreshButton invoiceId={item.invoiceId} busy={busy} mutate={mutate} label="Update Status" />
                    </>
                  )}
                  <DeleteRegistrationButton registration={item} busy={busy} mutate={mutate} className="ghost-button small danger-button" />
                  <button className="ghost-button small" onClick={(event) => {
                    event.stopPropagation();
                    setActive(item);
                  }}>
                    Detail
                  </button>
                </div>
              </footer>
            </article>
          ))}
            </div>
          </>
      )}
      </section>
      {active ? <RegistrationDrawer registration={active} busy={busy} mutate={mutate} onManualPaid={setOverrideTarget} onClose={() => setActive(null)} /> : null}
      {overrideTarget ? (
        <PaymentOverrideModal
          key={overrideTarget.id}
          registration={overrideTarget}
          busy={busy}
          mutate={mutate}
          onClose={() => setOverrideTarget(null)}
          onDone={() => {
            if (active?.id === overrideTarget.id) setActive(null);
          }}
        />
      ) : null}
    </>
  );
}

function RegistrationDrawer({
  registration,
  busy,
  mutate,
  onManualPaid,
  onClose
}: {
  registration: AdminSnapshot["registrations"][number];
  busy: string | null;
  mutate: AdminMutation;
  onManualPaid: (registration: AdminSnapshot["registrations"][number]) => void;
  onClose: () => void;
}) {
  const steps = [
    { label: "Form terkirim", value: registration.createdAt ? formatDateTime(registration.createdAt) : "Tercatat", state: "done" },
    { label: "Invoice", value: registration.status === "invoice_failed" ? "Gagal dibuat" : registration.invoiceRetryable ? "Perlu dicek" : "Dibuat", state: registration.status === "invoice_failed" ? "fail" : "done" },
    { label: "Pembayaran", value: formatPaymentStatus(registration.paymentStatus), state: ["paid", "confirmed", "completed"].includes(registration.status) ? "done" : registration.status === "waiting_payment" ? "now" : "" },
    { label: "Device", value: (registration.addonChoices ?? []).length ? "Ada pilihan device" : "Tidak perlu device", state: (registration.addonChoices ?? []).length ? "now" : "" }
  ];

  return (
    <div className="drawer-scrim" onClick={onClose}>
      <aside className="detail-drawer" onClick={(event) => event.stopPropagation()} aria-label="Detail registrasi">
        <header className="drawer-head">
          <div>
            <span className="section-label">{registration.externalReference}</span>
            <h2>{registration.studentName}</h2>
            <span>{registration.parentName} - {registration.parentWhatsapp ?? "WhatsApp belum ada"}</span>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="Tutup detail">
            <X size={18} />
          </button>
        </header>
        <div className="drawer-body">
          <section className="drawer-section">
            <h3>Ringkasan</h3>
            <InfoBlock
              title={registration.packageName}
              rows={[
                ["Status", formatRegistrationStatus(registration.status)],
                ["Pembayaran", formatPaymentStatus(registration.paymentStatus)],
                ["Invoice", registration.invoiceNumber ?? registration.invoiceId ?? "-"],
                ["Status Invoice", formatInvoiceStatus(registration.invoiceStatus ?? registration.paymentStatus)],
                ["Level", registration.levelName ?? "-"],
                ["Kelas sekolah", registration.studentGradeRaw ?? "-"],
                ["Sekolah", registration.studentSchool ?? "-"],
                ["Sekolah partner", registration.partnerSchoolName ?? "-"],
                ["Total", formatRupiah(registration.total)]
              ]}
            />
          </section>
          <section className="drawer-section">
            <h3>Jadwal</h3>
            <div className="chip-row">
              {(registration.selectedSchedules ?? []).length ? registration.selectedSchedules?.map((schedule) => (
                <span className="soft-chip" key={schedule}>{schedule}</span>
              )) : <span className="muted-text">Belum ada jadwal</span>}
            </div>
          </section>
          <section className="drawer-section">
            <h3>Device/Add-on</h3>
            <div className="chip-row">
              {(registration.addonChoices ?? []).length ? registration.addonChoices?.map((choice) => (
                <span className="soft-chip" key={choice}>{choice}</span>
              )) : <span className="muted-text">Tidak ada add-on</span>}
            </div>
          </section>
          <section className="drawer-section">
            <h3>Progres</h3>
            <div className="timeline">
              {steps.map((step) => (
                <div className="timeline-item" key={step.label}>
                  <span className={`timeline-dot ${step.state}`}>{step.state === "done" ? <CheckCircle2 size={11} /> : step.state === "fail" ? <X size={11} /> : null}</span>
                  <div>
                    <strong>{step.label}</strong>
                    <span>{step.value}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>
          {registration.adminNotes ? (
            <section className="drawer-section">
              <h3>Catatan admin</h3>
              <p className="note-box">{registration.adminNotes}</p>
            </section>
          ) : null}
        </div>
        <footer className="drawer-foot">
          <ManualPaidButton registration={registration} onSelect={onManualPaid} className="primary-action" />
          {registration.invoiceRetryable ? (
            <button className="primary-action" disabled={busy === `retry:${registration.id}`} onClick={() => mutate("Buat ulang invoice", `/admin/registrations/${registration.id}/retry-invoice`, { method: "POST" }, `retry:${registration.id}`)}>
              <RefreshCw size={16} />
              Buat Ulang Invoice
            </button>
          ) : null}
          {!registration.invoiceRetryable ? (
            <InvoiceRefreshButton invoiceId={registration.invoiceId} busy={busy} mutate={mutate} label="Update Status dari LMS" className="secondary-action" />
          ) : null}
          {registration.shortPaymentLink || registration.paymentLink ? (
            <a className="ghost-button" href={registration.shortPaymentLink || registration.paymentLink || "#"} target="_blank" rel="noreferrer">
              <ExternalLink size={16} />
              Link Pembayaran
            </a>
          ) : null}
          {registration.parentWhatsapp ? (
            <a className="secondary-action" href={`https://wa.me/${registration.parentWhatsapp}`} target="_blank" rel="noreferrer">
              <MessageCircle size={16} />
              Chat WhatsApp
            </a>
          ) : null}
          <button className="ghost-button" onClick={() => downloadRegistrationsCsv([registration])}>
            <Download size={16} />
            Export Detail
          </button>
          <DeleteRegistrationButton registration={registration} busy={busy} mutate={mutate} onDeleted={onClose} className="ghost-button danger-button" />
        </footer>
      </aside>
    </div>
  );
}

function InvoiceRefreshButton({
  invoiceId,
  busy,
  mutate,
  label = "Update Status",
  className = "ghost-button small",
  onDone
}: {
  invoiceId?: string | null;
  busy: string | null;
  mutate: AdminMutation;
  label?: string;
  className?: string;
  onDone?: () => void;
}) {
  if (!invoiceId) return null;
  const busyKey = `invoice-refresh:${invoiceId}`;
  return (
    <button
      className={`invoice-refresh-action ${className}`}
      disabled={busy === busyKey}
      title="Ambil status terbaru dari LMS"
      onClick={(event) => {
        event.stopPropagation();
        mutate("Update status invoice dari LMS", `/admin/invoices/${invoiceId}/refresh`, { method: "POST" }, busyKey).then(onDone);
      }}
      type="button"
    >
      <RefreshCw size={14} />
      <span>{busy === busyKey ? "Mengupdate..." : label}</span>
    </button>
  );
}

function ManualPaidButton({
  registration,
  onSelect,
  className = "primary-action"
}: {
  registration: AdminSnapshot["registrations"][number];
  onSelect: (registration: AdminSnapshot["registrations"][number]) => void;
  className?: string;
}) {
  if (isPaymentComplete(registration)) return null;
  if (registration.status === "cancelled" || registration.status === "expired") return null;
  return (
    <button
      className={`manual-paid-action ${className}`}
      onClick={(event) => {
        event.stopPropagation();
        onSelect(registration);
      }}
      type="button"
    >
      <CheckCircle2 size={14} />
      <span>Tandai Sudah Bayar</span>
    </button>
  );
}

function DeleteRegistrationButton({
  registration,
  busy,
  mutate,
  className = "ghost-button small",
  onDeleted
}: {
  registration: AdminSnapshot["registrations"][number];
  busy: string | null;
  mutate: AdminMutation;
  className?: string;
  onDeleted?: () => void;
}) {
  const busyKey = `registration-delete:${registration.id}`;
  return (
    <button
      className={className}
      disabled={busy === busyKey}
      onClick={(event) => {
        event.stopPropagation();
        const ok = window.confirm(`Hapus data testing ${registration.studentName} (${registration.externalReference})?\n\nInvoice reference, add-on, device order, dan slot Event Manager akan ikut dibersihkan.`);
        if (!ok) return;
        mutate(
          "Hapus registrasi",
          `/admin/registrations/${registration.id}`,
          {
            method: "DELETE",
            body: JSON.stringify({ reason: "Cleanup data testing dari dashboard Event Manager" })
          },
          busyKey
        ).then(onDeleted);
      }}
      type="button"
    >
      <XCircle size={14} />
      <span>{busy === busyKey ? "Menghapus..." : "Hapus"}</span>
    </button>
  );
}

function PaymentOverrideModal({
  registration,
  busy,
  mutate,
  onClose,
  onDone
}: {
  registration: AdminSnapshot["registrations"][number];
  busy: string | null;
  mutate: AdminMutation;
  onClose: () => void;
  onDone: () => void;
}) {
  const [reason, setReason] = useState("Dikonfirmasi manual oleh admin.");
  const trimmedReason = reason.trim();
  const busyKey = `payment-override:${registration.id}`;
  const disabled = busy === busyKey;
  const finalReason = trimmedReason.length >= 5 ? trimmedReason : "Dikonfirmasi manual oleh admin.";

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (disabled) return;
    await mutate(
      "Tandai sudah bayar",
      `/admin/registrations/${registration.id}/payment-override`,
      {
        method: "POST",
        body: JSON.stringify({
          newStatus: "paid",
          reason: finalReason
        })
      },
      busyKey
    );
    onDone();
    onClose();
  }

  return (
    <div className="payment-override-scrim" onClick={onClose}>
      <form className="payment-override-modal" onSubmit={submit} onClick={(event) => event.stopPropagation()}>
        <header>
          <span className="section-label">Manual override</span>
          <h2>Tandai Sudah Bayar?</h2>
          <p>
            Status {registration.studentName} akan menjadi <strong>Sudah Bayar</strong>, slot kelas dikonfirmasi,
            dan WhatsApp konfirmasi pembayaran dikirim.
          </p>
        </header>
        <InfoBlock
          title={registration.externalReference}
          rows={[
            ["Peserta", registration.studentName],
            ["Orang tua", registration.parentName],
            ["Status sekarang", formatPaymentStatus(registration.paymentStatus)],
            ["Total", formatRupiah(registration.total)]
          ]}
        />
        <label className="override-reason-field">
          <span>Alasan admin *</span>
          <textarea
            value={reason}
            onChange={(event) => setReason(event.target.value)}
            placeholder="Dikonfirmasi manual oleh admin."
            rows={4}
          />
          <small>Alasan ini masuk audit log. Boleh diganti kalau ada detail transfer.</small>
        </label>
        <footer>
          <button className="ghost-button" type="button" onClick={onClose}>
            Batal
          </button>
          <button className="primary-action" disabled={disabled} type="submit">
            <CheckCircle2 size={16} />
            {busy === busyKey ? "Menyimpan..." : "Tandai Sudah Bayar"}
          </button>
        </footer>
      </form>
    </div>
  );
}

function isPaymentComplete(registration: AdminSnapshot["registrations"][number]) {
  return ["paid", "confirmed", "completed"].includes(registration.status) || ["paid", "confirmed"].includes(registration.paymentStatus);
}

function InvoicesPage({
  data,
  busy,
  mutate
}: {
  data: AdminSnapshot;
  busy: string | null;
  mutate: (label: string, path: string, init: RequestInit, busyKey?: string) => Promise<void>;
}) {
  const [filter, setFilter] = useState("all");
  const invoiceFilters = [
    { id: "all", label: "Semua", test: () => true },
    { id: "waiting_payment", label: "Menunggu bayar", test: (item: AdminSnapshot["invoices"][number]) => item.status === "waiting_payment" || item.status === "pending" },
    { id: "paid", label: "Lunas", test: (item: AdminSnapshot["invoices"][number]) => item.status === "paid" },
    { id: "failed", label: "Gagal", test: (item: AdminSnapshot["invoices"][number]) => ["failed", "invoice_failed"].includes(item.status) },
    { id: "expired", label: "Expired/Batal", test: (item: AdminSnapshot["invoices"][number]) => ["expired", "cancelled"].includes(item.status) }
  ];
  const selected = invoiceFilters.find((item) => item.id === filter) ?? invoiceFilters[0];
  const invoices = data.invoices.filter(selected.test);

  return (
    <>
      <section className="metric-grid">
        <Metric label="Invoice Dibuat" value={data.metrics.invoiceCreated} tone="blue" />
        <Metric label="Menunggu Bayar" value={data.metrics.waitingPayment} tone="amber" />
        <Metric label="Sudah Bayar" value={data.metrics.paid} tone="green" />
        <Metric label="Kedaluwarsa/Batal" value={data.metrics.expired + data.metrics.cancelled} tone="red" />
        <Metric label="Dana Dibayar" valueText={formatRupiah(data.metrics.revenuePaid)} tone="green" />
        <Metric label="Dana Menunggu" valueText={formatRupiah(data.metrics.revenueWaiting)} tone="amber" />
      </section>
      <section className="admin-panel">
        <PanelHeader
          title="Invoice & pembayaran"
          subtitle="Update status dari LMS, buka link pembayaran, atau kirim ulang invoice ke WhatsApp."
          actions={
            <button className="ghost-button small" disabled={busy === "job:sync-invoices"} onClick={() => mutate("Sinkron invoice menunggu", "/admin/jobs/sync-invoices", { method: "POST" }, "job:sync-invoices")}>
              <RefreshCw size={14} />
              Sinkron Semua
            </button>
          }
        />
        <div className="filter-strip chip-buttons">
          {invoiceFilters.map((item) => (
            <button className={filter === item.id ? "soft-chip active" : "soft-chip"} key={item.id} onClick={() => setFilter(item.id)}>
              {item.label}
              <span>{data.invoices.filter(item.test).length}</span>
            </button>
          ))}
        </div>
        {invoices.length === 0 ? (
          <EmptyState icon={CreditCard} title="Belum ada invoice" />
        ) : (
          <div className="compact-list">
            {invoices.map((item) => (
              <div className="compact-row" key={item.id}>
                <span className="lr-icon"><CreditCard size={18} /></span>
                <div>
                  <strong>{item.invoiceNumber ?? item.invoiceId}</strong>
                  <span>{item.studentName ?? "-"} - {item.externalReference}</span>
                  {item.shortPaymentLink || item.paymentLink ? <a href={item.shortPaymentLink || item.paymentLink || "#"} target="_blank" rel="noreferrer">Buka link pembayaran</a> : null}
                </div>
                <span className={invoiceStatusClass(item.status)}>{formatInvoiceStatus(item.status)}</span>
                <strong>{formatRupiah(item.total)}</strong>
                <div className="row-actions">
                  <InvoiceRefreshButton invoiceId={item.invoiceId} busy={busy} mutate={mutate} label="Update Status dari LMS" />
                  <button className="ghost-button small" disabled={busy === `invoice-resend:${item.invoiceId}`} onClick={() => mutate("Kirim ulang invoice", `/admin/invoices/${item.invoiceId}/resend`, { method: "POST" }, `invoice-resend:${item.invoiceId}`)}>
                    <Send size={14} />
                    Kirim WA
                  </button>
                  {item.shortPaymentLink || item.paymentLink ? (
                    <a className="ghost-button small" href={item.shortPaymentLink || item.paymentLink || "#"} target="_blank" rel="noreferrer" aria-label="Buka link pembayaran">
                      <ExternalLink size={14} />
                    </a>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </>
  );
}

function SchedulesPage({
  data,
  busy,
  mutate
}: {
  data: AdminSnapshot;
  busy: string | null;
  mutate: (label: string, path: string, init: RequestInit, busyKey?: string) => Promise<void>;
}) {
  const firstRosterId = data.batchRosters.find((roster) => roster.students.length > 0)?.batchId ?? data.batchRosters[0]?.batchId ?? data.batches[0]?.id ?? "";
  const [selectedBatchId, setSelectedBatchId] = useState(firstRosterId);

  useEffect(() => {
    if (!selectedBatchId || !data.batchRosters.some((roster) => roster.batchId === selectedBatchId)) {
      setSelectedBatchId(firstRosterId);
    }
  }, [data.batchRosters, firstRosterId, selectedBatchId]);

  const selectedBatch = data.batches.find((batch) => batch.id === selectedBatchId) ?? data.batches[0];
  const selectedRoster = data.batchRosters.find((roster) => roster.batchId === selectedBatch?.id);

  return (
    <div className="schedule-ops-page">
      <section className="admin-panel schedule-step-panel">
        <PanelHeader
          title="1. Pilih jadwal"
          subtitle="Klik salah satu jadwal untuk melihat daftar anak dan mengubah jadwal tersebut."
          actions={selectedBatch ? (
            <div className="selected-schedule-pill">
              <CalendarDays size={15} />
              <span>{selectedBatch.className}</span>
              <strong>Minggu {selectedBatch.weekNo}</strong>
            </div>
          ) : null}
        />
        <ScheduleMatrix data={data} selectedBatchId={selectedBatchId} onSelect={setSelectedBatchId} />
      </section>

      <BatchRosterPanel data={data} selectedBatchId={selectedBatchId} onSelect={setSelectedBatchId} />

      <section className="schedule-management-grid">
        <SelectedBatchEditorPanel
          batch={selectedBatch}
          busy={selectedBatch ? busy === `batch:${selectedBatch.id}` : false}
          roster={selectedRoster}
          onSave={(payload) => {
            if (!selectedBatch) return;
            return mutate("Simpan jadwal", `/admin/batches/${selectedBatch.id}`, { method: "PATCH", body: JSON.stringify(payload) }, `batch:${selectedBatch.id}`);
          }}
        />
        <CreateBatchPanel data={data} busy={busy === "batch:create"} mutate={mutate} />
      </section>
    </div>
  );
}

function ClassesPage({ data }: { data: AdminSnapshot }) {
  return (
    <section className="admin-panel">
      <PanelHeader title="Level & kelas" subtitle="Level menentukan kelas yang muncul saat orang tua memilih kelas anak." />
      <div className="config-list roomy">
        {data.levels.map((level) => (
          <article className="config-card" key={level.id}>
            <header>
              <div>
                <strong>{level.name}</strong>
                <span>{level.gradeLabel}</span>
              </div>
              <span className={level.isActive === false ? "status-chip" : "status-chip success"}>{level.isActive === false ? "Nonaktif" : "Aktif"}</span>
            </header>
            <div className="class-grid">
              {data.classes.filter((klass) => klass.levelId === level.id).map((klass) => (
                <article className="class-card" key={klass.id}>
                  <strong>{klass.name}</strong>
                  <span>{klass.description ?? "Belum ada deskripsi"}</span>
                  <small>{klass.requirements ?? "Kebutuhan kelas belum diisi"}</small>
                  {klass.requiresDevice ? <span className="status-chip">Perlu pilihan device</span> : null}
                </article>
              ))}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

function SelectedBatchEditorPanel({
  batch,
  roster,
  busy,
  onSave
}: {
  batch?: AvailabilityItem;
  roster?: AdminSnapshot["batchRosters"][number];
  busy: boolean;
  onSave: (payload: BatchSavePayload) => void;
}) {
  const [batchName, setBatchName] = useState(batch?.batchName ?? "");
  const [weekNo, setWeekNo] = useState(batch?.weekNo ?? 1);
  const [startDate, setStartDate] = useState(batch ? toDateInput(batch.startsAt, batch.timezone) : "");
  const [startTime, setStartTime] = useState(batch ? toTimeInput(batch.startsAt, batch.timezone) : "");
  const [endDate, setEndDate] = useState(batch ? toDateInput(batch.endsAt, batch.timezone) : "");
  const [endTime, setEndTime] = useState(batch ? toTimeInput(batch.endsAt, batch.timezone) : "");
  const [quota, setQuota] = useState(batch?.quota ?? 0);
  const [status, setStatus] = useState(batch?.status ?? "open");
  const paidCount = roster?.students.filter((student) => ["paid", "confirmed", "completed"].includes(student.paymentStatus) || ["paid", "confirmed", "completed"].includes(student.registrationStatus)).length ?? 0;
  const waitingCount = roster?.students.filter((student) => ["pending_invoice", "waiting_payment"].includes(student.paymentStatus) || ["pending_invoice", "waiting_payment"].includes(student.registrationStatus)).length ?? 0;
  const canSave = Boolean(batch && startDate && startTime && endDate && endTime && weekNo > 0 && quota >= 0);

  useEffect(() => {
    setBatchName(batch?.batchName ?? "");
    setWeekNo(batch?.weekNo ?? 1);
    setStartDate(batch ? toDateInput(batch.startsAt, batch.timezone) : "");
    setStartTime(batch ? toTimeInput(batch.startsAt, batch.timezone) : "");
    setEndDate(batch ? toDateInput(batch.endsAt, batch.timezone) : "");
    setEndTime(batch ? toTimeInput(batch.endsAt, batch.timezone) : "");
    setQuota(batch?.quota ?? 0);
    setStatus(batch?.status ?? "open");
  }, [batch]);

  return (
    <section className="admin-panel selected-batch-editor">
      <PanelHeader
        title="3. Ubah jadwal terpilih"
        subtitle={batch ? "Edit nama, minggu, tanggal, jam, kuota, dan status untuk jadwal yang sedang dipilih." : "Pilih jadwal dulu dari bagian atas."}
        actions={batch ? <span className={status === "open" ? "status-chip success" : "status-chip"}>{formatBatchStatus(status)}</span> : null}
      />
      {!batch ? (
        <EmptyState icon={CalendarDays} title="Belum ada jadwal dipilih" hint="Klik kartu jadwal di bagian atas untuk membuka editor." />
      ) : (
        <>
          <div className="selected-batch-summary">
            <div>
              <span>Kelas</span>
              <strong>{batch.className}</strong>
            </div>
            <div>
              <span>Peserta daftar</span>
              <strong>{roster?.students.length ?? 0}</strong>
            </div>
            <div>
              <span>Sudah bayar</span>
              <strong>{paidCount}</strong>
            </div>
            <div>
              <span>Menunggu bayar</span>
              <strong>{waitingCount}</strong>
            </div>
          </div>
          <div className="admin-form-grid selected-batch-form-grid">
            <label>
              <span>Nama batch</span>
              <input value={batchName} onChange={(event) => setBatchName(event.target.value)} placeholder={batch.batchCode} />
            </label>
            <label>
              <span>Minggu</span>
              <input min={1} type="number" value={weekNo} onChange={(event) => setWeekNo(Number(event.target.value))} />
            </label>
            <label>
              <span>Kuota</span>
              <input min={0} type="number" value={quota} onChange={(event) => setQuota(Number(event.target.value))} />
            </label>
            <label>
              <span>Status</span>
              <select value={status} onChange={(event) => setStatus(event.target.value)}>
                <option value="open">Dibuka</option>
                <option value="closed">Ditutup</option>
                <option value="full">Penuh</option>
              </select>
            </label>
            <label>
              <span>Tanggal mulai</span>
              <input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} />
            </label>
            <label>
              <span>Jam mulai</span>
              <input type="time" value={startTime} onChange={(event) => setStartTime(event.target.value)} />
            </label>
            <label>
              <span>Tanggal selesai</span>
              <input type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} />
            </label>
            <label>
              <span>Jam selesai</span>
              <input type="time" value={endTime} onChange={(event) => setEndTime(event.target.value)} />
            </label>
          </div>
          <div className="admin-create-footer">
            <span>{formatAdminScheduleRange(batch)} - {batch.quota} kuota awal, {batch.availableSlots} slot tersedia</span>
            <button
              className="primary-action small"
              disabled={busy || !canSave}
              onClick={() => onSave({
                batchName: batchName.trim() || null,
                weekNo,
                quota,
                status,
                startsAt: composeJakartaDateTime(startDate, startTime),
                endsAt: composeJakartaDateTime(endDate, endTime)
              })}
              type="button"
            >
              {busy ? "Menyimpan..." : "Simpan Perubahan"}
            </button>
          </div>
        </>
      )}
    </section>
  );
}

function CreateBatchPanel({
  data,
  busy,
  mutate
}: {
  data: AdminSnapshot;
  busy: boolean;
  mutate: AdminMutation;
}) {
  const firstClass = data.classes[0];
  const [classId, setClassId] = useState(firstClass?.id ?? "");
  const [batchName, setBatchName] = useState("");
  const [weekNo, setWeekNo] = useState(1);
  const [startDate, setStartDate] = useState("2026-06-15");
  const [startTime, setStartTime] = useState("10:00");
  const [endTime, setEndTime] = useState("11:30");
  const [sessionCount, setSessionCount] = useState(3);
  const [quota, setQuota] = useState(data.program.defaultQuotaPerBatch || 10);
  const [status, setStatus] = useState("open");

  useEffect(() => {
    if (!classId && firstClass?.id) setClassId(firstClass.id);
  }, [classId, firstClass?.id]);

  const selectedClass = data.classes.find((klass) => klass.id === classId);
  const endDate = addDaysToDateInput(startDate, Math.max(1, sessionCount) - 1);
  const canCreate = Boolean(classId && startDate && startTime && endTime && sessionCount > 0 && quota >= 0);

  return (
    <div className="admin-create-card">
      <PanelHeader title="Tambah jadwal baru" subtitle="Buat batch baru tanpa ubah database manual. Sistem otomatis membuat sesi berurutan sesuai jumlah hari." />
      <div className="admin-form-grid schedule-create-grid">
        <label>
          <span>Kelas</span>
          <select value={classId} onChange={(event) => setClassId(event.target.value)}>
            {data.levels.map((level) => (
              <optgroup key={level.id} label={level.name}>
                {data.classes.filter((klass) => klass.levelId === level.id).map((klass) => (
                  <option key={klass.id} value={klass.id}>{klass.name}</option>
                ))}
              </optgroup>
            ))}
          </select>
        </label>
        <label>
          <span>Nama batch</span>
          <input value={batchName} onChange={(event) => setBatchName(event.target.value)} placeholder={selectedClass ? `${selectedClass.name} Week ${weekNo}` : "Nama jadwal"} />
        </label>
        <label>
          <span>Minggu</span>
          <input min={1} type="number" value={weekNo} onChange={(event) => setWeekNo(Number(event.target.value))} />
        </label>
        <label>
          <span>Tanggal mulai</span>
          <input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} />
        </label>
        <label>
          <span>Jam mulai</span>
          <input type="time" value={startTime} onChange={(event) => setStartTime(event.target.value)} />
        </label>
        <label>
          <span>Jam selesai</span>
          <input type="time" value={endTime} onChange={(event) => setEndTime(event.target.value)} />
        </label>
        <label>
          <span>Jumlah sesi/hari</span>
          <input min={1} max={14} type="number" value={sessionCount} onChange={(event) => setSessionCount(Number(event.target.value))} />
        </label>
        <label>
          <span>Kuota</span>
          <input min={0} type="number" value={quota} onChange={(event) => setQuota(Number(event.target.value))} />
        </label>
        <label>
          <span>Status</span>
          <select value={status} onChange={(event) => setStatus(event.target.value)}>
            <option value="open">Dibuka</option>
            <option value="closed">Ditutup</option>
            <option value="full">Penuh</option>
          </select>
        </label>
      </div>
      <div className="admin-create-footer">
        <span>{selectedClass?.name ?? "Kelas"} - {sessionCount || 0} sesi, {startDate} s/d {endDate}</span>
        <button
          className="primary-action small"
          disabled={busy || !canCreate}
          onClick={() =>
            mutate(
              "Tambah jadwal",
              "/admin/batches",
              {
                method: "POST",
                body: JSON.stringify({
                  programId: data.program.id,
                  classId,
                  batchName: batchName.trim() || undefined,
                  weekNo,
                  startsAt: composeJakartaDateTime(startDate, startTime),
                  endsAt: composeJakartaDateTime(endDate, endTime),
                  sessionCount,
                  quota,
                  status,
                  meetingPlatform: data.program.platform || "Zoom"
                })
              },
              "batch:create"
            )
          }
        >
          Tambah Jadwal
        </button>
      </div>
    </div>
  );
}

function PricingPage({ data, busy, mutate }: { data: AdminSnapshot; busy: string | null; mutate: AdminMutation }) {
  return (
    <section className="admin-grid two-col">
      <div className="admin-panel">
        <PanelHeader title="Paket" subtitle="Paket yang tersedia untuk peserta saat daftar." />
        <CreatePackageForm data={data} busy={busy === "package:create"} mutate={mutate} />
        <div className="config-list">
          {data.packages.map((pkg) => (
            <PackageEditorCard key={pkg.id} pkg={pkg} busy={busy === `package:${pkg.id}`} mutate={mutate} />
          ))}
        </div>
      </div>
      <div className="admin-panel">
        <PanelHeader title="Tabel harga" subtitle="Harga yang dipakai saat peserta membuat invoice." />
        <CreatePricingForm data={data} busy={busy === "pricing:create"} mutate={mutate} />
        <div className="price-list">
          {data.pricings.map((pricing) => {
            const level = data.levels.find((item) => item.id === pricing.levelId);
            const pkg = data.packages.find((item) => item.id === pricing.packageId);
            return <PricingEditorRow key={pricing.id} busy={busy === `pricing:${pricing.id}`} levelName={level?.name ?? "Level"} mutate={mutate} pkgName={pkg?.name ?? "Paket"} pricing={pricing} />;
          })}
        </div>
      </div>
    </section>
  );
}

function CreatePackageForm({ data, busy, mutate }: { data: AdminSnapshot; busy: boolean; mutate: AdminMutation }) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [description, setDescription] = useState("");
  const [maxClasses, setMaxClasses] = useState(1);
  const [oneClassPerWeek, setOneClassPerWeek] = useState(false);
  const canSubmit = Boolean(name.trim() && code.trim() && maxClasses > 0);

  return (
    <div className="admin-create-card compact-create">
      <strong>Tambah paket</strong>
      <div className="admin-form-grid package-create-grid">
        <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Nama paket" />
        <input value={code} onChange={(event) => setCode(event.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ""))} placeholder="kode-paket" />
        <input value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Deskripsi singkat" />
        <input min={1} type="number" value={maxClasses} onChange={(event) => setMaxClasses(Number(event.target.value))} />
      </div>
      <label className="inline-check">
        <input checked={oneClassPerWeek} type="checkbox" onChange={(event) => setOneClassPerWeek(event.target.checked)} />
        1 kelas per minggu
      </label>
      <button
        className="primary-action small"
        disabled={busy || !canSubmit}
        onClick={() =>
          mutate(
            "Tambah paket",
            "/admin/packages",
            {
              method: "POST",
              body: JSON.stringify({
                programId: data.program.id,
                code,
                name,
                description,
                minClasses: maxClasses,
                maxClasses,
                requiredWeekCount: maxClasses,
                oneClassPerWeek,
                sameLevelOnly: true,
                uniqueClassRequired: true,
                uniqueSoftwareRequired: true,
                allowCustomSelection: true
              })
            },
            "package:create"
          )
        }
      >
        Tambah Paket
      </button>
    </div>
  );
}

function PackageEditorCard({ pkg, busy, mutate }: { pkg: AdminSnapshot["packages"][number]; busy: boolean; mutate: AdminMutation }) {
  const [name, setName] = useState(pkg.name);
  const [description, setDescription] = useState(pkg.description);
  const [minClasses, setMinClasses] = useState(pkg.minClasses);
  const [maxClasses, setMaxClasses] = useState(pkg.maxClasses);
  const [requiredWeekCount, setRequiredWeekCount] = useState(pkg.requiredWeekCount ?? pkg.maxClasses);
  const [oneClassPerWeek, setOneClassPerWeek] = useState(pkg.oneClassPerWeek);
  const [sameLevelOnly, setSameLevelOnly] = useState(pkg.sameLevelOnly);
  const [uniqueClassRequired, setUniqueClassRequired] = useState(pkg.uniqueClassRequired);
  const [allowCustomSelection, setAllowCustomSelection] = useState(pkg.allowCustomSelection !== false);

  useEffect(() => {
    setName(pkg.name);
    setDescription(pkg.description);
    setMinClasses(pkg.minClasses);
    setMaxClasses(pkg.maxClasses);
    setRequiredWeekCount(pkg.requiredWeekCount ?? pkg.maxClasses);
    setOneClassPerWeek(pkg.oneClassPerWeek);
    setSameLevelOnly(pkg.sameLevelOnly);
    setUniqueClassRequired(pkg.uniqueClassRequired);
    setAllowCustomSelection(pkg.allowCustomSelection !== false);
  }, [pkg]);

  return (
    <article className="config-card package-editor-card">
      <header>
        <div>
          <input value={name} onChange={(event) => setName(event.target.value)} />
          <textarea value={description} onChange={(event) => setDescription(event.target.value)} />
        </div>
        <span className="status-chip">{minClasses}-{maxClasses} kelas</span>
      </header>
      <div className="admin-form-grid mini-grid">
        <label>
          <span>Min</span>
          <input min={1} type="number" value={minClasses} onChange={(event) => setMinClasses(Number(event.target.value))} />
        </label>
        <label>
          <span>Max</span>
          <input min={1} type="number" value={maxClasses} onChange={(event) => setMaxClasses(Number(event.target.value))} />
        </label>
        <label>
          <span>Minggu</span>
          <input min={1} type="number" value={requiredWeekCount ?? ""} onChange={(event) => setRequiredWeekCount(Number(event.target.value))} />
        </label>
      </div>
      <div className="check-grid">
        <label><input checked={oneClassPerWeek} type="checkbox" onChange={(event) => setOneClassPerWeek(event.target.checked)} />1 kelas/minggu</label>
        <label><input checked={sameLevelOnly} type="checkbox" onChange={(event) => setSameLevelOnly(event.target.checked)} />Level sama</label>
        <label><input checked={uniqueClassRequired} type="checkbox" onChange={(event) => setUniqueClassRequired(event.target.checked)} />Kelas unik</label>
        <label><input checked={allowCustomSelection} type="checkbox" onChange={(event) => setAllowCustomSelection(event.target.checked)} />Urutan bebas</label>
      </div>
      <button
        className="ghost-button small"
        disabled={busy}
        onClick={() =>
          mutate(
            "Simpan paket",
            `/admin/packages/${pkg.id}`,
            {
              method: "PATCH",
              body: JSON.stringify({
                name,
                description,
                minClasses,
                maxClasses,
                requiredWeekCount,
                oneClassPerWeek,
                sameLevelOnly,
                uniqueClassRequired,
                uniqueSoftwareRequired: uniqueClassRequired,
                allowCustomSelection
              })
            },
            `package:${pkg.id}`
          )
        }
      >
        Simpan Paket
      </button>
    </article>
  );
}

function CreatePricingForm({ data, busy, mutate }: { data: AdminSnapshot; busy: boolean; mutate: AdminMutation }) {
  const [priceType, setPriceType] = useState("normal");
  const [levelId, setLevelId] = useState(data.levels[0]?.id ?? "");
  const [packageId, setPackageId] = useState(data.packages[0]?.id ?? "");
  const [price, setPrice] = useState(0);
  const canSubmit = Boolean(levelId && packageId && price >= 0);

  return (
    <div className="admin-create-card compact-create">
      <strong>Tambah / ubah harga</strong>
      <div className="admin-form-grid pricing-create-grid">
        <select value={priceType} onChange={(event) => setPriceType(event.target.value)}>
          <option value="normal">Harga Normal</option>
          <option value="partner_school">Harga Sekolah Partner</option>
        </select>
        <select value={levelId} onChange={(event) => setLevelId(event.target.value)}>
          {data.levels.map((level) => <option key={level.id} value={level.id}>{level.name}</option>)}
        </select>
        <select value={packageId} onChange={(event) => setPackageId(event.target.value)}>
          {data.packages.map((pkg) => <option key={pkg.id} value={pkg.id}>{pkg.name}</option>)}
        </select>
        <input min={0} type="number" value={price} onChange={(event) => setPrice(Number(event.target.value))} placeholder="Harga" />
      </div>
      <button
        className="primary-action small"
        disabled={busy || !canSubmit}
        onClick={() =>
          mutate(
            "Simpan harga",
            "/admin/pricings",
            {
              method: "POST",
              body: JSON.stringify({
                programId: data.program.id,
                priceType,
                levelId,
                packageId,
                price
              })
            },
            "pricing:create"
          )
        }
      >
        Simpan Harga
      </button>
    </div>
  );
}

function PricingEditorRow({
  pricing,
  levelName,
  pkgName,
  busy,
  mutate
}: {
  pricing: AdminSnapshot["pricings"][number];
  levelName: string;
  pkgName: string;
  busy: boolean;
  mutate: AdminMutation;
}) {
  const [price, setPrice] = useState(pricing.price);

  useEffect(() => {
    setPrice(pricing.price);
  }, [pricing.price]);

  return (
    <span className="pricing-edit-row">
      <em>{levelName} - {pkgName} - {formatPriceType(pricing.priceType)}</em>
      <input min={0} type="number" value={price} onChange={(event) => setPrice(Number(event.target.value))} />
      <strong>{formatRupiah(price)}</strong>
      <button className="ghost-button small" disabled={busy} onClick={() => mutate("Simpan harga", `/admin/pricings/${pricing.id}`, { method: "PATCH", body: JSON.stringify({ price }) }, `pricing:${pricing.id}`)}>
        Simpan
      </button>
    </span>
  );
}

function AddonsPage({ data }: { data: AdminSnapshot }) {
  return (
    <section className="admin-panel">
      <PanelHeader title="Aturan add-on" subtitle="Pilihan device yang tersedia sesuai kelas yang dipilih peserta." />
      <div className="ops-grid three-col">
        {data.addons.map((addon) => {
          const klass = data.classes.find((item) => item.id === addon.appliesToClassId);
          return (
            <InfoBlock
              key={addon.id}
              title={addon.name}
              rows={[
                ["Kelas", klass?.name ?? "-"],
                ["Harga", formatRupiah(addon.price)],
                ["Pilihan", addon.selectionType],
                ["Wajib pilih", yesNo(addon.isRequiredChoice)],
                ["Status", addon.isActive === false ? "Nonaktif" : "Aktif"]
              ]}
            />
          );
        })}
      </div>
    </section>
  );
}

function DevicePage({ data }: { data: AdminSnapshot }) {
  return (
    <section className="admin-panel">
      <PanelHeader title="Device perlu diproses" subtitle="Hanya menampilkan device dari registrasi yang sudah dibayar." />
      {data.deviceOrders.length === 0 ? (
        <EmptyState icon={Package} title="Belum ada pesanan device aktif" />
      ) : (
        <div className="compact-list">
          {data.deviceOrders.map((item) => (
            <div className="compact-row" key={item.id}>
              <div>
                <strong>{item.deviceType}</strong>
                <span>{item.studentName} - {item.parentName ?? "Orang tua belum tercatat"}</span>
                <span>{item.className ?? item.programName ?? "Program"}</span>
                {item.adminNotes ? <span>Catatan: {item.adminNotes}</span> : null}
              </div>
              <span className="status-chip">{formatDeviceStatus(item.status)}</span>
              <span>{formatPaymentStatus(item.paymentStatus ?? "-")}</span>
              <span>{item.deliveredAt ? `Diberikan ${formatDateTime(item.deliveredAt)}` : "Belum diberikan"}</span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function AttendancePage({ data }: { data: AdminSnapshot }) {
  return (
    <section className="admin-grid two-col">
      <div className="admin-panel">
        <PanelHeader title="Alur presensi" subtitle="Langkah yang dipakai admin/coach saat mencatat kehadiran." />
        <div className="workflow-list">
          {["Pilih batch", "Pilih sesi", "Tandai hadir/terlambat/tidak hadir/izin", "Tambah catatan", "Export presensi"].map((item, index) => (
            <div className="workflow-step" key={item}>
              <span>{index + 1}</span>
              <strong>{item}</strong>
            </div>
          ))}
        </div>
      </div>
      <div className="admin-panel">
        <PanelHeader title="Rekap presensi" subtitle="Ringkasan data presensi yang sudah tercatat." />
        <InfoBlock
          title="Ringkasan"
          rows={[
            ["Sesi dibuat", `${data.attendanceSummary.sessions}`],
            ["Data presensi", `${data.attendanceSummary.records}`],
            ["Hadir", `${data.attendanceSummary.present}`],
            ["Tidak hadir", `${data.attendanceSummary.absent}`]
          ]}
        />
      </div>
    </section>
  );
}

function PitchingPage({ data }: { data: AdminSnapshot }) {
  return (
    <section className="admin-panel">
      <PanelHeader title="Pitching Day" subtitle="Holiday Class: Sabtu, 4 Juli 2026. Sekitar 5 menit per anak." />
      <div className="ops-grid three-col">
        <InfoBlock title="Aturan acara" rows={[["Platform", "Zoom, Instagram, YouTube"], ["Orang tua", "Boleh menonton"], ["Rekaman", "Rekaman YouTube tersedia"], ["Tanpa livestream", "Anak presentasi di Zoom tapi tidak tampil di livestream"]]} />
        <InfoBlock title="Data pitching" rows={[["Urutan", "Nomor tampil peserta"], ["Proyek", "Judul dan link proyek"], ["Kehadiran", "Hadir/terlambat/tidak hadir/izin"], ["Catatan", "Catatan admin"]]} />
        <InfoBlock title="Peserta pitching" rows={[["Total peserta", `${data.pitchingDayEntries.length}`], ["Sudah dijadwalkan", `${data.pitchingDayEntries.filter((item) => item.scheduleAt).length}`], ["Belum isi proyek", `${data.pitchingDayEntries.filter((item) => !item.projectTitle).length}`]]} />
      </div>
      {data.pitchingDayEntries.length ? (
        <div className="compact-list top-gap">
          {data.pitchingDayEntries.map((item) => (
            <div className="compact-row" key={item.id}>
              <div>
                <strong>{item.studentName}</strong>
                <span>{item.projectTitle ?? "Judul proyek belum diisi"}</span>
              </div>
              <span className="status-chip">{item.status}</span>
              <span>{item.scheduleAt ?? "Belum dijadwalkan"}</span>
            </div>
          ))}
        </div>
      ) : null}
    </section>
  );
}

function CertificatesPage({ data, busy, mutate }: { data: AdminSnapshot; busy: string | null; mutate: AdminMutation }) {
  const template = data.certificateTemplates?.find((item) => item.isActive) ?? data.certificateTemplates?.[0];
  const sample: CertificateSampleItem = data.certificates[0] ?? data.registrations.find((item) => ["paid", "confirmed", "completed"].includes(item.status)) ?? data.registrations[0];
  const sampleClasses = getCertificateSampleClasses(sample);
  const summary = data.certificateSummary ?? {
    eligible: data.registrations.filter((item) => ["paid", "confirmed", "completed"].includes(item.status)).length,
    ready: data.certificates.filter((item) => item.status === "ready").length,
    generated: data.certificates.filter((item) => item.status === "generated").length,
    sent: data.certificates.filter((item) => item.status === "sent").length,
    failed: data.certificates.filter((item) => item.status === "failed").length
  };
  const [templateForm, setTemplateForm] = useState(() => buildCertificateTemplateForm(template));
  const sendableCount = data.certificates.filter((item) => item.status === "generated" || (item.status === "failed" && item.downloadUrl)).length;

  useEffect(() => {
    setTemplateForm(buildCertificateTemplateForm(template));
  }, [template?.id, template?.templateVersion]);

  function updateTemplateField(key: keyof typeof templateForm, value: string) {
    setTemplateForm((current) => ({ ...current, [key]: value }));
  }

  function saveTemplate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    mutate(
      "Simpan template sertifikat",
      "/admin/certificates",
      {
        method: "POST",
        body: JSON.stringify({
          action: "save_template",
          programId: data.program.id,
          ...templateForm
        })
      },
      "cert:template"
    );
  }

  return (
    <section className="certificate-page">
      <div className="certificate-hero admin-panel">
        <div>
          <p className="section-label">Flow akhir event</p>
          <h2>Sertifikat dikirim serempak setelah Pitching Day</h2>
          <p>
            Admin cek data peserta dulu, generate semua sertifikat, preview sample, lalu kirim semua via WhatsApp saat acara selesai.
          </p>
        </div>
        <div className="certificate-actions">
          <button
            className="secondary-action"
            disabled={busy === "cert:prepare"}
            onClick={() => mutate("Cek peserta siap sertifikat", "/admin/certificates", { method: "POST", body: JSON.stringify({ action: "prepare", programId: data.program.id }) }, "cert:prepare")}
          >
            <ShieldCheck size={16} />
            {busy === "cert:prepare" ? "Mengecek..." : "Cek Peserta Siap"}
          </button>
          <button
            className="primary-action"
            disabled={busy === "cert:generate" || summary.ready === 0}
            onClick={() => mutate("Generate sertifikat", "/admin/certificates", { method: "POST", body: JSON.stringify({ action: "generate", programId: data.program.id }) }, "cert:generate")}
          >
            <Award size={16} />
            {busy === "cert:generate" ? "Generate..." : "Generate Semua"}
          </button>
          <button
            className="secondary-action"
            disabled={busy === "cert:send" || sendableCount === 0}
            onClick={() => mutate("Kirim sertifikat via WhatsApp", "/admin/certificates", { method: "POST", body: JSON.stringify({ action: "send", programId: data.program.id }) }, "cert:send")}
          >
            <Send size={16} />
            {busy === "cert:send" ? "Mengirim..." : "Kirim Semua WA"}
          </button>
        </div>
      </div>

      <section className="metric-grid certificate-metrics">
        <Metric label="Eligible" value={summary.eligible} tone="blue" />
        <Metric label="Siap Generate" value={summary.ready} tone="teal" />
        <Metric label="Sudah Jadi" value={summary.generated} tone="green" />
        <Metric label="Terkirim" value={summary.sent} tone="green" />
        <Metric label="Perlu Dicek" value={summary.failed} tone="amber" />
      </section>

      <section className="admin-grid two-col">
      <div className="admin-panel">
        <PanelHeader title="Preview sample" subtitle="Sample tampilan dari template aktif dan data peserta." />
        <div className="certificate-preview" style={{
          borderColor: templateForm.primaryColor || undefined,
          backgroundImage: templateForm.backgroundUrl
            ? `linear-gradient(rgba(255,255,255,.86), rgba(255,255,255,.9)), url("${templateForm.backgroundUrl}")`
            : undefined
        }}>
          <span style={{ color: templateForm.primaryColor || undefined }}>{templateForm.name || "Clevio"}</span>
          <h2>Sertifikat Penyelesaian</h2>
          <p>Diberikan kepada</p>
          <strong style={{ color: templateForm.primaryColor || undefined }}>{sample?.studentName ?? "Nama Peserta"}</strong>
          <p>atas partisipasi di {data.program.name}</p>
          <div className="chip-row center">
            {(sampleClasses.length ? sampleClasses : ["Nama kelas"]).slice(0, 3).map((item) => (
              <span className="soft-chip" key={item}>{item}</span>
            ))}
          </div>
          <footer>
            <span>No. Sertifikat {("certificateNumber" in (sample ?? {}) ? (sample as { certificateNumber?: string | null }).certificateNumber : null) ?? "HC-2026-XXXX"}</span>
            <span>{templateForm.signatureName || "Clevio"}</span>
          </footer>
        </div>
      </div>

      <div className="admin-panel">
        <PanelHeader title="Custom tampilan" subtitle="Edit ringan untuk template. Desain background bisa dari Canva/Figma lalu pakai URL asset." />
        <form className="certificate-template-form" onSubmit={saveTemplate}>
          <label>
            <span>Nama template</span>
            <input value={templateForm.name} onChange={(event) => updateTemplateField("name", event.target.value)} placeholder="Template Holiday Class 2026" />
          </label>
          <label>
            <span>URL background</span>
            <input value={templateForm.backgroundUrl} onChange={(event) => updateTemplateField("backgroundUrl", event.target.value)} placeholder="https://..." />
          </label>
          <div className="form-split">
            <label>
              <span>Warna utama</span>
              <input value={templateForm.primaryColor} onChange={(event) => updateTemplateField("primaryColor", event.target.value)} placeholder="#057BE3" />
            </label>
            <label>
              <span>Warna aksen</span>
              <input value={templateForm.accentColor} onChange={(event) => updateTemplateField("accentColor", event.target.value)} placeholder="#F2B929" />
            </label>
          </div>
          <label>
            <span>URL logo</span>
            <input value={templateForm.logoUrl} onChange={(event) => updateTemplateField("logoUrl", event.target.value)} placeholder="https://..." />
          </label>
          <label>
            <span>Nama tanda tangan</span>
            <input value={templateForm.signatureName} onChange={(event) => updateTemplateField("signatureName", event.target.value)} placeholder="Clevio Innovation Camp" />
          </label>
          <label>
            <span>Catatan admin</span>
            <textarea value={templateForm.notes} onChange={(event) => updateTemplateField("notes", event.target.value)} placeholder="Contoh: kirim setelah Pitching Day selesai." />
          </label>
          <button className="primary-action full" disabled={busy === "cert:template"} type="submit">
            {busy === "cert:template" ? "Menyimpan..." : "Simpan Template"}
          </button>
        </form>
      </div>

      <div className="admin-panel wide-panel">
        <PanelHeader title="Status peserta" subtitle="Gunakan tabel ini untuk cek siapa yang sudah siap, sudah jadi, sudah terkirim, atau perlu retry." />
        {data.certificates.length === 0 ? (
          <EmptyState icon={Award} title="Belum ada antrean sertifikat" hint="Klik Cek Peserta Siap setelah pembayaran peserta sudah confirmed." />
        ) : (
          <div className="compact-list certificate-list">
            {data.certificates.map((item) => (
              <div className="compact-row" key={item.id}>
                <div>
                  <strong>{item.studentName ?? "Peserta"}</strong>
                  <span>{[item.levelName, item.packageName, item.classNames?.join(", ")].filter(Boolean).join(" - ") || "Data kelas belum lengkap"}</span>
                  {item.errorMessage ? <small className="error-line">{item.errorMessage}</small> : null}
                </div>
                <span className={`status-chip ${certificateStatusTone(item.status)}`}>{certificateStatusLabel(item.status)}</span>
                <span>{item.certificateNumber ?? "Belum ada nomor"}</span>
                {item.downloadUrl ? <a className="ghost-button small" href={item.downloadUrl} target="_blank" rel="noreferrer"><ExternalLink size={14} />Buka</a> : <span>Belum ada link</span>}
              </div>
            ))}
          </div>
        )}
      </div>
      </section>
    </section>
  );
}

function buildCertificateTemplateForm(template?: CertificateTemplateItem) {
  const layout = template?.layout ?? {};
  return {
    name: template?.name ?? "Template Sertifikat Clevio",
    backgroundUrl: readLayoutString(layout, "backgroundUrl") ?? template?.backgroundUrl ?? "",
    previewImageUrl: template?.previewImageUrl ?? "",
    primaryColor: readLayoutString(layout, "primaryColor") ?? "#057BE3",
    accentColor: readLayoutString(layout, "accentColor") ?? "#F2B929",
    logoUrl: readLayoutString(layout, "logoUrl") ?? "",
    signatureName: readLayoutString(layout, "signatureName") ?? "Clevio",
    notes: template?.notes ?? ""
  };
}

function getCertificateSampleClasses(sample: CertificateSampleItem) {
  if (!sample) return [];
  if ("classNames" in sample && Array.isArray(sample.classNames)) return sample.classNames;
  if ("selectedClasses" in sample && Array.isArray(sample.selectedClasses)) return sample.selectedClasses;
  return [];
}

function readLayoutString(layout: Record<string, unknown>, key: string) {
  const value = layout[key];
  return typeof value === "string" ? value : null;
}

function certificateStatusLabel(status: string) {
  const labels: Record<string, string> = {
    pending: "Belum siap",
    ready: "Siap generate",
    generated: "Sudah jadi",
    sent: "Terkirim",
    failed: "Perlu dicek"
  };
  return labels[status] ?? status;
}

function certificateStatusTone(status: string) {
  if (status === "sent" || status === "generated") return "success";
  if (status === "failed") return "danger";
  if (status === "ready") return "warn";
  return "";
}

function AnalyticsPage({ data }: { data: AdminSnapshot }) {
  const submitted = data.analytics.find((item) => item.label === "Submitted")?.value ?? 0;
  const paid = data.analytics.find((item) => item.label === "Paid")?.value ?? 0;
  const conversion = submitted ? Math.round((paid / submitted) * 100) : 0;
  return (
    <>
      <section className="metric-grid">
        <Metric label="Kunjungan" value={data.analytics.find((item) => item.label === "Visits")?.value ?? 0} tone="blue" />
        <Metric label="Mulai Isi" value={data.analytics.find((item) => item.label === "Started")?.value ?? 0} tone="teal" />
        <Metric label="Terkirim" value={submitted} tone="green" />
        <Metric label="Invoice Dibuat" value={data.analytics.find((item) => item.label === "Invoice Created")?.value ?? 0} tone="blue" />
        <Metric label="Sudah Bayar" value={paid} tone="green" />
        <Metric label="Konversi" valueText={`${conversion}%`} tone="amber" />
      </section>
      <AnalyticsPanel data={data} title="Detail funnel" subtitle="Performa pendaftaran dari form dibuka sampai pembayaran diterima." />
    </>
  );
}

function IntegrationPage({
  data,
  busy,
  mutate
}: {
  data: AdminSnapshot;
  busy: string | null;
  mutate: (label: string, path: string, init: RequestInit, busyKey?: string) => Promise<void>;
}) {
  return (
    <>
      <section className="admin-grid two-col">
        <div className="admin-panel">
          <PanelHeader title="Status koneksi" subtitle="Koneksi yang dipakai untuk invoice, pembayaran, dan WhatsApp." />
          <div className="feature-grid">
            {["Buat invoice", "Cek status invoice", "Kirim ulang invoice", "Kirim WhatsApp", "Terima update pembayaran"].map((item) => (
              <span className="feature-pill on" key={item}><CheckCircle2 size={15} />{item}</span>
            ))}
          </div>
        </div>
        <div className="admin-panel">
          <PanelHeader title="Perbaikan sinkronisasi" subtitle="Jalankan bila status pembayaran atau kuota belum sesuai." />
          <div className="admin-action-row">
            <button className="secondary-action" disabled={busy === "job:release-expired"} onClick={() => mutate("Lepas slot kedaluwarsa", "/admin/jobs/release-expired-reservations", { method: "POST" }, "job:release-expired")}>Lepas Slot Kedaluwarsa</button>
            <button className="secondary-action" disabled={busy === "job:sync-invoices"} onClick={() => mutate("Sinkron invoice", "/admin/jobs/sync-invoices", { method: "POST" }, "job:sync-invoices")}>Sinkron Invoice</button>
            <button className="secondary-action" disabled={busy === "job:reconcile"} onClick={() => mutate("Hitung ulang kuota", "/admin/jobs/reconcile-batch-counters", { method: "POST" }, "job:reconcile")}>Hitung Ulang Kuota</button>
          </div>
        </div>
      </section>
      <LogsList logs={data.integrationLogs.map((log) => ({ id: log.id, title: log.integration, subtitle: formatIntegrationAction(log.action), status: log.status, meta: formatIntegrationMessage(log.message) }))} emptyIcon={PlugZap} emptyTitle="Belum ada log koneksi" />
    </>
  );
}

function WhatsAppPage({ data }: { data: AdminSnapshot }) {
  return (
    <LogsList
      logs={data.whatsappLogs.map((log) => ({
        id: log.id,
        title: formatWhatsappType(log.messageType),
        subtitle: log.recipient,
        status: log.status,
        meta: log.errorMessage ?? (log.createdAt ? formatDateTime(log.createdAt) : "-")
      }))}
      emptyIcon={MessageCircle}
      emptyTitle="Belum ada request WhatsApp"
    />
  );
}

function WebhooksPage({ data }: { data: AdminSnapshot }) {
  return (
    <LogsList
      logs={data.webhookLogs.map((log) => ({
        id: log.id,
        title: log.eventType,
        subtitle: log.externalReference ?? log.source,
        status: log.processingStatus,
        meta: `${log.signatureValid ? "Terverifikasi" : "Tidak valid"} - ${formatDateTime(log.receivedAt)}${log.errorMessage ? ` - ${log.errorMessage}` : ""}`
      }))}
      emptyIcon={History}
      emptyTitle="Belum ada webhook masuk"
    />
  );
}

function AuditPage({ data }: { data: AdminSnapshot }) {
  return (
    <section className="admin-grid two-col">
      <LogsList
        title="Log audit"
        logs={data.auditLogs.map((log) => ({
          id: log.id,
          title: formatAuditAction(log.action),
          subtitle: `${log.entityType}${log.entityId ? ` - ${log.entityId}` : ""}`,
          status: "processed",
          meta: `${log.adminId ?? "Sistem"} - ${formatDateTime(log.createdAt)}${log.reason ? ` - ${log.reason}` : ""}`
        }))}
        emptyIcon={ShieldCheck}
        emptyTitle="Belum ada audit log"
      />
      <LogsList
        title="Log perbaikan data"
        logs={data.reconciliationLogs.map((log) => ({
          id: log.id,
          title: formatIntegrationAction(log.jobName),
          subtitle: log.finishedAt ? `Selesai ${formatDateTime(log.finishedAt)}` : `Mulai ${formatDateTime(log.startedAt)}`,
          status: log.status,
          meta: log.errorMessage ?? "-"
        }))}
        emptyIcon={RefreshCw}
        emptyTitle="Belum ada log perbaikan data"
      />
    </section>
  );
}

function AnalyticsPanel({ data, title, subtitle }: { data: AdminSnapshot; title: string; subtitle: string }) {
  return (
    <div className="admin-panel">
      <PanelHeader title={title} subtitle={subtitle} />
      <div className="analytics-list">
        {data.analytics.map((item) => (
          <div key={item.label}>
            <span>{formatAnalyticsLabel(item.label)}</span>
            <strong>{item.value}</strong>
          </div>
        ))}
      </div>
    </div>
  );
}

function LogsList({
  logs,
  emptyIcon,
  emptyTitle,
  title = "Log aktivitas"
}: {
  logs: Array<{ id: string; title: string; subtitle: string; status: string; meta: string }>;
  emptyIcon: LucideIcon;
  emptyTitle: string;
  title?: string;
}) {
  return (
    <section className="admin-panel">
      <PanelHeader title={title} subtitle="Aktivitas terbaru tampil paling atas." />
      {logs.length === 0 ? (
        <EmptyState icon={emptyIcon} title={emptyTitle} />
      ) : (
        <div className="compact-list">
          {logs.map((log) => (
            <div className="compact-row" key={log.id}>
              <div className="log-icon">
                <Activity size={16} />
              </div>
              <div>
                <strong>{log.title}</strong>
                <span>{log.subtitle}</span>
              </div>
              <span className={log.status === "failed" || log.status === "rejected" ? "status-chip danger" : "status-chip success"}>{formatIntegrationStatus(log.status)}</span>
              <span>{log.meta}</span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function BatchRow({
  batch,
  busy,
  selected,
  onSelect,
  onSave
}: {
  batch: AvailabilityItem;
  busy: boolean;
  selected: boolean;
  onSelect: () => void;
  onSave: (payload: BatchSavePayload) => void;
}) {
  const [batchName, setBatchName] = useState(batch.batchName ?? "");
  const [weekNo, setWeekNo] = useState(batch.weekNo);
  const [startDate, setStartDate] = useState(toDateInput(batch.startsAt, batch.timezone));
  const [startTime, setStartTime] = useState(toTimeInput(batch.startsAt, batch.timezone));
  const [endDate, setEndDate] = useState(toDateInput(batch.endsAt, batch.timezone));
  const [endTime, setEndTime] = useState(toTimeInput(batch.endsAt, batch.timezone));
  const [quota, setQuota] = useState(batch.quota);
  const [status, setStatus] = useState(batch.status);
  const canSave = Boolean(startDate && startTime && endDate && endTime && weekNo > 0 && quota >= 0);

  useEffect(() => {
    setBatchName(batch.batchName ?? "");
    setWeekNo(batch.weekNo);
    setStartDate(toDateInput(batch.startsAt, batch.timezone));
    setStartTime(toTimeInput(batch.startsAt, batch.timezone));
    setEndDate(toDateInput(batch.endsAt, batch.timezone));
    setEndTime(toTimeInput(batch.endsAt, batch.timezone));
    setQuota(batch.quota);
    setStatus(batch.status);
  }, [batch.batchName, batch.weekNo, batch.startsAt, batch.endsAt, batch.timezone, batch.quota, batch.status]);

  return (
    <tr className={selected ? "clickable-row selected-row" : "clickable-row"} onClick={onSelect}>
      <td>{batch.className}</td>
      <td onClick={(event) => event.stopPropagation()}><input className="inline-input wide" value={batchName} onChange={(event) => setBatchName(event.target.value)} placeholder={batch.batchCode} /></td>
      <td onClick={(event) => event.stopPropagation()}><input className="inline-input narrow" min={1} type="number" value={weekNo} onChange={(event) => setWeekNo(Number(event.target.value))} /></td>
      <td onClick={(event) => event.stopPropagation()}>
        <div className="schedule-edit-grid">
          <input className="inline-input date" required type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} />
          <input className="inline-input time" required type="time" value={startTime} onChange={(event) => setStartTime(event.target.value)} />
          <span>s/d</span>
          <input className="inline-input date" required type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} />
          <input className="inline-input time" required type="time" value={endTime} onChange={(event) => setEndTime(event.target.value)} />
        </div>
        <small className="muted-text">{formatAdminScheduleRange(batch)}</small>
      </td>
      <td onClick={(event) => event.stopPropagation()}><input className="inline-input" min={0} type="number" value={quota} onChange={(event) => setQuota(Number(event.target.value))} /></td>
      <td>{batch.reservedCount}</td>
      <td>{batch.confirmedCount}</td>
      <td>{batch.availableSlots}</td>
      <td onClick={(event) => event.stopPropagation()}>
        <select className="inline-select" value={status} onChange={(event) => setStatus(event.target.value)}>
          <option value="open">Dibuka</option>
          <option value="closed">Ditutup</option>
          <option value="full">Penuh</option>
        </select>
      </td>
      <td onClick={(event) => event.stopPropagation()}>
        <button className="ghost-button small" disabled={busy || !canSave} onClick={() => onSave({
          batchName: batchName.trim() || null,
          weekNo,
          quota,
          status,
          startsAt: composeJakartaDateTime(startDate, startTime),
          endsAt: composeJakartaDateTime(endDate, endTime)
        })}>Simpan</button>
      </td>
    </tr>
  );
}

function MobileBatchCard({
  batch,
  busy,
  selected,
  onSelect,
  onSave
}: {
  batch: AvailabilityItem;
  busy: boolean;
  selected: boolean;
  onSelect: () => void;
  onSave: (payload: BatchSavePayload) => void;
}) {
  const [batchName, setBatchName] = useState(batch.batchName ?? "");
  const [weekNo, setWeekNo] = useState(batch.weekNo);
  const [startDate, setStartDate] = useState(toDateInput(batch.startsAt, batch.timezone));
  const [startTime, setStartTime] = useState(toTimeInput(batch.startsAt, batch.timezone));
  const [endDate, setEndDate] = useState(toDateInput(batch.endsAt, batch.timezone));
  const [endTime, setEndTime] = useState(toTimeInput(batch.endsAt, batch.timezone));
  const [quota, setQuota] = useState(batch.quota);
  const [status, setStatus] = useState(batch.status);
  const canSave = Boolean(startDate && startTime && endDate && endTime && weekNo > 0 && quota >= 0);

  useEffect(() => {
    setBatchName(batch.batchName ?? "");
    setWeekNo(batch.weekNo);
    setStartDate(toDateInput(batch.startsAt, batch.timezone));
    setStartTime(toTimeInput(batch.startsAt, batch.timezone));
    setEndDate(toDateInput(batch.endsAt, batch.timezone));
    setEndTime(toTimeInput(batch.endsAt, batch.timezone));
    setQuota(batch.quota);
    setStatus(batch.status);
  }, [batch.batchName, batch.weekNo, batch.startsAt, batch.endsAt, batch.timezone, batch.quota, batch.status]);

  return (
    <article className={selected ? "batch-card-editor selected" : "batch-card-editor"}>
      <header className="batch-card-heading" onClick={onSelect}>
        <div>
          <strong>{batch.className}</strong>
          <span>Minggu {batch.weekNo} - {formatAdminScheduleRange(batch)}</span>
        </div>
        <span className={status === "open" ? "status-chip success" : "status-chip"}>{formatBatchStatus(status)}</span>
      </header>
      <div className="batch-card-meta">
        <span>Dipesan <strong>{batch.reservedCount}</strong></span>
        <span>Konfirmasi <strong>{batch.confirmedCount}</strong></span>
        <span>Sisa Slot <strong>{batch.availableSlots}</strong></span>
      </div>
      <div className="mobile-edit-grid">
        <label className="mobile-control">
          <span>Nama batch</span>
          <input className="inline-input" value={batchName} onChange={(event) => setBatchName(event.target.value)} placeholder={batch.batchCode} />
        </label>
        <label className="mobile-control">
          <span>Minggu</span>
          <input className="inline-input" min={1} type="number" value={weekNo} onChange={(event) => setWeekNo(Number(event.target.value))} />
        </label>
        <label className="mobile-control">
          <span>Tanggal mulai</span>
          <input className="inline-input" required type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} />
        </label>
        <label className="mobile-control">
          <span>Jam mulai</span>
          <input className="inline-input" required type="time" value={startTime} onChange={(event) => setStartTime(event.target.value)} />
        </label>
        <label className="mobile-control">
          <span>Tanggal selesai</span>
          <input className="inline-input" required type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} />
        </label>
        <label className="mobile-control">
          <span>Jam selesai</span>
          <input className="inline-input" required type="time" value={endTime} onChange={(event) => setEndTime(event.target.value)} />
        </label>
        <label className="mobile-control">
          <span>Kuota</span>
          <input className="inline-input" min={0} type="number" value={quota} onChange={(event) => setQuota(Number(event.target.value))} />
        </label>
        <label className="mobile-control">
          <span>Status</span>
          <select className="inline-select" value={status} onChange={(event) => setStatus(event.target.value)}>
            <option value="open">Dibuka</option>
            <option value="closed">Ditutup</option>
            <option value="full">Penuh</option>
          </select>
        </label>
      </div>
      <button className="ghost-button small full" disabled={busy || !canSave} onClick={() => onSave({
        batchName: batchName.trim() || null,
        weekNo,
        quota,
        status,
        startsAt: composeJakartaDateTime(startDate, startTime),
        endsAt: composeJakartaDateTime(endDate, endTime)
      })}>Simpan Jadwal</button>
    </article>
  );
}

function ScheduleMatrix({
  data,
  selectedBatchId,
  onSelect
}: {
  data: AdminSnapshot;
  selectedBatchId: string;
  onSelect: (batchId: string) => void;
}) {
  const weeks = Array.from(new Set(data.batches.map((batch) => batch.weekNo))).sort((a, b) => a - b);
  const rows = data.classes.map((klass) => ({
    klass,
    level: data.levels.find((level) => level.id === klass.levelId),
    batches: weeks.map((weekNo) => data.batches.filter((batch) => batch.classSlug === klass.slug && batch.weekNo === weekNo))
  }));

  if (rows.length === 0 || weeks.length === 0) {
    return <EmptyState icon={ClipboardList} title="Belum ada schedule/batch" />;
  }

  return (
    <div className="schedule-matrix" aria-label="Matriks jadwal" style={{ "--matrix-weeks": weeks.length } as CSSProperties}>
      <div className="matrix-row matrix-head">
        <span>Level / Kelas</span>
        {weeks.map((weekNo) => <span key={weekNo}>Minggu {weekNo}</span>)}
      </div>
      {rows.map((row) => (
        <div className="matrix-row" key={row.klass.id}>
          <div className="matrix-label">
            <strong>{row.klass.name}</strong>
            <span>{row.level?.name ?? "Level belum diset"}</span>
          </div>
          {row.batches.map((batches, index) => (
            <div className="matrix-cell" key={`${row.klass.id}-${weeks[index]}`}>
              {batches.length === 0 ? (
                <span className="muted-text">Belum ada batch</span>
              ) : (
                batches.map((batch) => (
                  <article className={selectedBatchId === batch.id ? "selected" : ""} key={batch.id} onClick={() => onSelect(batch.id)}>
                    <strong>{batch.batchName ?? batch.batchCode}</strong>
                    <span>{formatScheduleRange(batch)}</span>
                    <span>{batch.confirmedCount} terkonfirmasi / {batch.reservedCount} dipesan / {batch.availableSlots} sisa</span>
                    <span className={batch.status === "open" && batch.availableSlots > 0 ? "status-chip success" : "status-chip"}>{formatBatchStatus(batch.availableSlots <= 0 ? "full" : batch.status)}</span>
                  </article>
                ))
              )}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function BatchRosterPanel({
  data,
  selectedBatchId,
  onSelect
}: {
  data: AdminSnapshot;
  selectedBatchId: string;
  onSelect: (batchId: string) => void;
}) {
  if (!data.batchRosters.length) {
    return <EmptyState icon={Users} title="Belum ada jadwal untuk rekap peserta" hint="Buat jadwal batch dulu, lalu peserta yang memilih jadwal itu akan tampil di sini." />;
  }
  const selectedRoster = data.batchRosters.find((roster) => roster.batchId === selectedBatchId) ?? data.batchRosters[0];
  const remainingRosters = data.batchRosters.filter((roster) => roster.batchId !== selectedRoster.batchId);

  return (
    <section className="admin-panel batch-roster-panel" aria-label="Rekap peserta per jadwal">
      <PanelHeader
        title="2. Rekap peserta jadwal terpilih"
        subtitle="Nama anak, status pembayaran, single/bundling, status slot, total invoice, dan nomor referensi untuk jadwal yang dipilih."
        actions={<button className="ghost-button small" onClick={() => downloadRosterCsv(selectedRoster)}><Download size={14} />Export roster</button>}
      />
      <RosterScheduleCard roster={selectedRoster} featured />
      <PanelHeader title="Pindah ke jadwal lain" subtitle="Klik kartu singkat ini kalau admin mau cek roster jadwal lain." />
      <div className="roster-board">
        {remainingRosters.map((roster) => (
          <RosterScheduleCard key={roster.batchId} roster={roster} compact onSelect={() => onSelect(roster.batchId)} />
        ))}
      </div>
    </section>
  );
}

function RosterScheduleCard({
  roster,
  featured,
  compact,
  onSelect
}: {
  roster: AdminSnapshot["batchRosters"][number];
  featured?: boolean;
  compact?: boolean;
  onSelect?: () => void;
}) {
  const paidCount = roster.students.filter((student) => ["paid", "confirmed", "completed"].includes(student.paymentStatus) || ["paid", "confirmed", "completed"].includes(student.registrationStatus)).length;
  const waitingCount = roster.students.filter((student) => ["pending_invoice", "waiting_payment"].includes(student.paymentStatus) || ["pending_invoice", "waiting_payment"].includes(student.registrationStatus)).length;
  const bundlingCount = roster.students.filter((student) => student.isBundling).length;
  return (
    <article className={`${featured ? "roster-schedule-card featured" : "roster-schedule-card"}${compact ? " compact-card" : ""}`} onClick={onSelect}>
      <header className="roster-schedule-head">
        <div>
          <span>Minggu {roster.weekNo}</span>
          <strong>{formatRosterTitle(roster)}</strong>
          <p>{formatAdminScheduleRange(roster)}</p>
        </div>
        <div className="roster-kpis compact" aria-label="Ringkasan roster">
          <span><strong>{roster.students.length}</strong> peserta</span>
          <span><strong>{paidCount}</strong> sudah bayar</span>
          <span><strong>{waitingCount}</strong> menunggu</span>
          <span><strong>{bundlingCount}</strong> bundling</span>
          <span><strong>{roster.availableSlots}</strong> sisa slot</span>
        </div>
      </header>
      {compact ? null : roster.students.length ? (
        <>
          <div className="table-wrap roster-table">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Anak</th>
                  <th>Orang tua</th>
                  <th>Paket</th>
                  <th>Status bayar</th>
                  <th>Status slot</th>
                  <th>Total</th>
                  <th>Ref</th>
                </tr>
              </thead>
              <tbody>
                {roster.students.map((student) => (
                  <tr key={`${roster.batchId}-${student.registrationId}`}>
                    <td>
                      <strong>{student.studentName}</strong>
                      <small>{student.levelName ?? "-"}</small>
                    </td>
                    <td>
                      <strong>{student.parentName}</strong>
                      <small>{student.parentWhatsapp ?? "-"}</small>
                    </td>
                    <td>
                      <span className={student.isBundling ? "status-chip success" : "status-chip"}>{student.isBundling ? "Bundling" : "Single"}</span>
                      <small>{student.packageName}</small>
                    </td>
                    <td><span className={getPaymentStatusClass(student.paymentStatus)}>{formatPaymentStatus(student.paymentStatus)}</span></td>
                    <td><span className={getSlotStatusClass(student.slotStatus)}>{formatSlotStatus(student.slotStatus)}</span></td>
                    <td>{formatRupiah(student.total)}</td>
                    <td>{student.externalReference}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="roster-mobile-list">
            {roster.students.map((student) => (
              <article className="roster-student-card" key={`${roster.batchId}-${student.registrationId}-mobile`}>
                <header>
                  <div>
                    <strong>{student.studentName}</strong>
                    <span>{student.parentName} - {student.parentWhatsapp ?? "-"}</span>
                  </div>
                  <span className={getPaymentStatusClass(student.paymentStatus)}>{formatPaymentStatus(student.paymentStatus)}</span>
                </header>
                <div className="roster-student-meta">
                  <span>{student.isBundling ? "Bundling" : "Single"}</span>
                  <span>{student.packageName}</span>
                  <span>{formatRupiah(student.total)}</span>
                  <span>{formatSlotStatus(student.slotStatus)}</span>
                </div>
                <small>{student.externalReference}</small>
              </article>
            ))}
          </div>
        </>
      ) : (
        <EmptyState icon={Users} title="Belum ada peserta di jadwal ini" hint="Kalau orang tua sudah daftar dan memilih jadwal ini, nama anak serta status bayarnya akan muncul di tabel ini." />
      )}
    </article>
  );
}

function CommandPalette({ open, onClose, data }: { open: boolean; onClose: () => void; data: AdminSnapshot }) {
  const [query, setQuery] = useState("");

  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  if (!open) return null;

  const normalizedQuery = query.trim().toLowerCase();
  const pageResults = navItems
    .map((item) => ({ type: "Halaman", label: item.label, sub: item.help, href: navPath(item), icon: item.icon }))
    .filter((item) => !normalizedQuery || `${item.label} ${item.sub}`.toLowerCase().includes(normalizedQuery));
  const registrationResults = data.registrations
    .filter((item) => {
      const text = `${item.studentName} ${item.parentName} ${item.parentWhatsapp ?? ""} ${item.externalReference} ${item.packageName}`.toLowerCase();
      return normalizedQuery && text.includes(normalizedQuery);
    })
    .slice(0, 6)
    .map((item) => ({ type: "Peserta", label: item.studentName, sub: `${item.parentName} - ${formatRegistrationStatus(item.status)}`, href: appPath("/admin/registrations"), icon: Users }));
  const invoiceResults = data.invoices
    .filter((item) => {
      const text = `${item.invoiceNumber ?? ""} ${item.invoiceId} ${item.externalReference} ${item.studentName ?? ""}`.toLowerCase();
      return normalizedQuery && text.includes(normalizedQuery);
    })
    .slice(0, 5)
    .map((item) => ({ type: "Invoice", label: item.invoiceNumber ?? item.invoiceId, sub: `${item.studentName ?? "-"} - ${formatInvoiceStatus(item.status)}`, href: appPath("/admin/registrations"), icon: CreditCard }));
  const results = [...registrationResults, ...invoiceResults, ...pageResults].slice(0, 14);

  return (
    <div className="cmdk-scrim" onClick={onClose}>
      <div className="cmdk" onClick={(event) => event.stopPropagation()}>
        <div className="cmdk-input">
          <Search size={18} />
          <input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cari halaman, peserta, invoice..." />
          <button className="icon-button" onClick={onClose} aria-label="Tutup pencarian"><X size={16} /></button>
        </div>
        <div className="cmdk-list">
          {results.length ? results.map((item) => (
            <Link className="cmdk-item" href={item.href} key={`${item.type}-${item.label}-${item.sub}`} onClick={onClose}>
              <item.icon size={18} />
              <div>
                <strong>{item.label}</strong>
                <span>{item.sub}</span>
              </div>
              <small>{item.type}</small>
            </Link>
          )) : (
            <EmptyState icon={Search} title="Tidak ada hasil" hint="Coba cari nama peserta, nomor WhatsApp, invoice, atau nama halaman." />
          )}
        </div>
      </div>
    </div>
  );
}

function PageFrame({ children }: { children: React.ReactNode }) {
  return <div className="admin-page">{children}</div>;
}

function Metric({ label, value, valueText, tone }: { label: string; value?: number; valueText?: string; tone: string }) {
  return (
    <div className={`metric-card ${tone}`}>
      <span>{label}</span>
      <strong>{valueText ?? value ?? 0}</strong>
    </div>
  );
}

function PanelHeader({ title, subtitle, actions }: { title: string; subtitle: string; actions?: React.ReactNode }) {
  return (
    <div className="panel-header">
      <div>
        <h2>{title}</h2>
        <p>{subtitle}</p>
      </div>
      {actions ? <div className="panel-actions">{actions}</div> : null}
    </div>
  );
}

function EmptyState({ icon: Icon, title, hint }: { icon: LucideIcon; title: string; hint?: string }) {
  return (
    <div className="empty-state">
      <Icon size={24} />
      <span>{title}</span>
      {hint ? <small>{hint}</small> : null}
    </div>
  );
}

function InfoBlock({ title, rows }: { title: string; rows: Array<[string, React.ReactNode]> }) {
  return (
    <article className="info-block">
      <h3>{title}</h3>
      <div>
        {rows.map(([label, value]) => (
          <p key={`${title}-${label}`}>
            <span>{label}</span>
            <strong>{value}</strong>
          </p>
        ))}
      </div>
    </article>
  );
}

function StatusCallout({ tone, title, value }: { tone: "success" | "danger" | "info"; title: string; value: string }) {
  return (
    <div className={`status-callout ${tone}`}>
      <strong>{title}</strong>
      <span>{value}</span>
    </div>
  );
}

function isPageId(value?: string): value is AdminPageId {
  return Boolean(value && navItems.some((item) => item.id === value));
}

function getNavCount(id: AdminPageId, data: AdminSnapshot) {
  if (id === "registrasi") return data.metrics.waitingPayment + data.metrics.invoiceFailed;
  if (id === "schedule") return data.batches.filter((batch) => batch.status === "open" && batch.availableSlots <= 2).length;
  if (id === "device") return data.metrics.deviceOrders;
  if (id === "whatsapp") return data.whatsappLogs.filter((log) => log.status === "failed").length;
  if (id === "webhooks") return data.webhookLogs.filter((log) => log.processingStatus === "failed").length;
  if (id === "audit") return data.reconciliationLogs.filter((log) => log.status === "failed").length;
  return 0;
}

function buildRecentActivity(data: AdminSnapshot): Array<{ icon: LucideIcon; tone: string; text: string; time: string }> {
  const registrationItems = data.registrations.slice(0, 3).map((item) => ({
    icon: item.status === "invoice_failed" ? AlertTriangle : item.status === "paid" || item.status === "confirmed" ? CheckCircle2 : Users,
    tone: item.status === "invoice_failed" ? "red" : item.status === "paid" || item.status === "confirmed" ? "green" : "blue",
    text: `${formatRegistrationStatus(item.status)} - ${item.studentName}`,
    time: item.createdAt ? formatDateTime(item.createdAt) : item.externalReference
  }));
  const invoiceItems = data.invoices.slice(0, 2).map((item) => ({
    icon: item.status === "paid" ? DollarSign : item.status === "failed" ? AlertTriangle : CreditCard,
    tone: item.status === "paid" ? "green" : item.status === "failed" ? "red" : "amber",
    text: `${formatInvoiceStatus(item.status)} - ${item.studentName ?? item.externalReference}`,
    time: item.createdAt ? formatDateTime(item.createdAt) : item.invoiceNumber ?? item.invoiceId
  }));
  return [...registrationItems, ...invoiceItems].slice(0, 5);
}

function downloadRegistrationsCsv(registrations: AdminSnapshot["registrations"]) {
  downloadCsv("event-manager-registrations.csv", [
    ["External Ref", "Nama Anak", "Orang Tua", "WhatsApp", "Kelas Anak", "Sekolah", "Level", "Paket", "Jadwal", "Status", "Pembayaran", "Total"],
    ...registrations.map((item) => [
      item.externalReference,
      item.studentName,
      item.parentName,
      item.parentWhatsapp ?? "",
      item.studentGradeRaw ?? "",
      item.studentSchool ?? "",
      item.levelName ?? "",
      item.packageName,
      (item.selectedSchedules ?? []).join(" | "),
      formatRegistrationStatus(item.status),
      formatPaymentStatus(item.paymentStatus),
      String(item.total)
    ])
  ]);
}

function downloadRosterCsv(roster: AdminSnapshot["batchRosters"][number]) {
  downloadCsv(`roster-${roster.batchCode}.csv`, [
    ["Jadwal", `${formatRosterTitle(roster)} - Minggu ${roster.weekNo}`, formatAdminScheduleRange(roster)],
    [],
    ["Nama Anak", "Orang Tua", "WhatsApp", "Paket", "Bundling", "Status Bayar", "Status Slot", "Total", "External Ref"],
    ...roster.students.map((student) => [
      student.studentName,
      student.parentName,
      student.parentWhatsapp ?? "",
      student.packageName,
      student.isBundling ? "Ya" : "Tidak",
      formatPaymentStatus(student.paymentStatus),
      formatSlotStatus(student.slotStatus),
      String(student.total),
      student.externalReference
    ])
  ]);
}

function downloadCsv(filename: string, rows: Array<Array<string>>) {
  if (typeof window === "undefined") return;
  const csv = rows.map((row) => row.map((cell) => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function yesNo(value?: boolean) {
  return value ? "Aktif" : "Tidak";
}

function invoiceStatusClass(value: string) {
  if (value === "paid") return "status-chip success";
  if (value === "expired" || value === "cancelled" || value === "failed") return "status-chip danger";
  return "status-chip";
}

function formatAccessType(value: string) {
  return ({ public: "Publik", code: "Pakai Kode", token: "Pakai Token" }[value] ?? value);
}

function formatPriceType(value: string) {
  return ({ normal: "Harga Normal", alpha_omega: "Harga Sekolah Partner", partner_school: "Harga Sekolah Partner" }[value] ?? value);
}

function formatFormStatus(value: string) {
  return ({ draft: "Draft", active: "Aktif", closed: "Ditutup", archived: "Diarsipkan" }[value] ?? value);
}

function formatBatchStatus(value: string) {
  return ({ open: "Dibuka", closed: "Ditutup", full: "Penuh" }[value] ?? value);
}

function formatAdminScheduleRange(batch: Pick<AvailabilityItem, "startsAt" | "endsAt" | "timezone">) {
  const start = new Date(batch.startsAt);
  const end = new Date(batch.endsAt);
  const sameDate = toDateInput(batch.startsAt, batch.timezone) === toDateInput(batch.endsAt, batch.timezone);
  const dateFormatter = new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    timeZone: batch.timezone
  });
  const weekdayFormatter = new Intl.DateTimeFormat("id-ID", {
    weekday: "long",
    timeZone: batch.timezone
  });
  const date = sameDate
    ? `${weekdayFormatter.format(start)}, ${dateFormatter.format(start)}`
    : `${dateFormatter.format(start)} - ${dateFormatter.format(end)}`;
  const timeFormat = new Intl.DateTimeFormat("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: batch.timezone
  });
  return `${date}, ${timeFormat.format(start)}-${timeFormat.format(end)}`;
}

function formatRosterTitle(roster: Pick<AdminSnapshot["batchRosters"][number], "className" | "batchName" | "batchCode">) {
  const batchLabel = roster.batchName || roster.batchCode;
  if (batchLabel.toLowerCase().includes(roster.className.toLowerCase())) return batchLabel;
  return `${roster.className} - ${batchLabel}`;
}

function toDateInput(value: string, timezone = "Asia/Jakarta") {
  const parts = new Intl.DateTimeFormat("en-CA", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    timeZone: timezone || "Asia/Jakarta"
  }).formatToParts(new Date(value));
  const get = (type: string) => parts.find((part) => part.type === type)?.value ?? "01";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

function toTimeInput(value: string, timezone = "Asia/Jakarta") {
  const parts = new Intl.DateTimeFormat("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: timezone || "Asia/Jakarta"
  }).formatToParts(new Date(value));
  const get = (type: string) => parts.find((part) => part.type === type)?.value ?? "00";
  return `${get("hour")}:${get("minute")}`;
}

function composeJakartaDateTime(date: string, time: string) {
  return `${date}T${time || "00:00"}:00+07:00`;
}

function addDaysToDateInput(date: string, days: number) {
  if (!date) return "";
  const [year, month, day] = date.split("-").map(Number);
  const current = new Date(Date.UTC(year, (month || 1) - 1, day || 1));
  if (!Number.isFinite(current.getTime())) return date;
  current.setUTCDate(current.getUTCDate() + days);
  return current.toISOString().slice(0, 10);
}

function formatRegistrationStatus(value: string) {
  return (
    {
      pending_invoice: "Menyiapkan invoice",
      invoice_failed: "Invoice gagal",
      waiting_payment: "Menunggu pembayaran",
      paid: "Sudah dibayar",
      confirmed: "Terkonfirmasi",
      expired: "Kedaluwarsa",
      cancelled: "Dibatalkan",
      completed: "Selesai"
    }[value] ?? value
  );
}

function formatDeviceStatus(value: string) {
  return ({ pending: "Menunggu fulfillment", fulfillment_needed: "Perlu diproses", prepared: "Disiapkan", delivered: "Sudah diberikan", picked_up: "Sudah diambil", cancelled: "Dibatalkan" }[value] ?? value);
}

function formatInvoiceStatus(value: string) {
  return ({ waiting_payment: "Menunggu pembayaran", paid: "Sudah dibayar", expired: "Kedaluwarsa", cancelled: "Dibatalkan", failed: "Gagal" }[value] ?? value);
}

function formatPaymentStatus(value: string) {
  return ({ waiting_payment: "Menunggu bayar", paid: "Sudah bayar", confirmed: "Terkonfirmasi", completed: "Selesai", expired: "Kedaluwarsa", cancelled: "Dibatalkan", invoice_failed: "Invoice gagal", failed: "Gagal", "-": "-" }[value] ?? value);
}

function formatSlotStatus(value: string) {
  return ({ reserved: "Dipesan", confirmed: "Terkonfirmasi", released: "Dilepas", expired: "Kedaluwarsa", cancelled: "Dibatalkan" }[value] ?? value);
}

function getPaymentStatusClass(value: string) {
  return ["paid", "confirmed", "completed"].includes(value)
    ? "status-chip success"
    : ["expired", "cancelled", "invoice_failed", "failed"].includes(value)
      ? "status-chip danger"
      : "status-chip";
}

function getSlotStatusClass(value: string) {
  return value === "confirmed"
    ? "status-chip success"
    : ["released", "expired", "cancelled"].includes(value)
      ? "status-chip danger"
      : "status-chip";
}

function formatAnalyticsLabel(value: string) {
  return ({ Visits: "Kunjungan", Started: "Mulai isi form", Submitted: "Form terkirim", "Invoice Created": "Invoice dibuat", Paid: "Sudah bayar", Errors: "Error" }[value] ?? value);
}

function formatIntegrationAction(value: string) {
  return (
    {
      invoice_api: "API Invoice",
      invoice_status: "Status Invoice",
      create_invoice: "Buat Invoice",
      whatsapp_send: "Kirim WhatsApp",
      send_invoice: "Kirim Invoice",
      invoice_webhook: "Webhook Invoice",
      sync_invoices: "Sinkron Invoice",
      reconcile_batch_counters: "Hitung Ulang Kuota",
      release_expired_reservations: "Lepas Slot Kedaluwarsa",
      activate_after_payment: "Aktif setelah pembayaran"
    }[value] ?? value
  );
}

function formatIntegrationStatus(value: string) {
  return ({ ready: "Siap", success: "Berhasil", failed: "Gagal", processing: "Diproses", processed: "Diproses", ignored: "Diabaikan", rejected: "Ditolak", pending: "Menunggu" }[value] ?? value);
}

function formatIntegrationMessage(value: string) {
  return ({ "Configured through LMS Core API only": "Koneksi LMS aktif." }[value] ?? value);
}

function formatWhatsappType(value: string) {
  return ({ invoice_created: "Invoice dibuat", invoice_retry: "Invoice dibuat ulang", invoice_reminder: "Reminder invoice", payment_confirmed: "Pembayaran diterima", schedule_info: "Info jadwal", certificate_sent: "Sertifikat terkirim" }[value] ?? value);
}

function formatAuditAction(value: string) {
  return ({ program_create: "Buat program", program_update: "Ubah program", form_create: "Buat form", form_update: "Ubah form", pricing_update: "Ubah harga", batch_update: "Ubah jadwal/kuota", batch_quota_status_update: "Ubah jadwal/kuota", registration_cancel: "Batalkan registrasi", invoice_resend: "Kirim ulang invoice", invoice_status_refresh: "Update status invoice", payment_manual_override: "Ubah status bayar manual", device_update: "Ubah status device", device_status_update: "Ubah status device", webhook_reprocess: "Proses ulang webhook", certificate_generate: "Buat sertifikat" }[value] ?? value);
}

function formatDateTime(value: string) {
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}
